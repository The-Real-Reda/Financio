
import { GoogleGenAI, Chat } from '@google/genai';

const API_KEY = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const getChatResponse = (systemInstruction: string): Chat => {
  return ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: { systemInstruction },
  });
};

export const fetchStockNews = async (name: string, ticker: string) => {
  const prompt = `Provide the 3 most significant recent financial news items for ${name} (${ticker}). Format: HEADLINE, SOURCE_DATE, SUMMARY. Separate items with ---ITEM_SEPARATOR---.`;
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: { tools: [{ googleSearch: {} }] },
  });
  return { 
    text: response.text, 
    groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks 
  };
};
