
import { Asset, AssetType, BankAccount, Transaction, ChartDataPoint } from './types';

export const MOCK_ASSETS: Asset[] = [
  // Tech Giants (Stocks)
  { id: '1', name: 'Apple Inc.', ticker: 'AAPL', type: AssetType.Stock, price: 172.25, change24h: 2.50, change24h_percent: 1.47, value: 0, holdings: 0, maxSupply: 15500000000, logo: 'https://logo.clearbit.com/apple.com' },
  { id: '2', name: 'Microsoft', ticker: 'MSFT', type: AssetType.Stock, price: 420.55, change24h: 3.20, change24h_percent: 0.76, value: 0, holdings: 0, maxSupply: 7430000000, logo: 'https://logo.clearbit.com/microsoft.com' },
  { id: '5', name: 'NVIDIA', ticker: 'NVDA', type: AssetType.Stock, price: 880.08, change24h: 15.12, change24h_percent: 1.75, value: 0, holdings: 0, maxSupply: 2500000000, logo: 'https://logo.clearbit.com/nvidia.com' },
  { id: '7', name: 'Tesla', ticker: 'TSLA', type: AssetType.Stock, price: 175.00, change24h: -5.20, change24h_percent: -2.89, value: 0, holdings: 0, maxSupply: 3190000000, logo: 'https://logo.clearbit.com/tesla.com' },

  // Crypto
  { id: '15', name: 'Bitcoin', ticker: 'BTC', type: AssetType.Crypto, price: 68134.78, change24h: -1200.45, change24h_percent: -1.73, value: 0, holdings: 0, maxSupply: 21000000, logo: 'https://logo.clearbit.com/bitcoin.org' },
  { id: '16', name: 'Ethereum', ticker: 'ETH', type: AssetType.Crypto, price: 3540.12, change24h: 80.23, change24h_percent: 2.31, value: 0, holdings: 0, maxSupply: 120000000, logo: 'https://logo.clearbit.com/ethereum.org' },
  { id: '17', name: 'Solana', ticker: 'SOL', type: AssetType.Crypto, price: 145.20, change24h: 5.40, change24h_percent: 3.86, value: 0, holdings: 0, maxSupply: 443000000, logo: 'https://logo.clearbit.com/solana.com' },

  // Commodities (Gold & Silver)
  { id: '48', name: 'Physical Gold', ticker: 'XAU', type: AssetType.Commodity, price: 2350.10, change24h: 15.80, change24h_percent: 0.68, value: 0, holdings: 0, maxSupply: 1000000, logo: 'https://upload.wikimedia.org/wikipedia/commons/d/d7/Gold-Bars.png' },
  { id: '60', name: 'Silver Spot', ticker: 'XAG', type: AssetType.Commodity, price: 28.45, change24h: 0.45, change24h_percent: 1.58, value: 0, holdings: 0, maxSupply: 5000000, logo: 'https://upload.wikimedia.org/wikipedia/commons/5/55/Silver_crystal.jpg' },
  { id: '61', name: 'Digital Gold Token', ticker: 'DGX', type: AssetType.Crypto, price: 75.20, change24h: 0.10, change24h_percent: 0.13, value: 0, holdings: 0, maxSupply: 10000000, logo: 'https://logo.clearbit.com/digix.global' },

  // Management / Funds ("Man")
  { id: '62', name: 'Vanguard 500', ticker: 'VOO', type: AssetType.Stock, price: 470.12, change24h: 2.10, change24h_percent: 0.45, value: 0, holdings: 0, maxSupply: 999999999, logo: 'https://logo.clearbit.com/vanguard.com' },
  { id: '63', name: 'Fidelity Growth', ticker: 'FBCG', type: AssetType.Stock, price: 32.50, change24h: 0.85, change24h_percent: 2.62, value: 0, holdings: 0, maxSupply: 500000000, logo: 'https://logo.clearbit.com/fidelity.com' },
];

export const MOCK_ACCOUNTS: BankAccount[] = [
    { id: '1', name: 'Primary Wallet', provider: 'Financify Bank', accountNumber: '**** 8890', balance: 12500.00, currency: 'USD' },
    { id: '2', name: 'Crypto Wallet', provider: 'MetaMask', accountNumber: '0x71...3f', balance: 0.5, currency: 'ETH' }
];

export const MOCK_TRANSACTIONS: Transaction[] = [
    { id: 't1', date: new Date().toISOString().split('T')[0], description: 'Gold Purchase', amount: 1200, type: 'debit' }
];

export const MOCK_CHART_DATA: ChartDataPoint[] = [
  { date: 'Mon', price: 100 },
  { date: 'Tue', price: 105 },
  { date: 'Wed', price: 102 },
  { date: 'Thu', price: 110 },
  { date: 'Fri', price: 108 },
  { date: 'Sat', price: 115 },
  { date: 'Sun', price: 120 },
];
