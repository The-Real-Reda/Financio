
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import Card from '../components/common/Card';
import Icon from '../components/common/Icon';
import { getChatResponse } from '../services/geminiService';
import { Chat } from '@google/genai';

interface AdvisorPageProps {
  location: GeolocationCoordinates | null;
  locationError: string | null;
}

interface Message {
  sender: 'user' | 'bot';
  text: string;
}

const AdvisorPage: React.FC<AdvisorPageProps> = ({ location }) => {
  const routeLocation = useLocation();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const chatRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const hasAutoQueried = useRef(false);

  const initChat = useCallback(() => {
    if (chatRef.current) return chatRef.current;
    const systemInstruction = `You are Financify AI. 
    Expertise: Financial Analysis, Market Trends, and JAVA/ANDROID DEVELOPMENT.
    Rules: 
    1. Provide concise financial advice.
    2. If the user asks for technical implementation, provide clean JAVA or SPRING BOOT code snippets.
    3. Use Markdown.
    User Location: ${location ? `${location.latitude},${location.longitude}` : 'Unknown'}`;
    
    try {
        const chat = getChatResponse(systemInstruction);
        chatRef.current = chat;
        return chat;
    } catch (e) {
        return null;
    }
  }, [location]);

  const sendMessageToBot = useCallback(async (text: string) => {
    if (!text.trim() || isLoading) return;
    const chat = initChat();
    if (!chat) return;
    
    setMessages(prev => [...prev, { sender: 'user', text }]);
    setInput('');
    setIsLoading(true);
    setMessages(prev => [...prev, { sender: 'bot', text: '' }]);

    try {
        const stream = await chat.sendMessageStream({ message: text });
        for await (const chunk of stream) {
            const chunkText = chunk.text;
            if(chunkText) {
                setMessages(prev => {
                    const newMsg = [...prev];
                    const last = { ...newMsg[newMsg.length - 1] };
                    last.text += chunkText;
                    newMsg[newMsg.length - 1] = last;
                    return newMsg;
                });
            }
        }
    } catch (e: any) {
        setError("Network error. Java backend simulator disconnected.");
    } finally {
        setIsLoading(false);
    }
  }, [isLoading, initChat]);

  useEffect(() => {
    if (routeLocation.state?.autoQuery && !hasAutoQueried.current) {
        hasAutoQueried.current = true;
        sendMessageToBot(routeLocation.state.autoQuery);
    }
  }, [routeLocation.state, sendMessageToBot]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="h-full flex flex-col w-full pb-6">
      <header className="mb-6 flex items-center justify-between">
        <div>
            <h1 className="text-2xl font-bold">AI Advisor</h1>
            <div className="flex items-center gap-2 mt-1">
                <span className="w-2 h-2 rounded-full bg-brand-success"></span>
                <span className="text-[10px] font-bold text-brand-text-secondary uppercase tracking-widest">Java SDK Engine v4.0</span>
            </div>
        </div>
        <button 
            onClick={() => sendMessageToBot("Generate a Java Spring Boot class to handle stock purchase validation logic.")}
            className="text-[10px] font-bold bg-white/5 border border-white/10 px-3 py-1.5 rounded-m3 hover:bg-white/10 transition-colors"
        >
            GENERATE JAVA LOGIC
        </button>
      </header>
      
      <Card className="flex-1 flex flex-col overflow-hidden !p-0 border-m3-surface-variant/30">
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {messages.map((msg, index) => (
            <div key={index} className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] p-4 rounded-m3 text-sm leading-relaxed ${
                  msg.sender === 'user' ? 'bg-m3-primary-container text-white rounded-tr-sm' : 'bg-m3-surface-variant/20 text-[#E2E2E6] rounded-tl-sm'
              }`}>
                <div className="whitespace-pre-wrap">{msg.text}</div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        
        <div className="p-4 bg-m3-surface border-t border-white/5">
            <div className="flex gap-2">
                <input 
                    type="text" 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && sendMessageToBot(input)}
                    placeholder="Ask about markets or Java implementation..."
                    className="flex-1 bg-brand-bg border border-white/10 rounded-m3 px-5 py-3 text-sm focus:ring-1 focus:ring-m3-primary outline-none text-white"
                />
                <button
                    onClick={() => sendMessageToBot(input)}
                    disabled={isLoading || !input.trim()}
                    className="w-12 h-12 flex items-center justify-center bg-m3-primary-container text-white rounded-m3 shadow-lg"
                >
                    <Icon name="send" className="w-5 h-5" />
                </button>
            </div>
        </div>
      </Card>
    </div>
  );
};

export default AdvisorPage;
