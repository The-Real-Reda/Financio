import React, { useState } from 'react';
import Icon from '../components/common/Icon';
import Logo from '../components/common/Logo';
import { useAuth } from '../context/AuthContext';

const LoginPage: React.FC = () => {
  const { login, register, resetPassword } = useAuth();
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');
  
  // Form State
  const [name, setName] = useState('');
  const [username, setUsername] = useState(''); // Used as email in this implementation
  const [password, setPassword] = useState('');
  
  // UI State
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState<{msg: string, type: 'success' | 'error'} | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setFeedback(null);

    try {
      if (mode === 'login') {
        const res = await login(username, password);
        if (!res.success) throw new Error(res.message);
      } else if (mode === 'register') {
        if (!name || !username || !password) throw new Error("All fields are required");
        const res = await register(name, username, password);
        if (!res.success) throw new Error(res.message);
      } else if (mode === 'forgot') {
        if (!username) throw new Error("Please enter your email");
        const res = await resetPassword(username);
        setFeedback({ msg: res.message, type: 'success' });
      }
    } catch (err: any) {
      setFeedback({ msg: err.message, type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-brand-bg p-4 text-brand-text-primary">
      <div className="w-full max-w-md bg-brand-surface p-8 rounded-2xl border border-brand-border shadow-2xl relative overflow-hidden transition-all duration-300">
        {/* Background Decoration */}
        <div className={`absolute top-0 left-0 w-full h-2 bg-gradient-to-r transition-colors duration-500 ${
            mode === 'register' ? 'from-purple-500 to-brand-primary' : 
            mode === 'forgot' ? 'from-orange-500 to-red-500' :
            'from-brand-success to-brand-primary'
        }`}></div>
        
        <div className="flex flex-col items-center mb-8 z-10 relative">
          <div className="mb-4">
             <Logo className="w-20 h-20 drop-shadow-lg" />
          </div>
          <h1 className="text-3xl font-bold text-center tracking-tight">Financio</h1>
          <p className="text-brand-text-secondary mt-2">Your AI-Powered Finance Hub</p>
        </div>

        {/* Tabs */}
        <div className="flex bg-brand-bg p-1 rounded-xl mb-6">
            <button 
                onClick={() => { setMode('login'); setFeedback(null); }}
                className={`flex-1 py-2 text-sm font-semibold rounded-lg transition-all ${mode === 'login' ? 'bg-brand-surface text-brand-primary shadow-sm' : 'text-brand-text-secondary hover:text-white'}`}
            >
                Log In
            </button>
            <button 
                onClick={() => { setMode('register'); setFeedback(null); }}
                className={`flex-1 py-2 text-sm font-semibold rounded-lg transition-all ${mode === 'register' ? 'bg-brand-surface text-brand-primary shadow-sm' : 'text-brand-text-secondary hover:text-white'}`}
            >
                Sign Up
            </button>
        </div>

        <h2 className="text-xl font-semibold mb-6 text-center animate-in fade-in slide-in-from-top-2">
          {mode === 'login' && 'Welcome Back'}
          {mode === 'register' && 'Create Your Account'}
          {mode === 'forgot' && 'Reset Password'}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'register' && (
             <div className="animate-in fade-in slide-in-from-left-2">
                <label className="block text-sm text-brand-text-secondary mb-1">Full Name</label>
                <input 
                  type="text" 
                  required={mode === 'register'}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-brand-bg border border-brand-border rounded-lg p-3 text-brand-text-primary focus:outline-none focus:border-brand-primary focus:ring-1 focus:ring-brand-primary transition-all"
                  placeholder="John Doe"
                />
             </div>
          )}

          <div className="animate-in fade-in slide-in-from-left-2 delay-75">
            <label className="block text-sm text-brand-text-secondary mb-1">Email Address</label>
            <input 
              type="email" 
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-brand-bg border border-brand-border rounded-lg p-3 text-brand-text-primary focus:outline-none focus:border-brand-primary focus:ring-1 focus:ring-brand-primary transition-all"
              placeholder="name@example.com"
            />
          </div>

          {(mode === 'login' || mode === 'register') && (
              <div className="animate-in fade-in slide-in-from-left-2 delay-150">
                <label className="block text-sm text-brand-text-secondary mb-1">Password</label>
                <input 
                  type="password" 
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-brand-bg border border-brand-border rounded-lg p-3 text-brand-text-primary focus:outline-none focus:border-brand-primary focus:ring-1 focus:ring-brand-primary transition-all"
                  placeholder="••••••••"
                />
              </div>
          )}
          
          {feedback && (
             <div className={`text-sm p-3 rounded-lg text-center ${feedback.type === 'success' ? 'bg-brand-success/10 text-brand-success' : 'bg-brand-danger/10 text-brand-danger'}`}>
                 {feedback.msg}
             </div>
          )}

          <button 
            type="submit" 
            disabled={isLoading}
            className={`w-full font-bold py-3 rounded-lg transition-all duration-200 mt-4 shadow-lg flex items-center justify-center gap-2 ${isLoading ? 'opacity-70 cursor-wait' : 'hover:brightness-110 active:scale-95'}
             ${mode === 'register' ? 'bg-gradient-to-r from-purple-600 to-brand-secondary text-white' : 
               mode === 'forgot' ? 'bg-brand-surface border border-brand-border hover:bg-brand-border text-brand-text-primary' :
               'bg-gradient-to-r from-brand-success to-brand-primary text-white'
             }`}
          >
            {isLoading && (
               <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            )}
            {mode === 'login' && 'Log In'}
            {mode === 'register' && 'Sign Up'}
            {mode === 'forgot' && 'Send Reset Link'}
          </button>
        </form>

        <div className="mt-6 text-center">
          {mode === 'login' && (
             <button onClick={() => { setMode('forgot'); setFeedback(null); }} className="text-xs text-brand-text-secondary hover:text-brand-primary">
                 Forgot password?
             </button>
          )}
          {mode === 'forgot' && (
              <button onClick={() => { setMode('login'); setFeedback(null); }} className="text-sm text-brand-primary font-semibold hover:underline">
                  Back to Login
              </button>
          )}
        </div>
      </div>
      
      <div className="mt-8 flex items-center gap-2 text-brand-text-secondary opacity-50">
         <Logo className="w-6 h-6 grayscale opacity-70" />
         <span className="text-sm font-medium tracking-widest">FINANCIO</span>
      </div>
    </div>
  );
};

export default LoginPage;