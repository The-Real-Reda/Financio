
import React, { useState, useEffect, useMemo } from 'react';
import { MOCK_CHART_DATA } from '../constants';
import Card from '../components/common/Card';
import StockChart from '../components/invest/StockChart';
import StockNews from '../components/invest/StockNews';
import { Asset, AssetType } from '../types';
import { useFinance } from '../context/FinanceContext';
import { useLocation } from 'react-router-dom';
import Icon from '../components/common/Icon';
import AssetLogo from '../components/common/AssetLogo';

const InvestPage: React.FC = () => {
  const { assets, executeTrade, accounts } = useFinance();
  const location = useLocation();
  const [selectedAssetId, setSelectedAssetId] = useState<string>(assets[0]?.id || '');
  const [tradeAmount, setTradeAmount] = useState('1');
  const [tradeType, setTradeType] = useState<'buy' | 'sell'>('buy');
  const [activeCategory, setActiveCategory] = useState<'All' | AssetType>('All');
  const [feedback, setFeedback] = useState<{msg: string, type: 'success' | 'error'} | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const categories = ['All', AssetType.Stock, AssetType.Crypto, AssetType.Commodity];

  useEffect(() => {
    if (location.state && location.state.assetId) {
       setSelectedAssetId(location.state.assetId);
    }
  }, [location.state]);

  const filteredAssets = useMemo(() => {
    return assets.filter(a => {
      const matchesSearch = a.name.toLowerCase().includes(searchTerm.toLowerCase()) || a.ticker.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = activeCategory === 'All' || a.type === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [assets, searchTerm, activeCategory]);

  const selectedAsset = useMemo(() => {
    return assets.find(a => a.id === selectedAssetId) || filteredAssets[0] || assets[0];
  }, [assets, selectedAssetId, filteredAssets]);

  const fundingAccount = accounts[0];

  const handleTrade = () => {
    if (!selectedAsset) return;
    const amount = parseFloat(tradeAmount);
    if (isNaN(amount) || amount <= 0) {
      setFeedback({ msg: "Invalid quantity", type: 'error' });
      return;
    }
    const result = executeTrade(selectedAsset.id, tradeType, amount);
    setFeedback({ msg: result.message, type: result.success ? 'success' : 'error' });
  };

  return (
    <div className="space-y-6 pb-20">
      <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Trade Center</h1>
          <p className="text-xs text-brand-text-secondary uppercase font-bold tracking-widest">Global Markets</p>
        </div>
        <div className="relative">
           <input 
             type="text" 
             placeholder="Search assets..." 
             value={searchTerm}
             onChange={(e) => setSearchTerm(e.target.value)}
             className="w-full sm:w-64 bg-m3-surface border border-white/5 rounded-m3 px-10 py-2.5 text-sm focus:ring-1 focus:ring-m3-primary outline-none"
           />
           <div className="absolute left-3 top-2.5 opacity-50"><Icon name="list" className="w-5 h-5" /></div>
        </div>
      </header>

      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar py-2">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat as any)}
            className={`px-6 py-2 rounded-full text-xs font-bold transition-all whitespace-nowrap ${
              activeCategory === cat ? 'bg-m3-primary-container text-white shadow-lg' : 'bg-m3-surface text-brand-text-secondary border border-white/5'
            }`}
          >
            {cat.toUpperCase()}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {selectedAsset && (
            <Card className="!p-0 overflow-hidden relative border-m3-primary/10">
              <div className="p-6 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <AssetLogo logo={selectedAsset.logo} name={selectedAsset.name} ticker={selectedAsset.ticker} className="w-12 h-12" />
                  <div>
                    <h2 className="text-xl font-bold">{selectedAsset.name}</h2>
                    <p className="text-xs font-mono text-brand-text-secondary">{selectedAsset.ticker}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-black">${selectedAsset.price.toLocaleString()}</p>
                  <p className={`text-xs font-bold ${selectedAsset.change24h >= 0 ? 'text-brand-success' : 'text-brand-danger'}`}>
                    {selectedAsset.change24h >= 0 ? '↑' : '↓'} {selectedAsset.change24h_percent.toFixed(2)}%
                  </p>
                </div>
              </div>
              <div className="h-64 px-4 pb-4">
                <StockChart data={MOCK_CHART_DATA} positive={selectedAsset.change24h >= 0} />
              </div>
            </Card>
          )}

          <div className="space-y-4">
            <h3 className="text-sm font-bold text-brand-text-secondary uppercase tracking-widest px-1">Market Watchlist</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {filteredAssets.slice(0, 10).map(asset => (
                <button 
                  key={asset.id}
                  onClick={() => setSelectedAssetId(asset.id)}
                  className={`flex items-center gap-4 p-4 rounded-m3 transition-all border ${
                    selectedAssetId === asset.id ? 'bg-m3-primary-container/20 border-m3-primary/30' : 'bg-m3-surface border-white/5 hover:bg-white/5'
                  }`}
                >
                  <AssetLogo logo={asset.logo} name={asset.name} ticker={asset.ticker} className="w-10 h-10" />
                  <div className="text-left flex-1">
                    <p className="font-bold text-sm truncate">{asset.name}</p>
                    <p className="text-[10px] text-brand-text-secondary font-mono">{asset.ticker}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold">${asset.price.toFixed(2)}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <Card className="bg-m3-surface sticky top-6">
            <h3 className="text-lg font-bold mb-4">Execute Order</h3>
            
            <div className="flex bg-brand-bg p-1 rounded-m3 mb-6">
              <button 
                onClick={() => setTradeType('buy')}
                className={`flex-1 py-2 rounded-m3 text-xs font-bold transition-all ${tradeType === 'buy' ? 'bg-m3-primary-container text-white' : 'text-brand-text-secondary'}`}
              >BUY</button>
              <button 
                onClick={() => setTradeType('sell')}
                className={`flex-1 py-2 rounded-m3 text-xs font-bold transition-all ${tradeType === 'sell' ? 'bg-brand-danger text-white' : 'text-brand-text-secondary'}`}
              >SELL</button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-brand-text-secondary uppercase mb-2 block">Quantity</label>
                <input 
                  type="number"
                  value={tradeAmount}
                  onChange={(e) => setTradeAmount(e.target.value)}
                  className="w-full bg-brand-bg border border-white/10 rounded-m3 px-4 py-3 text-lg font-bold outline-none focus:border-m3-primary"
                />
              </div>

              <div className="p-4 bg-brand-bg/50 rounded-m3 space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-brand-text-secondary">Estimated Total</span>
                  <span className="font-bold">${(parseFloat(tradeAmount || '0') * (selectedAsset?.price || 0)).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-brand-text-secondary">Available Cash</span>
                  <span className="font-bold text-m3-primary">${fundingAccount?.balance.toLocaleString()}</span>
                </div>
              </div>

              {feedback && (
                <div className={`text-xs p-3 rounded-m3 text-center font-bold ${feedback.type === 'success' ? 'bg-brand-success/10 text-brand-success' : 'bg-brand-danger/10 text-brand-danger'}`}>
                  {feedback.msg}
                </div>
              )}

              <button 
                onClick={handleTrade}
                className={`w-full py-4 rounded-m3 font-bold shadow-lg active:scale-95 transition-all ${
                  tradeType === 'buy' ? 'bg-m3-primary-container text-white' : 'bg-brand-danger text-white'
                }`}
              >
                PLACE {tradeType.toUpperCase()} ORDER
              </button>
            </div>
          </Card>
          
          {selectedAsset && <StockNews name={selectedAsset.name} ticker={selectedAsset.ticker} />}
        </div>
      </div>
    </div>
  );
};

export default InvestPage;
