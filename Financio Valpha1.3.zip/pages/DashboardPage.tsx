
import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/common/Card';
import PortfolioChart from '../components/dashboard/PortfolioChart';
import AssetList from '../components/dashboard/AssetList';
import Icon from '../components/common/Icon';
import { useFinance } from '../context/FinanceContext';

const DashboardPage: React.FC = () => {
  const { assets, accounts } = useFinance();
  const navigate = useNavigate();
  
  const stats = useMemo(() => {
    const totalAssetValue = assets.reduce((sum, asset) => sum + asset.value, 0);
    const totalCashBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);
    const totalChangeValue = assets.reduce((sum, asset) => sum + (asset.change24h * asset.holdings), 0);
    const totalChangePercent = totalAssetValue > 0 ? (totalChangeValue / totalAssetValue) * 100 : 0;
    return { totalAssetValue, totalCashBalance, netWorth: totalAssetValue + totalCashBalance, totalChangePercent };
  }, [assets, accounts]);

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center mb-2">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Financify</h1>
          <p className="text-xs text-brand-text-secondary font-bold uppercase tracking-widest">Live Portfolio</p>
        </div>
        <div className="text-right">
            <p className="text-3xl font-black">${stats.netWorth.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
            <p className={`text-xs font-bold ${stats.totalChangePercent >= 0 ? 'text-brand-success' : 'text-brand-danger'}`}>
                {stats.totalChangePercent >= 0 ? '↑' : '↓'} {Math.abs(stats.totalChangePercent).toFixed(2)}% TODAY
            </p>
        </div>
      </header>

      {/* Quick Access Grid */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="!p-4 bg-m3-primary-container/20 border-m3-primary/10">
            <p className="text-[11px] font-bold text-m3-primary uppercase mb-1">Cash Balance</p>
            <p className="text-xl font-bold">${stats.totalCashBalance.toLocaleString()}</p>
        </Card>
        <Card className="!p-4 bg-emerald-500/10 border-emerald-500/10">
            <p className="text-[11px] font-bold text-brand-success uppercase mb-1">Total Assets</p>
            <p className="text-xl font-bold">${stats.totalAssetValue.toLocaleString()}</p>
        </Card>
      </div>

      <Card className="!p-0 overflow-hidden">
        <div className="p-6">
            <h2 className="text-lg font-bold">Performance</h2>
            <p className="text-xs text-brand-text-secondary">Historical market variance</p>
        </div>
        <div className="h-64">
          <PortfolioChart currentValue={stats.totalAssetValue} />
        </div>
      </Card>

      <div className="flex justify-between items-center mt-8">
          <h2 className="text-lg font-bold">Watchlist</h2>
          <button onClick={() => navigate('/invest')} className="text-xs font-bold text-m3-primary">VIEW ALL</button>
      </div>
      
      <AssetList assets={assets} />
    </div>
  );
};

export default DashboardPage;
