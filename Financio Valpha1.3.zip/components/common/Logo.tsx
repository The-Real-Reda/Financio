
import React from 'react';

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className = "w-10 h-10" }) => {
  return (
    <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#2EA043" />
          <stop offset="100%" stopColor="#238636" />
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="50" fill="url(#logoGradient)" />
      {/* Stylized F */}
      <path d="M35 25H75C77.7614 25 80 27.2386 80 30V35C80 37.7614 77.7614 40 75 40H45V50H70C72.7614 50 75 52.2386 75 55V60C75 62.7614 72.7614 65 70 65H45V75C45 77.7614 42.7614 80 40 80H35C32.2386 80 30 77.7614 30 75V30C30 27.2386 32.2386 25 35 25Z" fill="white" />
      {/* Dynamic Swoosh */}
      <path d="M85 25L45 75" stroke="white" strokeWidth="0" strokeOpacity="0.2" />
    </svg>
  );
};

export default Logo;
