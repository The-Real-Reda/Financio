
import React from 'react';

const LoadingScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-brand-bg flex flex-col items-center justify-center z-50">
      <div className="relative w-48 h-48">
        {/* Cat Body */}
        <div className="absolute bottom-10 left-10 w-24 h-28 bg-gray-400 rounded-t-full rounded-b-3xl transform -rotate-12"></div>
        
        {/* Cat Head */}
        <div className="absolute bottom-32 left-8 w-20 h-18 bg-gray-400 rounded-2xl">
            {/* Ears */}
            <div className="absolute -top-4 left-0 w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-b-[20px] border-b-gray-400 transform -rotate-12"></div>
            <div className="absolute -top-4 right-0 w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-b-[20px] border-b-gray-400 transform rotate-12"></div>
            
            {/* Eyes */}
            <div className="absolute top-6 left-4 w-3 h-3 bg-brand-bg rounded-full animate-blink">
                 <div className="w-1 h-1 bg-white rounded-full ml-1 mt-0.5"></div>
            </div>
            <div className="absolute top-6 right-4 w-3 h-3 bg-brand-bg rounded-full animate-blink">
                 <div className="w-1 h-1 bg-white rounded-full ml-1 mt-0.5"></div>
            </div>
            
            {/* Nose */}
            <div className="absolute top-10 left-1/2 transform -translate-x-1/2 w-2 h-1.5 bg-pink-400 rounded-b-full"></div>
        </div>

        {/* Tail */}
        <div className="absolute bottom-12 left-2 w-8 h-24 border-4 border-gray-400 rounded-full border-t-0 border-r-0 transform rotate-45 origin-bottom animate-tail"></div>

        {/* Paw */}
        <div className="absolute bottom-10 right-16 w-8 h-8 bg-gray-300 rounded-full z-10 animate-paw origin-top-left"></div>
        
        {/* Tissue Ball */}
        <div className="absolute bottom-8 right-4 w-10 h-10 bg-white rounded-full animate-ball shadow-lg flex items-center justify-center overflow-hidden">
            <div className="w-full h-px bg-gray-200 rotate-45 transform scale-150"></div>
            <div className="w-full h-px bg-gray-200 -rotate-45 transform scale-150"></div>
            <div className="w-full h-px bg-gray-200 rotate-90 transform scale-150"></div>
        </div>
      </div>
      
      <h2 className="mt-4 text-brand-primary font-bold text-xl tracking-widest animate-pulse">FINANCIFY</h2>
    </div>
  );
};

export default LoadingScreen;
