
import React, { useState, useRef, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { getChatResponse } from '../../services/geminiService';
import { Chat } from '@google/genai';
import Icon from './Icon';

const AIChatWidget: React.FC = () => {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{sender: 'user' | 'bot', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [hasUnread, setHasUnread] = useState(true);
  const chatRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Hide widget on Advisor page to prevent redundancy
  if (location.pathname === '/advisor') return null;

  const toggleChat = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      setHasUnread(false);
      if (messages.length === 0) {
        setMessages([{ sender: 'bot', text: 'Hi! I am Financio Support AI. How may I help you today?' }]);
      }
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) scrollToBottom();
  }, [messages, isOpen, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userText = input;
    setMessages(prev => [...prev, { sender: 'user', text: userText }]);
    setInput('');
    setIsLoading(true);

    try {
      if (!chatRef.current) {
        chatRef.current = getChatResponse("You are a helpful customer support agent for the Financio app. Keep responses concise.");
      }
      
      const stream = await chatRef.current.sendMessageStream({ message: userText });
      
      let botResponse = '';
      setMessages(prev => [...prev, { sender: 'bot', text: '' }]);
      
      for await (const chunk of stream) {
        if (chunk.text) {
             botResponse += chunk.text;
             setMessages(prev => {
                const newArr = [...prev];
                // Update the last message
                newArr[newArr.length - 1].text = botResponse;
                return newArr;
             });
        }
      }
    } catch (error) {
      setMessages(prev => {
          // Remove the empty placeholder if it failed immediately
          const newArr = prev.filter(m => m.text !== ''); 
          return [...newArr, { sender: 'bot', text: "I'm having trouble connecting right now. Please try again later." }];
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Chat Window */}
      {isOpen && (
        <div className="mb-4 w-80 sm:w-96 bg-brand-surface border border-brand-border rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-5 fade-in duration-200 origin-bottom-right">
          <div className="bg-brand-primary p-3 flex justify-between items-center">
            <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <h3 className="text-white font-bold text-sm">Financio Support</h3>
            </div>
            <button onClick={toggleChat} className="text-white/80 hover:text-white">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                 <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
               </svg>
            </button>
          </div>
          
          <div className="h-72 overflow-y-auto p-4 space-y-3 bg-brand-bg/95 backdrop-blur-sm">
             {messages.map((msg, idx) => {
               // Fix: Do not render empty bot messages (prevents double icon glitch while loading)
               if (msg.sender === 'bot' && !msg.text) return null;
               
               return (
                <div key={idx} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-3 rounded-2xl text-xs sm:text-sm shadow-sm ${
                        msg.sender === 'user' 
                        ? 'bg-brand-primary text-white rounded-tr-none' 
                        : 'bg-brand-surface border border-brand-border text-brand-text-primary rounded-tl-none'
                    }`}>
                        {msg.text}
                    </div>
                </div>
               );
             })}
             
             {isLoading && (
                 <div className="flex justify-start">
                     <div className="bg-brand-surface border border-brand-border p-3 rounded-2xl rounded-tl-none flex gap-1 shadow-sm">
                         <div className="w-1.5 h-1.5 bg-brand-text-secondary rounded-full animate-bounce"></div>
                         <div className="w-1.5 h-1.5 bg-brand-text-secondary rounded-full animate-bounce delay-75"></div>
                         <div className="w-1.5 h-1.5 bg-brand-text-secondary rounded-full animate-bounce delay-150"></div>
                     </div>
                 </div>
             )}
             <div ref={messagesEndRef}></div>
          </div>

          <div className="p-3 border-t border-brand-border bg-brand-surface">
            <div className="flex gap-2">
                <input 
                    type="text" 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Type a message..."
                    className="flex-1 bg-brand-bg border border-brand-border rounded-full px-4 py-2 text-xs sm:text-sm focus:outline-none focus:border-brand-primary text-white transition-colors"
                />
                <button 
                    onClick={handleSend}
                    disabled={!input.trim() || isLoading}
                    className="p-2 bg-brand-primary text-white rounded-full hover:bg-brand-secondary disabled:opacity-50 transition-colors shadow-md"
                >
                    <Icon name="send" className="w-4 h-4" />
                </button>
            </div>
          </div>
        </div>
      )}

      {/* Toggle Button - Smaller Size (w-12 h-12) */}
      <button 
        onClick={toggleChat}
        className="relative w-12 h-12 bg-brand-primary hover:bg-brand-secondary text-white rounded-full shadow-2xl flex items-center justify-center transition-all hover:scale-105 active:scale-95 group"
      >
        {hasUnread && !isOpen && (
            <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full border-2 border-brand-bg animate-bounce z-10"></span>
        )}
        {isOpen ? (
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
             </svg>
        ) : (
             <Icon name="advisor" className="w-6 h-6 group-hover:rotate-12 transition-transform" />
        )}
      </button>
    </div>
  );
};

export default AIChatWidget;
