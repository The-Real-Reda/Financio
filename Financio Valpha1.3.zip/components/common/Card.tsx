
import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '' }) => {
  return (
    <div className={`bg-brand-surface/80 backdrop-blur-md border border-white/5 rounded-2xl shadow-xl p-6 sm:p-8 hover:border-white/10 transition-colors duration-300 ${className}`}>
      {children}
    </div>
  );
};

export default Card;
