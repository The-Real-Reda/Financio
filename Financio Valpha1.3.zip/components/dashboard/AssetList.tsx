
import React from 'react';
import { Asset } from '../../types';
import AssetLogo from '../common/AssetLogo';

interface AssetListProps {
  assets: Asset[];
}

const AssetList: React.FC<AssetListProps> = ({ assets }) => {
  // Only show assets that have non-zero value or holdings in the list, 
  // unless user has no assets at all, then show all for demo
  const hasHoldings = assets.some(a => a.holdings > 0);
  const displayAssets = hasHoldings ? assets.filter(a => a.holdings > 0) : assets.slice(0, 5);

  const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
  };

  const formatChange = (value: number, percent: number) => {
    const isPositive = value >= 0;
    return (
      <span className={isPositive ? 'text-brand-success' : 'text-brand-danger'}>
        {isPositive ? '+' : ''}{formatCurrency(value)} ({percent.toFixed(2)}%)
      </span>
    );
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left">
        <thead className="border-b border-brand-border text-sm text-brand-text-secondary">
          <tr>
            <th className="py-3 px-4 font-medium">Asset</th>
            <th className="py-3 px-4 font-medium hidden md:table-cell">Price</th>
            <th className="py-3 px-4 font-medium hidden sm:table-cell">24h Change</th>
            <th className="py-3 px-4 font-medium">Holdings</th>
            <th className="py-3 px-4 font-medium text-right">Value</th>
          </tr>
        </thead>
        <tbody>
          {displayAssets.map((asset) => (
            <tr key={asset.id} className="border-b border-brand-border last:border-b-0 hover:bg-white/5 transition-colors">
              <td className="py-4 px-4">
                <div className="flex items-center gap-3">
                  <AssetLogo logo={asset.logo} name={asset.name} ticker={asset.ticker} className="w-10 h-10 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-brand-text-primary">{asset.name}</p>
                    <p className="text-xs text-brand-text-secondary font-mono">{asset.ticker}</p>
                  </div>
                </div>
              </td>
              <td className="py-4 px-4 hidden md:table-cell font-mono">{formatCurrency(asset.price)}</td>
              <td className="py-4 px-4 hidden sm:table-cell">{formatChange(asset.change24h, asset.change24h_percent)}</td>
              <td className="py-4 px-4 text-brand-text-primary">{asset.holdings > 0 ? asset.holdings : '-'}</td>
              <td className="py-4 px-4 text-right font-semibold text-brand-text-primary">{asset.value > 0 ? formatCurrency(asset.value) : '-'}</td>
            </tr>
          ))}
          {displayAssets.length === 0 && (
            <tr>
                <td colSpan={5} className="py-8 text-center text-brand-text-secondary">
                    You don't own any assets yet. Go to Invest to start trading.
                </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default AssetList;
