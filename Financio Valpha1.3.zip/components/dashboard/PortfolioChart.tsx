
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { MOCK_CHART_DATA } from '../../constants';

interface PortfolioChartProps {
  currentValue: number;
}

const PortfolioChart: React.FC<PortfolioChartProps> = ({ currentValue }) => {
  // If no value, show a flat line at 0
  let data;
  
  if (currentValue <= 0) {
    data = MOCK_CHART_DATA.map(d => ({ ...d, price: 0 }));
  } else {
    // Scale the mock pattern to match the current total value
    const lastMockValue = MOCK_CHART_DATA[MOCK_CHART_DATA.length - 1].price;
    const ratio = currentValue / lastMockValue;
    data = MOCK_CHART_DATA.map((d, i) => ({ 
        ...d, 
        price: d.price * ratio * (1 + Math.sin(i) * 0.05) // Add slight variation
    }));
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart
        data={data}
        margin={{
          top: 10,
          right: 10,
          left: 0,
          bottom: 0,
        }}
      >
        <defs>
          <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#238636" stopOpacity={0.6}/>
            <stop offset="95%" stopColor="#238636" stopOpacity={0}/>
          </linearGradient>
          <linearGradient id="strokeGradient" x1="0" y1="0" x2="1" y2="0">
             <stop offset="0%" stopColor="#2EA043" />
             <stop offset="100%" stopColor="#58A6FF" />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#30363D" vertical={false} />
        <XAxis 
          dataKey="date" 
          stroke="#8B949E" 
          tickLine={false}
          axisLine={false}
          tick={{fontSize: 12}}
          dy={10}
        />
        <YAxis 
          stroke="#8B949E" 
          tickLine={false}
          axisLine={false}
          tickFormatter={(value) => `$${(value).toLocaleString('en-US', { notation: "compact", maximumFractionDigits: 1 })}`} 
          tick={{fontSize: 12}}
        />
        <Tooltip
          contentStyle={{
            backgroundColor: 'rgba(22, 27, 34, 0.95)',
            borderColor: '#30363D',
            color: '#C9D1D9',
            borderRadius: '8px',
            boxShadow: '0 4px 6px rgba(0,0,0,0.3)'
          }}
          itemStyle={{ color: '#58A6FF' }}
          formatter={(value) => [`$${Number(value).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 'Portfolio Value']}
        />
        <Area 
          type="monotone" 
          dataKey="price" 
          stroke="url(#strokeGradient)" 
          strokeWidth={3}
          fillOpacity={1} 
          fill="url(#colorValue)" 
          animationDuration={1500}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
};

export default PortfolioChart;
