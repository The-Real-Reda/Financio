
import React from 'react';
import { UserProfile } from '../../types';

interface AccountWidgetProps {
  user: UserProfile | null;
  onLogout?: () => void;
  onAddAccount?: () => void;
  onOpenProfile?: () => void;
  compact?: boolean;
}

const AccountWidget: React.FC<AccountWidgetProps> = ({ user, onLogout, onAddAccount, onOpenProfile, compact = false }) => {
  const username = user?.name || 'Guest';
  const initial = username.charAt(0).toUpperCase();

  return (
    <div className={`flex flex-col gap-3 bg-brand-bg border border-brand-border rounded-xl p-4 shadow-sm`}>
      <div 
        className={`flex items-center gap-4 group cursor-pointer ${compact ? 'justify-center' : ''}`}
        onClick={onOpenProfile}
        title="View Profile"
      >
        <div className="relative">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-brand-success to-brand-primary flex items-center justify-center text-white font-bold text-3xl shadow-inner ring-2 ring-brand-surface overflow-hidden group-hover:ring-brand-primary/50 transition-all">
            {user?.avatar ? (
                <img src={user.avatar} alt={username} className="w-full h-full object-cover" />
            ) : (
                initial
            )}
          </div>
          <div className="absolute bottom-0 right-0 w-5 h-5 bg-green-500 border-4 border-brand-bg rounded-full"></div>
        </div>
        
        {!compact && (
          <div className="flex-1 min-w-0">
            <p className="text-lg font-bold text-brand-text-primary truncate group-hover:text-brand-primary transition-colors">{username}</p>
            <p className="text-sm text-brand-text-secondary truncate">Premium Member</p>
          </div>
        )}
      </div>

      {!compact && (
        <div className="grid grid-cols-2 gap-2 mt-2">
          <button 
            onClick={onAddAccount}
            className="text-sm bg-brand-surface hover:bg-brand-border text-brand-primary font-semibold py-2 px-2 rounded-lg transition-colors flex items-center justify-center gap-1"
          >
            + New
          </button>
          <button 
            onClick={onLogout}
            className="text-sm bg-brand-danger/10 hover:bg-brand-danger/20 text-brand-danger font-semibold py-2 px-2 rounded-lg transition-colors flex items-center justify-center gap-1"
          >
            Log Out
          </button>
        </div>
      )}
    </div>
  );
};

export default AccountWidget;
