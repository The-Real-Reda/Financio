
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import Icon from '../common/Icon';
import Logo from '../common/Logo';
import AccountWidget from './AccountWidget';
import { UserProfile } from '../../types';

interface SidebarProps {
  user: UserProfile | null;
  onLogout: () => void;
  onOpenProfile: () => void;
}

const navItems = [
  { name: 'Dashboard', path: '/', icon: 'dashboard' as const },
  { name: 'Invest', path: '/invest', icon: 'invest' as const },
  { name: 'Banking', path: '/banking', icon: 'banking' as const },
  { name: 'Sharia', path: '/sharia', icon: 'sharia' as const },
  { name: 'Advisor', path: '/advisor', icon: 'advisor' as const },
];

const Sidebar: React.FC<SidebarProps> = ({ user, onLogout, onOpenProfile }) => {
  const navigate = useNavigate();

  const handleAddAccountNavigation = () => {
    // Navigate to banking with a flag to open the modal
    navigate('/banking', { state: { openAddModal: true } });
  };

  return (
    <aside className="w-24 lg:w-72 bg-brand-surface border-r border-white/5 flex flex-col justify-between transition-all duration-300 z-20">
      <div className="flex flex-col h-full">
        {/* Logo Area */}
        <div className="h-28 flex items-center justify-center lg:justify-start lg:pl-8 gap-4 mb-4">
          <Logo className="w-10 h-10 lg:w-12 lg:h-12 flex-shrink-0" />
          <h1 className="text-2xl font-bold hidden lg:block tracking-tight text-white">Financio</h1>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 space-y-2">
          {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center justify-center lg:justify-start px-2 lg:px-4 py-3 rounded-2xl transition-all duration-200 group relative overflow-hidden ${
                  isActive
                    ? 'bg-brand-primary text-white shadow-lg shadow-brand-primary/20'
                    : 'text-brand-text-secondary hover:bg-white/5 hover:text-white'
                }`
              }
            >
              <Icon name={item.icon} className={`w-5 h-5 z-10 ${({isActive}: any) => isActive ? 'text-white' : ''}`} />
              <span className="ml-4 font-medium hidden lg:block z-10 text-sm">{item.name}</span>
            </NavLink>
          ))}
        </nav>

        {/* Bottom / Account Area */}
        <div className="p-4 lg:p-6 border-t border-white/5 space-y-4 bg-brand-bg/30">
          <div className="hidden lg:block">
             <AccountWidget 
               user={user} 
               onLogout={onLogout} 
               onAddAccount={handleAddAccountNavigation}
               onOpenProfile={onOpenProfile}
             />
          </div>
          <div className="lg:hidden flex flex-col gap-4 items-center">
              <button 
                  onClick={onOpenProfile}
                  className="w-10 h-10 rounded-full bg-gradient-to-br from-brand-success to-brand-primary flex items-center justify-center text-white font-bold text-lg overflow-hidden hover:ring-2 hover:ring-white/20 transition-all"
              >
                {user?.avatar ? (
                     <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                ) : (
                    user ? user.name.charAt(0).toUpperCase() : 'G'
                )}
              </button>

              <button
                onClick={onLogout}
                className="w-full flex items-center justify-center p-3 rounded-xl transition-colors duration-200 text-brand-text-secondary hover:bg-brand-danger/20 hover:text-brand-danger"
              >
                <Icon name="logout" className="w-6 h-6" />
              </button>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
