
import React from 'react';
import { NavLink } from 'react-router-dom';
import Icon from '../common/Icon';
import { UserProfile } from '../../types';

interface BottomNavProps {
  user: UserProfile | null;
  onLogout: () => void;
  onOpenProfile: () => void;
}

const navItems = [
  { name: 'Home', path: '/', icon: 'dashboard' as const },
  { name: 'Trade', path: '/invest', icon: 'invest' as const },
  { name: 'Bank', path: '/banking', icon: 'banking' as const },
  { name: 'Sharia', path: '/sharia', icon: 'sharia' as const },
  { name: 'AI', path: '/advisor', icon: 'advisor' as const },
];

const BottomNav: React.FC<BottomNavProps> = ({ user, onOpenProfile }) => {
  return (
    <>
      {/* Mobile Bottom Navigation (M3 Style) */}
      <nav className="fixed bottom-0 left-0 right-0 h-20 bg-m3-surface border-t border-white/5 flex items-center justify-around px-2 z-40 lg:hidden">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center flex-1 transition-all duration-300 gap-1 ${
                isActive ? 'text-m3-primary' : 'text-brand-text-secondary'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <div className={`px-5 py-1 m3-pill transition-all ${isActive ? 'bg-m3-primary-container' : ''}`}>
                  <Icon name={item.icon} className={`w-6 h-6 ${isActive ? 'text-white' : ''}`} />
                </div>
                <span className={`text-[11px] font-bold tracking-tight ${isActive ? 'text-white' : ''}`}>
                  {item.name}
                </span>
              </>
            )}
          </NavLink>
        ))}
        <button 
          onClick={onOpenProfile}
          className="flex-1 flex flex-col items-center justify-center gap-1"
        >
          <div className="w-8 h-8 rounded-full bg-brand-primary/20 border border-brand-primary/40 overflow-hidden">
            {user?.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : <span className="text-xs font-bold">{user?.name[0]}</span>}
          </div>
          <span className="text-[11px] font-bold text-brand-text-secondary">Profile</span>
        </button>
      </nav>

      {/* Desktop Side Bar (Mini Drawer) */}
      <nav className="fixed left-0 top-0 bottom-0 w-20 bg-m3-surface border-r border-white/5 hidden lg:flex flex-col items-center py-8 z-40">
        <div className="mb-12">
            <div className="w-12 h-12 bg-m3-primary-container rounded-m3 flex items-center justify-center text-white font-bold text-xl">F</div>
        </div>
        <div className="flex-1 flex flex-col gap-8">
            {navItems.map((item) => (
                <NavLink
                    key={item.name}
                    to={item.path}
                    title={item.name}
                    className={({ isActive }) =>
                        `p-3 rounded-m3 transition-all ${isActive ? 'bg-m3-primary-container text-white' : 'text-brand-text-secondary hover:bg-white/5'}`
                    }
                >
                    <Icon name={item.icon} className="w-6 h-6" />
                </NavLink>
            ))}
        </div>
        <button onClick={onOpenProfile} className="mt-auto w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 overflow-hidden ring-2 ring-brand-primary/20">
             {user?.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : <span className="text-sm font-bold">{user?.name[0]}</span>}
        </button>
      </nav>
    </>
  );
};

export default BottomNav;
