
import React, { useState, useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import BottomNav from './components/layout/BottomNav';
import DashboardPage from './pages/DashboardPage';
import InvestPage from './pages/InvestPage';
import BankingPage from './pages/BankingPage';
import AdvisorPage from './pages/AdvisorPage';
import ShariaPage from './pages/ShariaPage';
import LoginPage from './pages/LoginPage';
import AIChatWidget from './components/common/AIChatWidget';
import LoadingScreen from './components/common/LoadingScreen';
import ProfileModal from './components/profile/ProfileModal';
import { useGeolocation } from './hooks/useGeolocation';
import { FinanceProvider } from './context/FinanceContext';
import { AuthProvider, useAuth } from './context/AuthContext';

const AuthenticatedApp: React.FC = () => {
  const { user, logout } = useAuth();
  const { location, error, requestLocation } = useGeolocation();
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (user) requestLocation();
  }, [user]);

  if (loading) return <LoadingScreen />;
  if (!user) return <LoginPage />;

  return (
    <FinanceProvider>
      <div className="flex flex-col h-screen bg-brand-bg relative overflow-hidden">
        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto pb-24 lg:pb-8 lg:pl-24 px-4 sm:px-6 pt-6">
          <div className="max-w-6xl mx-auto">
            <Routes>
              <Route path="/" element={<DashboardPage />} />
              <Route path="/invest" element={<InvestPage />} />
              <Route path="/banking" element={<BankingPage />} />
              <Route path="/sharia" element={<ShariaPage />} />
              <Route path="/advisor" element={<AdvisorPage location={location} locationError={error} />} />
            </Routes>
          </div>
        </main>

        {/* Universal Navigation */}
        <BottomNav 
            user={user} 
            onLogout={logout} 
            onOpenProfile={() => setIsProfileOpen(true)}
        />

        <AIChatWidget />
        
        <ProfileModal 
            isOpen={isProfileOpen} 
            onClose={() => setIsProfileOpen(false)} 
        />
      </div>
    </FinanceProvider>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
        <AuthenticatedApp />
    </AuthProvider>
  );
};

export default App;
