
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserProfile } from '../types';

interface AuthContextType {
  user: UserProfile | null;
  login: (email: string, password: string) => Promise<{ success: boolean; message: string }>;
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; message: string }>;
  logout: () => void;
  updateProfile: (data: Partial<UserProfile>) => Promise<{ success: boolean; message: string }>;
  resetPassword: (email: string) => Promise<{ success: boolean; message: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Mock "Database" keys
const USERS_KEY = 'financify_users';
const SESSION_KEY = 'financify_session';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Load session on mount
  useEffect(() => {
    const session = localStorage.getItem(SESSION_KEY);
    if (session) {
      setUser(JSON.parse(session));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));

    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const foundUser = users.find((u: any) => u.email === email && u.password === password);

    if (foundUser) {
      const { password, ...userProfile } = foundUser;
      setUser(userProfile);
      localStorage.setItem(SESSION_KEY, JSON.stringify(userProfile));
      return { success: true, message: 'Logged in successfully' };
    }
    
    // Default demo login
    if (email === 'demo' && password === 'demo') {
       const demoUser: UserProfile = {
           id: 'demo-1',
           name: 'Demo User',
           email: 'demo@financify.app',
           joinedDate: new Date().toISOString()
       };
       setUser(demoUser);
       localStorage.setItem(SESSION_KEY, JSON.stringify(demoUser));
       return { success: true, message: 'Logged in as Demo User' };
    }

    return { success: false, message: 'Invalid email or password' };
  };

  const register = async (name: string, email: string, password: string) => {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    
    if (users.find((u: any) => u.email === email)) {
      return { success: false, message: 'Email already exists' };
    }

    const newUser = {
      id: Date.now().toString(),
      name,
      email,
      password, // In a real app, never store plain text passwords
      joinedDate: new Date().toISOString()
    };

    users.push(newUser);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));

    // Auto login after register
    const { password: _, ...userProfile } = newUser;
    setUser(userProfile);
    localStorage.setItem(SESSION_KEY, JSON.stringify(userProfile));

    return { success: true, message: 'Account created successfully' };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(SESSION_KEY);
  };

  const updateProfile = async (data: Partial<UserProfile>) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    if (!user) return { success: false, message: 'No user logged in' };

    const updatedUser = { ...user, ...data };
    setUser(updatedUser);
    localStorage.setItem(SESSION_KEY, JSON.stringify(updatedUser));

    // Update in "Database"
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const updatedUsers = users.map((u: any) => u.id === user.id ? { ...u, ...data } : u);
    localStorage.setItem(USERS_KEY, JSON.stringify(updatedUsers));

    return { success: true, message: 'Profile updated successfully' };
  };

  const resetPassword = async (email: string) => {
     await new Promise(resolve => setTimeout(resolve, 1000));
     return { success: true, message: `Password reset link sent to ${email}` };
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, updateProfile, resetPassword }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
