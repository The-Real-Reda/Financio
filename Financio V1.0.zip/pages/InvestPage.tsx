
import React, { useState, useEffect, useMemo } from 'react';
import { MOCK_CHART_DATA } from '../constants';
import Card from '../components/common/Card';
import StockChart from '../components/invest/StockChart';
import StockNews from '../components/invest/StockNews';
import { Asset, AssetType } from '../types';
import { useFinance } from '../context/FinanceContext';
import { useLocation } from 'react-router-dom';
import Icon from '../components/common/Icon';
import AssetLogo from '../components/common/AssetLogo';

const InvestPage: React.FC = () => {
  const { assets, executeTrade, accounts } = useFinance();
  const location = useLocation();
  
  // Selection State
  const [selectedAssetId, setSelectedAssetId] = useState<string>(assets[0]?.id || '');
  const [activeCategory, setActiveCategory] = useState<'All' | AssetType>('All');
  const [searchTerm, setSearchTerm] = useState('');

  // Trade Panel State
  const [tradeMode, setTradeMode] = useState<'spot' | 'options'>('spot');
  const [tradeType, setTradeType] = useState<'buy' | 'sell'>('buy');
  const [orderType, setOrderType] = useState<'market' | 'limit' | 'stop'>('market');
  const [tradeAmount, setTradeAmount] = useState('1');
  
  // Options specific fields
  const [optionType, setOptionType] = useState<'call' | 'put'>('call');
  const [strikePrice, setStrikePrice] = useState('');
  const [expiryDate, setExpiryDate] = useState('2025-06-20');

  const [feedback, setFeedback] = useState<{msg: string, type: 'success' | 'error'} | null>(null);

  const categories = ['All', AssetType.Stock, AssetType.Crypto, AssetType.Commodity, AssetType.Managed, AssetType.Fund];

  useEffect(() => {
    if (location.state?.assetId) {
       setSelectedAssetId(location.state.assetId);
    }
  }, [location.state?.assetId]);

  const filteredAssets = useMemo(() => {
    const term = searchTerm.toLowerCase();
    return assets.filter(a => {
      const matchesSearch = a.name.toLowerCase().includes(term) || a.ticker.toLowerCase().includes(term);
      const matchesCategory = activeCategory === 'All' || a.type === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [assets, searchTerm, activeCategory]);

  const selectedAsset = useMemo(() => {
    return assets.find(a => a.id === selectedAssetId) || assets[0];
  }, [assets, selectedAssetId]);

  const watchlistAssets = useMemo(() => {
    return assets.filter(a => a.change24h_percent > 0).slice(0, 6);
  }, [assets]);

  const fundingAccount = accounts[0];

  const handleTrade = () => {
    if (!selectedAsset) return;
    const amount = parseFloat(tradeAmount);
    if (isNaN(amount) || amount <= 0) {
      setFeedback({ msg: "Invalid quantity", type: 'error' });
      return;
    }

    // In a real app, options trading would have its own logic. 
    // Here we simulate it by adjusting the transaction description.
    let description = `${tradeType.toUpperCase()} ${amount} ${selectedAsset.ticker}`;
    if (tradeMode === 'options') {
      description = `${tradeType.toUpperCase()} ${optionType.toUpperCase()} OPTION: ${amount} ${selectedAsset.ticker} @ $${strikePrice} Exp: ${expiryDate}`;
    }

    const result = executeTrade(selectedAsset.id, tradeType, amount);
    setFeedback({ msg: result.message, type: result.success ? 'success' : 'error' });
    setTimeout(() => setFeedback(null), 3000);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Ticker Animation */}
      <div className="w-full bg-brand-surface border-b border-white/5 py-2 overflow-hidden whitespace-nowrap relative -mx-4 px-4 sm:-mx-6 sm:px-6">
        <div className="flex animate-marquee items-center gap-8">
            {[...assets, ...assets].map((asset, i) => (
                <div key={`${asset.id}-${i}`} className="flex items-center gap-2 text-xs font-bold">
                    <span className="text-brand-text-primary">{asset.ticker}</span>
                    <span className="text-white">${asset.price.toFixed(2)}</span>
                    <span className={asset.change24h >= 0 ? 'text-brand-success' : 'text-brand-danger'}>
                        {asset.change24h >= 0 ? '▲' : '▼'} {Math.abs(asset.change24h_percent).toFixed(2)}%
                    </span>
                </div>
            ))}
        </div>
      </div>
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 40s linear infinite;
        }
      `}</style>

      <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Market Terminal</h1>
          <p className="text-[10px] text-brand-text-secondary uppercase font-black tracking-[0.2em] opacity-60">Global Asset Marketplace</p>
        </div>
        <div className="relative">
           <input 
             type="text" 
             placeholder="Search markets..." 
             value={searchTerm}
             onChange={(e) => setSearchTerm(e.target.value)}
             className="w-full sm:w-64 bg-brand-surface border border-white/10 rounded-xl px-10 py-2.5 text-sm focus:ring-1 focus:ring-brand-primary outline-none text-white transition-all shadow-inner"
           />
           <div className="absolute left-3 top-2.5 text-brand-text-secondary"><Icon name="list" className="w-5 h-5" /></div>
        </div>
      </header>

      {/* Categories & Full List */}
      <div className="space-y-4">
        <div className="flex gap-2 overflow-x-auto no-scrollbar py-2">
            {categories.map(cat => (
            <button
                key={cat}
                onClick={() => setActiveCategory(cat as any)}
                className={`px-6 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap border ${
                activeCategory === cat ? 'bg-brand-primary border-brand-primary text-white shadow-lg' : 'bg-brand-surface text-brand-text-secondary border-white/5 hover:bg-white/5'
                }`}
            >
                {cat.toUpperCase()}
            </button>
            ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {filteredAssets.map(asset => (
                <button 
                  key={asset.id}
                  onClick={() => setSelectedAssetId(asset.id)}
                  className={`flex items-center gap-4 p-4 rounded-xl transition-all border ${
                    selectedAssetId === asset.id ? 'bg-brand-primary/10 border-brand-primary/40 shadow-lg' : 'bg-brand-surface border-white/5 hover:bg-white/5'
                  }`}
                >
                  <AssetLogo logo={asset.logo} name={asset.name} ticker={asset.ticker} className="w-10 h-10" />
                  <div className="text-left flex-1 min-w-0">
                    <p className="font-bold text-sm truncate text-white">{asset.name}</p>
                    <div className="flex items-center gap-1.5">
                        <p className="text-[10px] text-brand-text-secondary font-mono">{asset.ticker}</p>
                        {asset.type === AssetType.Managed && (
                            <span className="text-[8px] bg-brand-primary/20 text-brand-primary px-1.5 rounded font-black uppercase tracking-tighter">EXPERT</span>
                        )}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-white">${asset.price.toFixed(2)}</p>
                  </div>
                </button>
            ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Detail View */}
        <div className="lg:col-span-8 space-y-6">
          {selectedAsset && (
            <Card className="!p-0 overflow-hidden relative border-white/5 shadow-2xl bg-brand-surface/50">
              <div className="p-6 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <AssetLogo logo={selectedAsset.logo} name={selectedAsset.name} ticker={selectedAsset.ticker} className="w-14 h-14" />
                  <div>
                    <h2 className="text-2xl font-bold text-white">{selectedAsset.name}</h2>
                    <p className="text-xs font-mono text-brand-text-secondary">{selectedAsset.ticker} / USD</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-black text-white">${selectedAsset.price.toLocaleString()}</p>
                  <p className={`text-sm font-bold ${selectedAsset.change24h >= 0 ? 'text-brand-success' : 'text-brand-danger'}`}>
                    {selectedAsset.change24h >= 0 ? '↑' : '↓'} {Math.abs(selectedAsset.change24h_percent).toFixed(2)}%
                  </p>
                </div>
              </div>
              <div className="h-80 px-4 pb-4">
                <StockChart data={MOCK_CHART_DATA} positive={selectedAsset.change24h >= 0} />
              </div>
            </Card>
          )}

          <div className="pt-2">
              {selectedAsset && <StockNews name={selectedAsset.name} ticker={selectedAsset.ticker} />}
          </div>
        </div>

        {/* Order Panel */}
        <div className="lg:col-span-4 space-y-6">
          <Card className="bg-brand-surface border-white/10 shadow-2xl relative">
            <h3 className="text-lg font-bold text-white mb-4">Execute Order</h3>
            
            {/* Mode Toggle: Spot vs Options */}
            <div className="flex bg-brand-bg p-1 rounded-xl mb-6">
              <button 
                onClick={() => setTradeMode('spot')}
                className={`flex-1 py-2 rounded-lg text-xs font-black tracking-widest transition-all ${tradeMode === 'spot' ? 'bg-brand-surface text-brand-primary shadow-sm' : 'text-brand-text-secondary'}`}
              >SPOT</button>
              <button 
                onClick={() => setTradeMode('options')}
                className={`flex-1 py-2 rounded-lg text-xs font-black tracking-widest transition-all ${tradeMode === 'options' ? 'bg-brand-surface text-brand-primary shadow-sm' : 'text-brand-text-secondary'}`}
              >OPTIONS</button>
            </div>

            <div className="flex bg-brand-bg p-1 rounded-xl mb-4">
              <button 
                onClick={() => setTradeType('buy')}
                className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${tradeType === 'buy' ? 'bg-brand-success text-white' : 'text-brand-text-secondary'}`}
              >BUY</button>
              <button 
                onClick={() => setTradeType('sell')}
                className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${tradeType === 'sell' ? 'bg-brand-danger text-white' : 'text-brand-text-secondary'}`}
              >SELL</button>
            </div>

            <div className="space-y-4">
              {/* Order Type Selector */}
              <div>
                <label className="text-[10px] font-bold text-brand-text-secondary uppercase mb-2 block tracking-widest">Order Type</label>
                <select 
                    value={orderType}
                    onChange={(e) => setOrderType(e.target.value as any)}
                    className="w-full bg-brand-bg border border-white/10 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-brand-primary text-white"
                >
                    <option value="market">Market Order</option>
                    <option value="limit">Limit Order</option>
                    <option value="stop">Stop Loss</option>
                </select>
              </div>

              {/* Specific Options Inputs */}
              {tradeMode === 'options' && (
                <div className="space-y-4 p-4 bg-brand-bg/40 rounded-xl border border-white/5 animate-in slide-in-from-top-2">
                    <div className="flex gap-2">
                        <button 
                            onClick={() => setOptionType('call')}
                            className={`flex-1 py-2 rounded-lg text-[10px] font-black transition-all border ${optionType === 'call' ? 'border-brand-success bg-brand-success/10 text-brand-success' : 'border-white/5 text-brand-text-secondary'}`}
                        >CALL</button>
                        <button 
                            onClick={() => setOptionType('put')}
                            className={`flex-1 py-2 rounded-lg text-[10px] font-black transition-all border ${optionType === 'put' ? 'border-brand-danger bg-brand-danger/10 text-brand-danger' : 'border-white/5 text-brand-text-secondary'}`}
                        >PUT</button>
                    </div>
                    <div>
                        <label className="text-[9px] font-bold text-brand-text-secondary uppercase mb-1 block tracking-widest">Strike Price ($)</label>
                        <input 
                            type="number"
                            value={strikePrice}
                            onChange={(e) => setStrikePrice(e.target.value)}
                            placeholder={selectedAsset?.price.toFixed(0)}
                            className="w-full bg-brand-bg border border-white/10 rounded-lg px-3 py-2 text-sm font-bold text-white outline-none focus:border-brand-primary"
                        />
                    </div>
                    <div>
                        <label className="text-[9px] font-bold text-brand-text-secondary uppercase mb-1 block tracking-widest">Expiration</label>
                        <input 
                            type="date"
                            value={expiryDate}
                            onChange={(e) => setExpiryDate(e.target.value)}
                            className="w-full bg-brand-bg border border-white/10 rounded-lg px-3 py-2 text-sm font-bold text-white outline-none focus:border-brand-primary"
                        />
                    </div>
                </div>
              )}

              <div>
                <label className="text-[10px] font-bold text-brand-text-secondary uppercase mb-2 block tracking-widest">
                    {tradeMode === 'options' ? 'Contracts' : 'Order Quantity'}
                </label>
                <input 
                  type="number"
                  value={tradeAmount}
                  onChange={(e) => setTradeAmount(e.target.value)}
                  className="w-full bg-brand-bg border border-white/10 rounded-xl px-4 py-4 text-xl font-bold outline-none focus:border-brand-primary text-white shadow-inner"
                />
              </div>

              <div className="p-4 bg-brand-bg/50 rounded-xl space-y-2 border border-white/5">
                <div className="flex justify-between text-xs">
                  <span className="text-brand-text-secondary">Est. Cost</span>
                  <span className="font-bold text-white">${(parseFloat(tradeAmount || '0') * (selectedAsset?.price || 0)).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-brand-text-secondary">Balance Available</span>
                  <span className="font-bold text-brand-success">${fundingAccount?.balance.toLocaleString() || '0'}</span>
                </div>
              </div>

              {feedback && (
                <div className={`text-xs p-3 rounded-xl text-center font-bold animate-in fade-in slide-in-from-top-1 ${feedback.type === 'success' ? 'bg-brand-success/10 text-brand-success' : 'bg-brand-danger/10 text-brand-danger'}`}>
                  {feedback.msg}
                </div>
              )}

              <button 
                onClick={handleTrade}
                className={`w-full py-4 rounded-xl font-black shadow-xl active:scale-95 transition-all text-xs tracking-[0.2em] ${
                  tradeType === 'buy' ? 'bg-brand-success text-white' : 'bg-brand-danger text-white'
                }`}
              >
                CONFIRM {tradeMode === 'options' ? `${optionType.toUpperCase()} OPTION` : tradeType.toUpperCase()}
              </button>
            </div>
          </Card>

          {/* Watchlist Section */}
          <div className="space-y-4">
             <h3 className="text-[10px] font-black text-brand-text-secondary uppercase tracking-[0.2em] px-1">Watchlist</h3>
             <div className="space-y-2">
                {watchlistAssets.map(asset => (
                    <div 
                        key={asset.id} 
                        onClick={() => setSelectedAssetId(asset.id)}
                        className="flex items-center justify-between p-3 bg-brand-surface border border-white/5 rounded-xl cursor-pointer hover:bg-white/5 transition-all group"
                    >
                        <div className="flex items-center gap-3">
                            <AssetLogo logo={asset.logo} name={asset.name} ticker={asset.ticker} className="w-8 h-8 opacity-80 group-hover:opacity-100 transition-opacity" />
                            <div>
                                <p className="text-xs font-bold text-white">{asset.ticker}</p>
                                <p className="text-[9px] text-brand-text-secondary truncate w-24">{asset.name}</p>
                            </div>
                        </div>
                        <div className="text-right">
                            <p className="text-xs font-bold text-white">${asset.price.toFixed(2)}</p>
                            <p className="text-[9px] font-bold text-brand-success">+{asset.change24h_percent.toFixed(2)}%</p>
                        </div>
                    </div>
                ))}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvestPage;
