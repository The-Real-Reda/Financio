
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/common/Card';
import Icon from '../components/common/Icon';
import AssetLogo from '../components/common/AssetLogo';
import { useFinance } from '../context/FinanceContext';

const ShariaPage: React.FC = () => {
  const { assets } = useFinance();
  const navigate = useNavigate();
  
  // Filter for specific Sharia compliant funds
  const shariaTickers = ['SPUS', 'HLAL', 'SPRE', 'UMMA', 'AMAL'];
  const shariaFunds = assets.filter(a => shariaTickers.includes(a.ticker));

  const handleLearnMore = () => {
    navigate('/advisor', { 
        state: { autoQuery: "Can you explain the principles of Sharia compliant investing and how funds like SPRE, HLAL, SPUS, UMMA, and AMAL work?" } 
    });
  };

  return (
    <div className="space-y-8 pb-20">
      <div className="flex items-center gap-3">
        <div className="p-3 bg-brand-primary/20 rounded-xl">
             <Icon name="sharia" className="w-8 h-8 text-brand-primary" />
        </div>
        <div>
            <h1 className="text-3xl font-bold text-brand-text-primary">Sharia Compliant Investing</h1>
            <p className="text-brand-text-secondary">Ethical investment options aligned with Islamic principles (S&P & ETFs).</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
         {shariaFunds.map(fund => (
             <Card key={fund.id} className="flex flex-col h-full hover:border-brand-primary/50 transition-colors group">
                 <div className="flex justify-between items-start mb-4">
                     <AssetLogo name={fund.name} ticker={fund.ticker} logo={fund.logo} className="w-12 h-12" />
                     <div className={`px-3 py-1 rounded-full text-sm font-bold ${fund.change24h_percent >= 0 ? 'bg-brand-success/10 text-brand-success' : 'bg-brand-danger/10 text-brand-danger'}`}>
                        {fund.change24h_percent >= 0 ? '+' : ''}{fund.change24h_percent.toFixed(2)}%
                     </div>
                 </div>
                 <h2 className="text-xl font-bold mb-1 group-hover:text-brand-primary transition-colors">{fund.ticker}</h2>
                 <p className="text-sm text-brand-text-primary font-medium mb-2">{fund.name}</p>
                 <p className="text-sm text-brand-text-secondary mb-6 flex-1">
                    {fund.ticker === 'SPUS' ? 'Tracks the S&P 500 Shariah Industry Exclusions Index.' : 
                     fund.ticker === 'HLAL' ? 'Exposure to US Large and Mid Cap Shariah-compliant equities.' :
                     fund.ticker === 'SPRE' ? 'Sharia-compliant Real Estate Investment Trusts.' :
                     fund.ticker === 'UMMA' ? 'Focuses on Sharia-compliant companies from developed and emerging markets globally.' :
                     'A Sharia-compliant approach to high-yield blue-chip companies with ethical filters.'}
                 </p>
                 
                 <div className="flex justify-between items-end border-t border-brand-border pt-4">
                     <div>
                         <p className="text-xs text-brand-text-secondary">Current Price</p>
                         <p className="text-2xl font-bold">${fund.price.toFixed(2)}</p>
                     </div>
                     <button 
                        onClick={() => navigate('/invest', { state: { assetId: fund.id } })}
                        className="bg-brand-primary hover:bg-brand-secondary text-white font-bold py-2 px-6 rounded-lg transition-colors shadow-lg active:scale-95"
                     >
                         Trade
                     </button>
                 </div>
             </Card>
         ))}
      </div>

      <Card className="bg-gradient-to-r from-brand-surface to-brand-bg border-brand-primary/20 shadow-2xl">
          <div className="flex flex-col md:flex-row items-center gap-6 p-2">
              <div className="flex-1">
                  <h3 className="text-xl font-bold mb-2 text-white">Why Sharia Compliant?</h3>
                  <ul className="space-y-2 text-brand-text-secondary">
                      <li className="flex items-center gap-2">
                          <span className="w-2 h-2 bg-brand-success rounded-full"></span>
                          Excludes interest-based income (Riba)
                      </li>
                      <li className="flex items-center gap-2">
                          <span className="w-2 h-2 bg-brand-success rounded-full"></span>
                          No gambling, alcohol, or tobacco industries
                      </li>
                      <li className="flex items-center gap-2">
                          <span className="w-2 h-2 bg-brand-success rounded-full"></span>
                          Low debt-to-equity ratio requirements
                      </li>
                  </ul>
              </div>
              <div className="w-full md:w-auto">
                  <button 
                    onClick={handleLearnMore}
                    className="w-full md:w-auto bg-brand-surface border border-brand-border hover:border-brand-primary/40 text-brand-text-primary font-semibold py-3 px-8 rounded-xl transition-all flex items-center justify-center gap-2 group active:scale-95"
                  >
                      <Icon name="advisor" className="w-5 h-5 group-hover:scale-110 transition-transform" />
                      Learn More via Advisor
                  </button>
              </div>
          </div>
      </Card>
    </div>
  );
};

export default ShariaPage;
