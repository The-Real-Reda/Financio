
import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/common/Card';
import PortfolioChart from '../components/dashboard/PortfolioChart';
import AssetList from '../components/dashboard/AssetList';
import Icon from '../components/common/Icon';
import { useFinance } from '../context/FinanceContext';

const DashboardPage: React.FC = () => {
  const { assets, accounts } = useFinance();
  const navigate = useNavigate();
  
  const stats = useMemo(() => {
    const totalAssetValue = assets.reduce((sum, asset) => sum + asset.value, 0);
    const totalCashBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);
    const totalChangeValue = assets.reduce((sum, asset) => sum + (asset.change24h * asset.holdings), 0);
    const totalChangePercent = totalAssetValue > 0 ? (totalChangeValue / totalAssetValue) * 100 : 0;
    return { totalAssetValue, totalCashBalance, netWorth: totalAssetValue + totalCashBalance, totalChangePercent };
  }, [assets, accounts]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <header className="flex justify-between items-end mb-4 px-1">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-xs text-brand-text-secondary">Overview of your global portfolio</p>
        </div>
        <div className="text-right">
            <p className="text-3xl font-black text-white">${stats.netWorth.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
            <p className={`text-xs font-bold ${stats.totalChangePercent >= 0 ? 'text-brand-success' : 'text-brand-danger'}`}>
                {stats.totalChangePercent >= 0 ? '▲' : '▼'} {Math.abs(stats.totalChangePercent).toFixed(2)}%
            </p>
        </div>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-6 rounded-2xl bg-brand-surface border border-brand-border hover:border-brand-primary/30 transition-all cursor-pointer shadow-lg">
            <div className="flex items-center gap-3 mb-2">
                <Icon name="banking" className="w-5 h-5 text-brand-primary" />
                <p className="text-[10px] font-bold text-brand-text-secondary uppercase tracking-widest">Available Cash</p>
            </div>
            <p className="text-2xl font-bold text-white">${stats.totalCashBalance.toLocaleString()}</p>
        </div>

        <div className="p-6 rounded-2xl bg-brand-surface border border-brand-primary/20 hover:border-brand-primary transition-all cursor-pointer shadow-xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-brand-primary/5 rounded-full -mr-8 -mt-8 blur-2xl group-hover:bg-brand-primary/10 transition-colors"></div>
            <div className="flex items-center gap-3 mb-2">
                <Icon name="dashboard" className="w-5 h-5 text-brand-primary" />
                <p className="text-[10px] font-bold text-brand-text-secondary uppercase tracking-widest">Total Net Worth</p>
            </div>
            <p className="text-3xl font-black text-white">${stats.netWorth.toLocaleString()}</p>
        </div>
        
        <div className="p-6 rounded-2xl bg-brand-surface border border-brand-border hover:border-brand-success/30 transition-all cursor-pointer shadow-lg">
            <div className="flex items-center gap-3 mb-2">
                <Icon name="invest" className="w-5 h-5 text-brand-success" />
                <p className="text-[10px] font-bold text-brand-text-secondary uppercase tracking-widest">Invested Value</p>
            </div>
            <p className="text-2xl font-bold text-white">${stats.totalAssetValue.toLocaleString()}</p>
        </div>
      </div>

      <Card className="!p-0 overflow-hidden shadow-2xl">
        <div className="p-6 pb-2 flex justify-between items-center">
            <h2 className="text-lg font-bold text-white">Performance</h2>
            <div className="flex gap-2">
                {['1W', '1M', 'ALL'].map(t => (
                  <button key={t} className={`px-3 py-1 text-[10px] font-bold rounded-lg transition-all ${t === '1W' ? 'bg-brand-primary text-white' : 'text-brand-text-secondary hover:text-white'}`}>
                    {t}
                  </button>
                ))}
            </div>
        </div>
        <div className="h-64 w-full">
          <PortfolioChart currentValue={stats.totalAssetValue} />
        </div>
      </Card>

      <div className="space-y-4">
          <div className="flex justify-between items-center px-1">
              <h2 className="text-lg font-bold text-white">Assets</h2>
              <button onClick={() => navigate('/invest')} className="text-xs font-bold text-brand-primary hover:text-brand-secondary transition-colors">Market Terminal →</button>
          </div>
          <AssetList assets={assets} />
      </div>
    </div>
  );
};

export default DashboardPage;
