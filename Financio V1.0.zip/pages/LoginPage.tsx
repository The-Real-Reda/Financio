
import React, { useState } from 'react';
import Icon from '../components/common/Icon';
import Logo from '../components/common/Logo';
import { useAuth } from '../context/AuthContext';

const LoginPage: React.FC = () => {
  const { login, register, resetPassword } = useAuth();
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');
  
  // Form State
  const [name, setName] = useState('');
  const [username, setUsername] = useState(''); // Used as email
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  
  // UI State
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState<{msg: string, type: 'success' | 'error'} | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setFeedback(null);

    try {
      if (mode === 'login') {
        const res = await login(username, password);
        if (!res.success) throw new Error(res.message);
      } else if (mode === 'register') {
        if (!name || !username || !password) throw new Error("All fields are required");
        const res = await register(name, username, password);
        if (!res.success) throw new Error(res.message);
      } else if (mode === 'forgot') {
        if (!username) throw new Error("Please enter your email");
        const res = await resetPassword(username);
        setFeedback({ msg: res.message, type: 'success' });
      }
    } catch (err: any) {
      setFeedback({ msg: err.message, type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  const socialLogin = (provider: string) => {
    setFeedback({ msg: `${provider} login is a demo placeholder. Use credentials: demo / demo`, type: 'error' });
  };

  return (
    <div className="w-full h-full bg-brand-bg overflow-y-auto no-scrollbar relative flex flex-col">
      {/* Fixed Background Ambience */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] bg-brand-primary/5 rounded-full blur-[140px]"></div>
        <div className="absolute -bottom-[10%] -right-[10%] w-[50%] h-[50%] bg-brand-success/5 rounded-full blur-[140px]"></div>
      </div>

      {/* Robust Scrollable Centering Wrapper */}
      <div className="flex-1 w-full flex flex-col items-center justify-center p-4 sm:p-8 min-h-max relative z-10">
        
        <div className="w-full max-w-md bg-brand-surface p-6 sm:p-10 rounded-[2.5rem] border border-white/5 shadow-2xl relative overflow-hidden transition-all duration-300">
          {/* Animated Accent Bar */}
          <div className={`absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r transition-all duration-500 ease-in-out ${
              mode === 'register' ? 'from-purple-500 to-brand-primary' : 
              mode === 'forgot' ? 'from-orange-500 to-red-500' :
              'from-brand-success to-brand-primary'
          }`}></div>
          
          <div className="flex flex-col items-center mb-6 sm:mb-10">
            <div className="mb-4 transform hover:scale-105 transition-transform duration-300 cursor-pointer">
               <Logo className="w-16 h-16 sm:w-20 sm:h-20 drop-shadow-[0_0_20px_rgba(16,185,129,0.3)]" />
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-center tracking-tighter text-white uppercase italic">Financio</h1>
            <p className="text-brand-text-secondary text-[10px] sm:text-xs mt-2 uppercase tracking-[0.3em] font-black opacity-50">High-Yield Wealth Terminal</p>
          </div>

          {/* Mode Switcher */}
          {mode !== 'forgot' && (
              <div className="flex bg-brand-bg/50 p-1.5 rounded-2xl mb-8 border border-white/5 shadow-inner">
                  <button 
                      type="button"
                      onClick={() => { setMode('login'); setFeedback(null); }}
                      className={`flex-1 py-3 text-[10px] font-black uppercase tracking-[0.2em] rounded-xl transition-all ${mode === 'login' ? 'bg-brand-surface text-brand-primary shadow-lg ring-1 ring-white/10' : 'text-brand-text-secondary hover:text-white'}`}
                  >
                      Log In
                  </button>
                  <button 
                      type="button"
                      onClick={() => { setMode('register'); setFeedback(null); }}
                      className={`flex-1 py-3 text-[10px] font-black uppercase tracking-[0.2em] rounded-xl transition-all ${mode === 'register' ? 'bg-brand-surface text-brand-primary shadow-lg ring-1 ring-white/10' : 'text-brand-text-secondary hover:text-white'}`}
                  >
                      Sign Up
                  </button>
              </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {mode === 'register' && (
               <div className="animate-in fade-in slide-in-from-left-4 duration-300">
                  <label className="block text-[10px] font-black text-brand-text-secondary uppercase tracking-widest mb-2 ml-1">Full Name</label>
                  <input 
                    type="text" 
                    required={mode === 'register'}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-brand-bg border border-white/10 rounded-2xl p-4 text-white focus:outline-none focus:border-brand-primary/50 focus:ring-4 focus:ring-brand-primary/5 transition-all placeholder:text-white/10 text-sm font-medium shadow-inner"
                    placeholder="Enter full name"
                  />
               </div>
            )}

            <div className="animate-in fade-in slide-in-from-left-4 duration-300 delay-75">
              <label className="block text-[10px] font-black text-brand-text-secondary uppercase tracking-widest mb-2 ml-1">Email Address</label>
              <input 
                type="email" 
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-brand-bg border border-white/10 rounded-2xl p-4 text-white focus:outline-none focus:border-brand-primary/50 focus:ring-4 focus:ring-brand-primary/5 transition-all placeholder:text-white/10 text-sm font-medium shadow-inner"
                placeholder="name@domain.com"
              />
            </div>

            {(mode === 'login' || mode === 'register') && (
                <div className="animate-in fade-in slide-in-from-left-4 duration-300 delay-150">
                  <div className="flex justify-between items-center mb-2 ml-1">
                      <label className="text-[10px] font-black text-brand-text-secondary uppercase tracking-widest">Security Pin</label>
                      {mode === 'login' && (
                          <button 
                              type="button"
                              onClick={() => setMode('forgot')}
                              className="text-[10px] font-black text-brand-primary uppercase tracking-widest hover:text-brand-secondary transition-colors"
                          >
                              Recovery
                          </button>
                      )}
                  </div>
                  <input 
                    type="password" 
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-brand-bg border border-white/10 rounded-2xl p-4 text-white focus:outline-none focus:border-brand-primary/50 focus:ring-4 focus:ring-brand-primary/5 transition-all placeholder:text-white/10 text-sm font-medium shadow-inner"
                    placeholder="••••••••"
                  />
                </div>
            )}

            {mode === 'login' && (
                <div className="flex items-center gap-2.5 px-1 py-1">
                    <input 
                      type="checkbox" 
                      id="remember" 
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-5 h-5 rounded-lg bg-brand-bg border-white/10 text-brand-primary focus:ring-brand-primary transition-all cursor-pointer"
                    />
                    <label htmlFor="remember" className="text-[11px] text-brand-text-secondary font-bold cursor-pointer select-none">Trusted Device</label>
                </div>
            )}
            
            {feedback && (
               <div className={`text-[11px] p-4 rounded-2xl font-black uppercase tracking-wider animate-in zoom-in-95 ${feedback.type === 'success' ? 'bg-brand-success/10 text-brand-success border border-brand-success/20' : 'bg-brand-danger/10 text-brand-danger border border-brand-danger/20'}`}>
                   {feedback.msg}
               </div>
            )}

            <button 
              type="submit" 
              disabled={isLoading}
              className={`w-full font-black py-4.5 rounded-2xl transition-all duration-300 mt-2 shadow-2xl flex items-center justify-center gap-3 active:scale-[0.98] text-[11px] tracking-[0.3em] uppercase
               ${isLoading ? 'opacity-70 cursor-wait' : 'hover:brightness-110'}
               ${mode === 'register' ? 'bg-gradient-to-r from-purple-600 to-brand-primary text-white' : 
                 mode === 'forgot' ? 'bg-white text-black' :
                 'bg-gradient-to-r from-brand-success to-brand-primary text-white shadow-brand-primary/20'
               }`}
            >
              {isLoading && (
                 <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              )}
              {mode === 'login' && 'Establish Connection'}
              {mode === 'register' && 'Deploy Account'}
              {mode === 'forgot' && 'Reset Secure Link'}
            </button>
          </form>

          {mode !== 'forgot' && (
              <div className="mt-10 space-y-5">
                  <div className="relative flex items-center">
                      <div className="flex-grow border-t border-white/5"></div>
                      <span className="flex-shrink mx-4 text-[9px] font-black text-brand-text-secondary uppercase tracking-[0.4em]">Biometric bypass</span>
                      <div className="flex-grow border-t border-white/5"></div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                      <button 
                          onClick={() => socialLogin('Google')}
                          className="flex items-center justify-center gap-3 py-3.5 bg-brand-bg border border-white/5 rounded-2xl hover:bg-white/5 transition-all active:scale-95 group shadow-sm hover:shadow-md"
                      >
                          <svg className="w-4 h-4" viewBox="0 0 24 24">
                              <path fill="#EA4335" d="M12 5.04c1.62 0 3.08.56 4.22 1.66l3.13-3.13C17.43 1.68 14.9 1 12 1 7.24 1 3.2 3.73 1.25 7.68l3.6 2.79C5.7 7.7 8.64 5.04 12 5.04z"/>
                              <path fill="#4285F4" d="M23.52 12.27c0-.79-.07-1.54-.19-2.27H12v4.3h6.45c-.28 1.48-1.12 2.74-2.38 3.58l3.7 2.87c2.16-2 3.75-4.94 3.75-8.48z"/>
                              <path fill="#FBBC05" d="M4.85 14.73c-.23-.68-.35-1.41-.35-2.18s.12-1.5.35-2.18l-3.6-2.79C.45 8.92 0 10.41 0 12s.45 3.08 1.25 4.43l3.6-2.7z"/>
                              <path fill="#34A853" d="M12 23c3.15 0 5.8-1.04 7.73-2.83l-3.7-2.87c-1.03.69-2.35 1.1-4.03 1.1-3.36 0-6.3-2.66-7.15-5.43l-3.6 2.79C3.2 20.27 7.24 23 12 23z"/>
                          </svg>
                          <span className="text-[9px] font-black uppercase tracking-widest text-white opacity-60 group-hover:opacity-100">Google</span>
                      </button>
                      <button 
                          onClick={() => socialLogin('Apple')}
                          className="flex items-center justify-center gap-3 py-3.5 bg-brand-bg border border-white/5 rounded-2xl hover:bg-white/5 transition-all active:scale-95 group shadow-sm hover:shadow-md"
                      >
                          <svg className="w-4 h-4 fill-white opacity-80 group-hover:opacity-100" viewBox="0 0 24 24">
                              <path d="M17.05 20.28c-.96.95-2.1 1.72-3.4 1.72s-1.8-.75-3.35-.75-2.15.75-3.45.75-2.45-.75-3.45-1.72c-2.4-2.4-2.4-6.3 0-8.7 1-1 2.3-1.6 3.6-1.6s2.35.5 3.3.5 2-.5 3.35-.5 2.65.6 3.6 1.6c.9.9 1.4 1.9 1.6 2.8-.2.1-1.9.9-1.9 3.1s1.7 3 1.9 3.2c-.1.3-.4 1.1-.9 1.6zm-4.35-13.6c.9-.9 1.4-2.2 1.4-3.4 0-.2 0-.3-.1-.5-1.2.1-2.4.8-3.3 1.8-.9.9-1.4 2.1-1.4 3.4 0 .2 0 .3.1.5 1.2-.1 2.4-.8 3.3-1.8z"/>
                          </svg>
                          <span className="text-[9px] font-black uppercase tracking-widest text-white opacity-60 group-hover:opacity-100">Apple</span>
                      </button>
                  </div>
              </div>
          )}

          {mode === 'forgot' && (
              <div className="mt-10 text-center animate-in fade-in duration-500">
                  <button 
                      type="button"
                      onClick={() => { setMode('login'); setFeedback(null); }} 
                      className="text-[10px] font-black uppercase tracking-[0.2em] text-brand-primary hover:text-white transition-colors flex items-center justify-center gap-2 mx-auto"
                  >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 19l-7-7 7-7" /></svg>
                      Return to Authentication
                  </button>
              </div>
          )}
        </div>
        
        <div className="mt-12 flex flex-col items-center gap-3 text-brand-text-secondary opacity-30 pb-12 animate-pulse text-center">
           <Logo className="w-8 h-8 grayscale opacity-60" />
           <span className="text-[9px] font-black tracking-[0.6em] uppercase">End-to-End Quantum Shielded</span>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
