
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Card from '../components/common/Card';
import AccountCard from '../components/banking/AccountCard';
import Icon from '../components/common/Icon';
import Modal from '../components/common/Modal';
import { useFinance } from '../context/FinanceContext';
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const BankingPage: React.FC = () => {
  const { accounts, transactions, addTransaction, addBankAccount, removeBankAccount } = useFinance();
  const location = useLocation();
  
  // UI State
  const [viewMode, setViewMode] = useState<'accounts' | 'overview'>('accounts');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [accountToDelete, setAccountToDelete] = useState<string | null>(null);

  // Add Account Form State
  const [newAccProvider, setNewAccProvider] = useState('');
  const [newAccName, setNewAccName] = useState('');
  const [newAccBalance, setNewAccBalance] = useState('');

  // Add Transaction Form State
  const [txnDesc, setTxnDesc] = useState('');
  const [txnAmount, setTxnAmount] = useState('');
  const [txnType, setTxnType] = useState<'credit' | 'debit'>('debit');

  // Auto-open Add Modal if navigated from Sidebar
  useEffect(() => {
    if (location.state && location.state.openAddModal) {
        setIsAddModalOpen(true);
        // Clear state to prevent reopening on refresh
        window.history.replaceState({}, document.title);
    }
  }, [location]);

  const openDeleteModal = (id: string) => {
    setAccountToDelete(id);
    setIsDeleteModalOpen(true);
  };

  const handleConfirmDelete = () => {
    if (accountToDelete) {
      removeBankAccount(accountToDelete);
      setIsDeleteModalOpen(false);
      setAccountToDelete(null);
    }
  };

  const handleAddAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newAccName && newAccProvider && newAccBalance) {
        addBankAccount(newAccName, newAccProvider, parseFloat(newAccBalance));
        // Reset and Close
        setNewAccName(''); 
        setNewAccProvider(''); 
        setNewAccBalance('');
        setIsAddModalOpen(false);
    }
  };

  const handleAddTransactionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (txnDesc && txnAmount) {
        addTransaction(txnDesc, parseFloat(txnAmount), txnType);
        setIsTransactionModalOpen(false);
        setTxnDesc('');
        setTxnAmount('');
        setTxnType('debit');
    }
  };

  // --- Overview Data Calculation ---
  const totalBalance = accounts.reduce((sum, acc) => sum + acc.balance, 0);
  const monthlyIncome = transactions
    .filter(t => t.type === 'credit')
    .reduce((sum, t) => sum + t.amount, 0);
  const monthlyExpense = transactions
    .filter(t => t.type === 'debit')
    .reduce((sum, t) => sum + t.amount, 0);
  
  // Real Chart Data based on user stats
  const getChartData = () => {
    const data = [];
    const today = new Date();
    // Generate last 7 days
    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      
      const dayTxns = transactions.filter(t => t.date === dateStr);
      const income = dayTxns.filter(t => t.type === 'credit').reduce((sum, t) => sum + t.amount, 0);
      const expense = dayTxns.filter(t => t.type === 'debit').reduce((sum, t) => sum + t.amount, 0);
      
      data.push({
        name: d.toLocaleDateString('en-US', { weekday: 'short' }),
        income,
        expense
      });
    }
    return data;
  };

  const chartData = getChartData();

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h1 className="text-3xl font-bold text-brand-text-primary">Banking</h1>
          <p className="text-brand-text-secondary mt-1">Your connected accounts and transaction history.</p>
        </div>
        
        <div className="flex items-center gap-2 bg-brand-surface p-1 rounded-xl border border-white/5">
            <button 
                onClick={() => setViewMode('accounts')}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                    viewMode === 'accounts' ? 'bg-brand-primary text-white shadow-md' : 'text-brand-text-secondary hover:text-white'
                }`}
            >
                <div className="flex items-center gap-2">
                    <Icon name="list" className="w-4 h-4" />
                    Accounts
                </div>
            </button>
            <button 
                onClick={() => setViewMode('overview')}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                    viewMode === 'overview' ? 'bg-brand-primary text-white shadow-md' : 'text-brand-text-secondary hover:text-white'
                }`}
            >
                <div className="flex items-center gap-2">
                     <Icon name="chart" className="w-4 h-4" />
                     Overview
                </div>
            </button>
            <div className="w-px h-6 bg-white/10 mx-1"></div>
            <button 
                onClick={() => setIsTransactionModalOpen(true)}
                className="px-4 py-2 rounded-lg text-sm font-semibold text-brand-text-secondary hover:text-white hover:bg-white/5 transition-colors flex items-center gap-2"
                title="Add Transaction"
            >
                <span className="text-xl leading-none">+</span> $
            </button>
            <button 
                onClick={() => setIsAddModalOpen(true)}
                className="px-4 py-2 rounded-lg text-sm font-semibold text-brand-success hover:bg-brand-success/10 transition-colors flex items-center gap-2"
            >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" /></svg>
                Add Account
            </button>
        </div>
      </div>

      {/* Content Area with Animation */}
      <div className="relative">
          {/* Accounts View */}
          <div className={`transition-all duration-500 ease-in-out transform ${
              viewMode === 'accounts' ? 'opacity-100 translate-y-0 relative z-10' : 'opacity-0 translate-y-4 absolute inset-0 -z-10 pointer-events-none'
          }`}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {accounts.map(acc => (
                    <AccountCard 
                        key={acc.id} 
                        account={acc} 
                        onDelete={() => openDeleteModal(acc.id)} 
                    />
                ))}
                
                {/* Empty State */}
                {accounts.length === 0 && (
                    <button 
                        onClick={() => setIsAddModalOpen(true)}
                        className="col-span-1 md:col-span-2 lg:col-span-3 border-2 border-dashed border-white/10 rounded-2xl p-12 flex flex-col items-center justify-center text-brand-text-secondary hover:border-brand-primary/50 hover:bg-brand-surface/30 transition-all group"
                    >
                        <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4 group-hover:bg-brand-primary group-hover:text-white transition-colors">
                            <Icon name="banking" className="w-8 h-8" />
                        </div>
                        <h3 className="text-lg font-semibold text-white">No Accounts Connected</h3>
                        <p className="text-sm">Click to add your first bank account manually.</p>
                    </button>
                )}
              </div>

              {/* Transactions Section */}
              {transactions.length > 0 && (
                <Card className="!p-0 overflow-hidden border-t border-white/5 mt-8">
                    <div className="p-6 border-b border-white/5 bg-brand-surface/50">
                        <h2 className="text-xl font-bold text-white">Recent Transactions</h2>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                            <thead className="bg-white/5 text-xs uppercase text-brand-text-secondary font-semibold tracking-wider">
                                <tr>
                                    <th className="px-6 py-4">Date</th>
                                    <th className="px-6 py-4">Description</th>
                                    <th className="px-6 py-4 text-right">Amount</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-white/5">
                                {transactions.map(txn => (
                                    <tr key={txn.id} className="hover:bg-white/5 transition-colors">
                                        <td className="px-6 py-4 text-sm text-brand-text-secondary">{txn.date}</td>
                                        <td className="px-6 py-4 text-sm font-medium text-white">{txn.description}</td>
                                        <td className={`px-6 py-4 text-sm font-bold text-right ${txn.type === 'credit' ? 'text-brand-success' : 'text-white'}`}>
                                            {txn.type === 'debit' ? '-' : '+'}${txn.amount.toLocaleString()}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </Card>
              )}
          </div>

          {/* Overview View */}
          <div className={`transition-all duration-500 ease-in-out transform ${
              viewMode === 'overview' ? 'opacity-100 translate-y-0 relative z-10' : 'opacity-0 -translate-y-4 absolute inset-0 -z-10 pointer-events-none'
          }`}>
               {transactions.length === 0 ? (
                   <div className="text-center py-20 bg-brand-surface border border-white/5 rounded-2xl">
                       <h3 className="text-xl font-bold text-white mb-2">No Transaction Data Available</h3>
                       <p className="text-brand-text-secondary">Transactions from investments and accounts will appear here.</p>
                       <button 
                            onClick={() => setIsTransactionModalOpen(true)}
                            className="mt-4 px-6 py-2 bg-brand-primary text-white rounded-xl font-bold hover:bg-brand-secondary transition-colors"
                       >
                           Add Transaction
                       </button>
                   </div>
               ) : (
                   <div className="space-y-6">
                       <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                           <Card className="bg-brand-surface/50 border-white/5">
                               <p className="text-sm text-brand-text-secondary mb-1">Total Balance</p>
                               <p className="text-3xl font-bold text-white">${totalBalance.toLocaleString()}</p>
                           </Card>
                           <Card className="bg-brand-surface/50 border-white/5">
                               <p className="text-sm text-brand-text-secondary mb-1">Total Income</p>
                               <p className="text-3xl font-bold text-brand-success">+${monthlyIncome.toLocaleString()}</p>
                           </Card>
                           <Card className="bg-brand-surface/50 border-white/5">
                               <p className="text-sm text-brand-text-secondary mb-1">Total Expenses</p>
                               <p className="text-3xl font-bold text-brand-danger">-${monthlyExpense.toLocaleString()}</p>
                           </Card>
                       </div>

                       <Card className="h-80">
                           <h3 className="text-lg font-bold mb-4">Last 7 Days Activity</h3>
                           <ResponsiveContainer width="100%" height="100%">
                                <BarChart
                                    data={chartData}
                                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                                >
                                    <CartesianGrid strokeDasharray="3 3" stroke="#30363D" vertical={false} />
                                    <XAxis dataKey="name" stroke="#8B949E" />
                                    <YAxis stroke="#8B949E" />
                                    <Tooltip 
                                        contentStyle={{ backgroundColor: '#161B22', borderColor: '#30363D', color: '#fff' }}
                                        cursor={{fill: 'rgba(255,255,255,0.05)'}}
                                    />
                                    <Bar dataKey="income" fill="#238636" name="Income" radius={[4, 4, 0, 0]} />
                                    <Bar dataKey="expense" fill="#DA3633" name="Expense" radius={[4, 4, 0, 0]} />
                                </BarChart>
                           </ResponsiveContainer>
                       </Card>
                   </div>
               )}
          </div>
      </div>

      {/* Add Account Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add New Account"
      >
        <form onSubmit={handleAddAccountSubmit} className="space-y-4">
            <div className="space-y-2">
                <label className="text-sm text-brand-text-secondary font-medium">Bank Provider</label>
                <input 
                    autoFocus
                    type="text" 
                    placeholder="e.g. Chase, Wells Fargo" 
                    value={newAccProvider} 
                    onChange={e => setNewAccProvider(e.target.value)} 
                    className="w-full bg-brand-bg border border-white/10 rounded-xl p-3 focus:border-brand-primary focus:ring-1 focus:ring-brand-primary outline-none transition-all"
                />
            </div>
            <div className="space-y-2">
                <label className="text-sm text-brand-text-secondary font-medium">Account Name</label>
                <input 
                    type="text" 
                    placeholder="e.g. Checking" 
                    value={newAccName} 
                    onChange={e => setNewAccName(e.target.value)} 
                    className="w-full bg-brand-bg border border-white/10 rounded-xl p-3 focus:border-brand-primary focus:ring-1 focus:ring-brand-primary outline-none transition-all"
                />
            </div>
            <div className="space-y-2">
                <label className="text-sm text-brand-text-secondary font-medium">Initial Balance</label>
                <input 
                    type="number" 
                    placeholder="0.00" 
                    value={newAccBalance} 
                    onChange={e => setNewAccBalance(e.target.value)} 
                    className="w-full bg-brand-bg border border-white/10 rounded-xl p-3 focus:border-brand-primary focus:ring-1 focus:ring-brand-primary outline-none transition-all"
                />
            </div>
            <div className="pt-4 flex gap-3">
                <button 
                    type="button" 
                    onClick={() => setIsAddModalOpen(false)} 
                    className="flex-1 py-3 rounded-xl font-semibold text-brand-text-secondary hover:bg-white/5 transition-colors"
                >
                    Cancel
                </button>
                <button 
                    type="submit" 
                    disabled={!newAccName || !newAccProvider || !newAccBalance}
                    className="flex-1 py-3 rounded-xl font-semibold bg-brand-primary text-white hover:bg-brand-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg"
                >
                    Create Account
                </button>
            </div>
        </form>
      </Modal>

      {/* Add Transaction Modal */}
      <Modal
        isOpen={isTransactionModalOpen}
        onClose={() => setIsTransactionModalOpen(false)}
        title="Add Transaction"
      >
        <form onSubmit={handleAddTransactionSubmit} className="space-y-4">
            <div className="flex gap-2 p-1 bg-brand-bg rounded-xl border border-white/10 mb-4">
                <button
                    type="button"
                    onClick={() => setTxnType('debit')}
                    className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${txnType === 'debit' ? 'bg-brand-danger text-white' : 'text-brand-text-secondary hover:text-white'}`}
                >
                    Expense
                </button>
                <button
                    type="button"
                    onClick={() => setTxnType('credit')}
                    className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${txnType === 'credit' ? 'bg-brand-success text-white' : 'text-brand-text-secondary hover:text-white'}`}
                >
                    Income
                </button>
            </div>

            <div className="space-y-2">
                <label className="text-sm text-brand-text-secondary font-medium">Description</label>
                <input 
                    autoFocus
                    type="text" 
                    placeholder="e.g. Grocery, Salary, Rent" 
                    value={txnDesc} 
                    onChange={e => setTxnDesc(e.target.value)} 
                    className="w-full bg-brand-bg border border-white/10 rounded-xl p-3 focus:border-brand-primary focus:ring-1 focus:ring-brand-primary outline-none transition-all"
                />
            </div>
            <div className="space-y-2">
                <label className="text-sm text-brand-text-secondary font-medium">Amount</label>
                <input 
                    type="number" 
                    placeholder="0.00" 
                    value={txnAmount} 
                    onChange={e => setTxnAmount(e.target.value)} 
                    className="w-full bg-brand-bg border border-white/10 rounded-xl p-3 focus:border-brand-primary focus:ring-1 focus:ring-brand-primary outline-none transition-all"
                />
            </div>
            
            <div className="pt-4 flex gap-3">
                <button 
                    type="button" 
                    onClick={() => setIsTransactionModalOpen(false)} 
                    className="flex-1 py-3 rounded-xl font-semibold text-brand-text-secondary hover:bg-white/5 transition-colors"
                >
                    Cancel
                </button>
                <button 
                    type="submit" 
                    disabled={!txnDesc || !txnAmount}
                    className="flex-1 py-3 rounded-xl font-semibold bg-brand-primary text-white hover:bg-brand-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg"
                >
                    Save
                </button>
            </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal 
        isOpen={isDeleteModalOpen} 
        onClose={() => setIsDeleteModalOpen(false)}
        title="Delete Account?"
        type="danger"
        footer={
            <div className="flex gap-3 w-full">
                <button 
                    onClick={() => setIsDeleteModalOpen(false)} 
                    className="flex-1 py-2 rounded-lg text-brand-text-secondary hover:bg-white/5 font-medium transition-colors"
                >
                    Keep Account
                </button>
                <button 
                    onClick={handleConfirmDelete} 
                    className="flex-1 py-2 rounded-lg bg-brand-danger text-white font-bold hover:bg-red-600 shadow-lg transition-colors"
                >
                    Yes, Delete
                </button>
            </div>
        }
      >
        <div className="flex flex-col items-center text-center py-2">
            <div className="w-16 h-16 bg-brand-danger/10 text-brand-danger rounded-full flex items-center justify-center mb-4">
                <Icon name="trash" className="w-8 h-8" />
            </div>
            <p className="text-white text-lg font-medium mb-2">This action is permanent.</p>
            <p className="text-brand-text-secondary text-sm">
                Deleting this account will remove it and its associated local transaction history from your dashboard.
            </p>
        </div>
      </Modal>
    </div>
  );
};

export default BankingPage;
