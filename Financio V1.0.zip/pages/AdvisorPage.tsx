
import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import Icon from '../components/common/Icon';
import { getChatResponse } from '../services/geminiService';

interface AdvisorPageProps {
  location: GeolocationCoordinates | null;
  locationError: string | null;
}

interface Message {
  sender: 'user' | 'bot';
  text: string;
}

const AdvisorPage: React.FC<AdvisorPageProps> = ({ location }) => {
  const routeLocation = useLocation();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const chatRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const hasAutoQueried = useRef(false);

  const locationString = useMemo(() => {
    if (!location) return 'Global';
    try {
      return `${location.latitude.toFixed(2)}, ${location.longitude.toFixed(2)}`;
    } catch (e) {
      return 'Global';
    }
  }, [location]);

  const sendMessageToBot = useCallback(async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || isLoading) return;
    
    setError(null);
    setInput('');
    setIsLoading(true);
    
    if (!chatRef.current) {
      try {
        const sysMsg = `You are Financio Advisor,a world-class financial expert in Stocks, Crypto, Gold, and Sharia-compliant funds. 
        User Location: ${locationString}. 
        Provide professional, concise, and actionable financial insights using markdown formatting for lists or emphasis.
        Always remind users that you provide information, not legal financial advice. Use a friendly but professional tone.`;
        
        chatRef.current = getChatResponse(sysMsg);
      } catch (err) {
        console.error("Chat Init Error:", err);
        setError("Failed to initialize AI. Please ensure your environment is configured correctly.");
        setIsLoading(false);
        return;
      }
    }
    
    setMessages(prev => [...prev, { sender: 'user', text: trimmed }, { sender: 'bot', text: '' }]);

    try {
        const stream = await chatRef.current.sendMessageStream({ message: trimmed });
        let fullText = "";
        
        for await (const chunk of stream) {
            if (chunk.text) {
                fullText += chunk.text;
                setMessages(prev => {
                    const next = [...prev];
                    if (next.length > 0) {
                      next[next.length - 1] = { sender: 'bot', text: fullText };
                    }
                    return next;
                });
            }
        }
    } catch (e: any) {
        console.error("Chat streaming error:", e);
        setError(e.message || "Connection lost. Please try again.");
        setMessages(prev => prev.filter(m => m.text !== '' || m.sender === 'user'));
    } finally {
        setIsLoading(false);
    }
  }, [isLoading, locationString]);

  useEffect(() => {
    if (routeLocation.state?.autoQuery && !hasAutoQueried.current) {
        hasAutoQueried.current = true;
        sendMessageToBot(routeLocation.state.autoQuery);
    }
  }, [routeLocation.state, sendMessageToBot]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col w-full max-w-4xl mx-auto">
      <header className="mb-4 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">AI Wealth Advisor</h1>
          <p className="text-xs text-brand-text-secondary mt-0.5 uppercase tracking-widest font-bold flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-brand-success rounded-full animate-pulse"></span>
            Terminal Gemini 3.0 Pro
          </p>
        </div>
        <button 
          onClick={() => setMessages([])} 
          className="text-[10px] font-bold text-brand-text-secondary hover:text-brand-danger transition-colors border border-white/5 rounded-lg px-3 py-1 bg-brand-surface"
        >
          CLEAR CHAT
        </button>
      </header>
      
      <div className="flex-1 flex flex-col overflow-hidden bg-[#0F172A] border border-white/5 rounded-2xl shadow-2xl relative">
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 no-scrollbar bg-gradient-to-b from-brand-surface to-brand-bg">
          {messages.length === 0 && (
             <div className="h-full flex flex-col items-center justify-center text-center opacity-40 py-20">
                <div className="w-20 h-20 bg-brand-primary/10 rounded-3xl flex items-center justify-center mb-6 border border-brand-primary/20 rotate-3 group-hover:rotate-0 transition-transform">
                  <Icon name="advisor" className="w-10 h-10 text-brand-primary" />
                </div>
                <h3 className="text-white text-lg font-bold mb-2">Welcome to Financio AI</h3>
                <p className="text-sm max-w-xs font-medium text-brand-text-secondary">
                  How can I help you grow your portfolio today? Try asking about:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-6 w-full max-w-md">
                    {["Market trends in Gold", "Is AAPL a good buy?", "Crypto outlook 2025", "Sharia ETF benefits"].map(q => (
                      <button key={q} onClick={() => sendMessageToBot(q)} className="text-[11px] bg-brand-surface hover:bg-brand-primary/10 border border-white/5 rounded-xl p-3 text-brand-text-primary text-left transition-all hover:scale-[1.02]">
                        {q}
                      </button>
                    ))}
                </div>
             </div>
          )}
          
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
              <div className={`max-w-[85%] p-5 rounded-3xl text-sm leading-relaxed ${
                msg.sender === 'user' 
                  ? 'bg-brand-primary text-white rounded-tr-none shadow-xl border border-white/10' 
                  : 'bg-brand-surface border border-white/5 text-brand-text-primary rounded-tl-none shadow-lg'
              }`}>
                {msg.sender === 'bot' && (
                  <div className="flex items-center gap-2 mb-2 text-[10px] uppercase font-black text-brand-primary tracking-tighter">
                    <Icon name="advisor" className="w-3 h-3" />
                    Financio Intelligence
                  </div>
                )}
                <div className="whitespace-pre-wrap">
                  {msg.text || (isLoading && i === messages.length - 1 ? (
                    <div className="flex gap-1.5 py-1">
                      <div className="w-1.5 h-1.5 bg-brand-primary rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 bg-brand-primary rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                      <div className="w-1.5 h-1.5 bg-brand-primary rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                    </div>
                  ) : '')}
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        
        <div className="p-4 border-t border-white/5 bg-brand-surface/80 backdrop-blur-xl">
            {error && (
              <div className="flex items-center gap-2 text-xs text-brand-danger mb-3 bg-brand-danger/10 p-2 rounded-lg border border-brand-danger/20">
                <span className="font-bold">Error:</span> {error}
              </div>
            )}
            
            <div className="flex gap-3 bg-[#020617] rounded-2xl p-2 border border-white/10 focus-within:border-brand-primary transition-all shadow-inner group">
                <input 
                    type="text" 
                    value={input}
                    disabled={isLoading}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && sendMessageToBot(input)}
                    placeholder="Ask about assets, trends, or Sharia ethics..."
                    className="flex-1 bg-transparent border-none px-4 py-3 text-sm focus:ring-0 outline-none text-white placeholder:text-brand-text-secondary/30"
                />
                <button
                    onClick={() => sendMessageToBot(input)}
                    disabled={isLoading || !input.trim()}
                    className="w-12 h-12 flex items-center justify-center bg-brand-primary text-white rounded-xl hover:bg-brand-secondary transition-all disabled:opacity-30 active:scale-95 shadow-lg group-hover:shadow-brand-primary/20"
                >
                    <Icon name="send" className="w-5 h-5" />
                </button>
            </div>
            <p className="text-[9px] text-center text-brand-text-secondary mt-3 opacity-30 uppercase tracking-[0.2em] font-black">
              SECURE QUANTUM ADVISORY NODE
            </p>
        </div>
      </div>
    </div>
  );
};

export default AdvisorPage;
