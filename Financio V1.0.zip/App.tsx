
import React, { useState, useEffect, useRef } from 'react';
import { Routes, Route } from 'react-router-dom';
import BottomNav from './components/layout/BottomNav';
import DashboardPage from './pages/DashboardPage';
import InvestPage from './pages/InvestPage';
import BankingPage from './pages/BankingPage';
import AdvisorPage from './pages/AdvisorPage';
import ShariaPage from './pages/ShariaPage';
import LoginPage from './pages/LoginPage';
import AIChatWidget from './components/common/AIChatWidget';
import LoadingScreen from './components/common/LoadingScreen';
import SplashScreen from './components/common/SplashScreen';
import ProfileModal from './components/profile/ProfileModal';
import { useGeolocation } from './hooks/useGeolocation';
import { FinanceProvider } from './context/FinanceContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { GoogleGenAI, Modality } from "@google/genai";

// Decoding helpers for TTS
function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const AuthenticatedApp: React.FC = () => {
  const { user, logout } = useAuth();
  const { location, error, requestLocation } = useGeolocation();
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [appState, setAppState] = useState<'splash' | 'loading' | 'ready'>('splash');
  const soundPlayedRef = useRef(false);

  useEffect(() => {
    // Transition from loading to ready after 5 seconds
    if (appState === 'loading') {
        const timer = setTimeout(() => {
            setAppState('ready');
        }, 5000);
        return () => clearTimeout(timer);
    }
  }, [appState]);

  // Startup sound effect - triggered when entering 'ready' state
  useEffect(() => {
    if (appState === 'ready' && !soundPlayedRef.current) {
        soundPlayedRef.current = true;
        playStartupSound();
    }
  }, [appState]);

  const playStartupSound = async () => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        // Enhanced prompt to mimic the Discord easter egg sound
        contents: [{ parts: [{ text: 'Shout "Financio!" in a very high-pitched, energetic, fast, and cute voice. Make it sound exactly like the Discord easter egg startup sound. Short and snappy!' }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Puck' },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const decoded = decodeBase64(base64Audio);
        const buffer = await decodeAudioData(decoded, audioCtx, 24000, 1);
        const source = audioCtx.createBufferSource();
        source.buffer = buffer;
        
        // Slightly speed up playback to make it even more energetic/snappy
        source.playbackRate.value = 1.15;
        
        source.connect(audioCtx.destination);
        source.start();
      }
    } catch (e) {
      console.error("Failed to play startup sound:", e);
    }
  };

  useEffect(() => {
    if (user && appState === 'ready') requestLocation();
  }, [user, appState, requestLocation]);

  if (appState === 'splash') {
    return <SplashScreen onFinish={() => setAppState('loading')} />;
  }

  if (appState === 'loading') {
    return <LoadingScreen />;
  }

  if (!user) {
    return <LoginPage />;
  }

  return (
    <FinanceProvider>
      <div className="flex flex-col h-screen bg-brand-bg relative overflow-hidden animate-in fade-in duration-1000">
        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto pb-24 lg:pb-8 lg:pl-24 px-4 sm:px-6 pt-6">
          <div className="max-w-6xl mx-auto">
            <Routes>
              <Route path="/" element={<DashboardPage />} />
              <Route path="/invest" element={<InvestPage />} />
              <Route path="/banking" element={<BankingPage />} />
              <Route path="/sharia" element={<ShariaPage />} />
              <Route path="/advisor" element={<AdvisorPage location={location} locationError={error} />} />
            </Routes>
          </div>
        </main>

        {/* Universal Navigation */}
        <BottomNav 
            user={user} 
            onLogout={logout} 
            onOpenProfile={() => setIsProfileOpen(true)}
        />

        <AIChatWidget />
        
        <ProfileModal 
            isOpen={isProfileOpen} 
            onClose={() => setIsProfileOpen(false)} 
        />
      </div>
    </FinanceProvider>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
        <AuthenticatedApp />
    </AuthProvider>
  );
};

export default App;
