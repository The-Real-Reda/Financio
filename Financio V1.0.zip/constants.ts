
import { Asset, AssetType, BankAccount, Transaction, ChartDataPoint } from './types';

export const MOCK_ASSETS: Asset[] = [
  // Stocks
  { id: '1', name: 'Apple Inc.', ticker: 'AAPL', type: AssetType.Stock, price: 172.25, change24h: 2.50, change24h_percent: 1.47, value: 0, holdings: 0, maxSupply: 15500000000, logo: 'https://logo.clearbit.com/apple.com' },
  { id: '2', name: 'Microsoft', ticker: 'MSFT', type: AssetType.Stock, price: 420.55, change24h: 3.20, change24h_percent: 0.76, value: 0, holdings: 0, maxSupply: 7430000000, logo: 'https://logo.clearbit.com/microsoft.com' },
  { id: '5', name: 'NVIDIA', ticker: 'NVDA', type: AssetType.Stock, price: 880.08, change24h: 15.12, change24h_percent: 1.75, value: 0, holdings: 0, maxSupply: 2500000000, logo: 'https://logo.clearbit.com/nvidia.com' },
  
  // Crypto
  { id: '15', name: 'Bitcoin', ticker: 'BTC', type: AssetType.Crypto, price: 68134.78, change24h: -1200.45, change24h_percent: -1.73, value: 0, holdings: 0, maxSupply: 21000000, logo: 'https://logo.clearbit.com/bitcoin.org' },
  { id: '16', name: 'Ethereum', ticker: 'ETH', type: AssetType.Crypto, price: 3540.12, change24h: 80.23, change24h_percent: 2.31, value: 0, holdings: 0, maxSupply: 120000000, logo: 'https://logo.clearbit.com/ethereum.org' },

  // Commodities
  { id: '48', name: 'Physical Gold', ticker: 'XAU', type: AssetType.Commodity, price: 2350.10, change24h: 15.80, change24h_percent: 0.68, value: 0, holdings: 0, maxSupply: 1000000, logo: 'https://upload.wikimedia.org/wikipedia/commons/d/d7/Gold-Bars.png' },

  // Managed Assets
  { id: 'm1', name: 'AI Aggressive Managed', ticker: 'AGGR-M', type: AssetType.Managed, price: 1240.50, change24h: 45.20, change24h_percent: 3.78, value: 0, holdings: 0, maxSupply: 500000, logo: 'https://logo.clearbit.com/blackrock.com' },
  { id: 'm2', name: 'Conservative Wealth', ticker: 'CONS-M', type: AssetType.Managed, price: 980.15, change24h: 2.15, change24h_percent: 0.22, value: 0, holdings: 0, maxSupply: 1000000, logo: 'https://logo.clearbit.com/vanguard.com' },

  // Sharia Compliant
  { id: '64', name: 'SP Funds S&P 500 Sharia', ticker: 'SPUS', type: AssetType.Fund, price: 35.80, change24h: 0.12, change24h_percent: 0.34, value: 0, holdings: 0, maxSupply: 100000000, logo: 'https://logo.clearbit.com/wahedinvest.com' },
  { id: '65', name: 'Wahed FTSE USA Sharia', ticker: 'HLAL', type: AssetType.Fund, price: 62.45, change24h: 0.85, change24h_percent: 1.38, value: 0, holdings: 0, maxSupply: 100000000, logo: 'https://logo.clearbit.com/wahedinvest.com' },
  { id: '66', name: 'SP Funds REIT Sharia', ticker: 'SPRE', type: AssetType.Fund, price: 22.10, change24h: -0.15, change24h_percent: -0.68, value: 0, holdings: 0, maxSupply: 50000000, logo: 'https://logo.clearbit.com/sp-funds.com' },
  { id: '67', name: 'Wahed Dow Jones Islamic', ticker: 'UMMA', type: AssetType.Fund, price: 54.20, change24h: 0.45, change24h_percent: 0.83, value: 0, holdings: 0, maxSupply: 75000000, logo: 'https://logo.clearbit.com/wahed.com' },
  { id: '68', name: 'AMAL Sharia ETF', ticker: 'AMAL', type: AssetType.Fund, price: 38.90, change24h: 0.22, change24h_percent: 0.57, value: 0, holdings: 0, maxSupply: 100000000, logo: 'https://logo.clearbit.com/globalxetfs.com' },
];

export const MOCK_ACCOUNTS: BankAccount[] = [];
export const MOCK_TRANSACTIONS: Transaction[] = [];

export const MOCK_CHART_DATA: ChartDataPoint[] = [
  { date: 'Mon', price: 100 },
  { date: 'Tue', price: 105 },
  { date: 'Wed', price: 102 },
  { date: 'Thu', price: 110 },
  { date: 'Fri', price: 108 },
  { date: 'Sat', price: 115 },
  { date: 'Sun', price: 120 },
];
