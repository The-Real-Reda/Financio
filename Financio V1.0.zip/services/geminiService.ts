
import { GoogleGenAI } from '@google/genai';

/**
 * Helper to safely access API key from environment
 */
const getApiKey = () => {
  try {
    return process.env.API_KEY || '';
  } catch (e) {
    return '';
  }
};

export const getChatResponse = (systemInstruction: string) => {
  const apiKey = getApiKey();
  const ai = new GoogleGenAI({ apiKey });
  return ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: { 
      systemInstruction,
      temperature: 0.7,
      topP: 0.95,
      topK: 40
    },
  });
};

export const fetchStockNews = async (name: string, ticker: string) => {
  const apiKey = getApiKey();
  const ai = new GoogleGenAI({ apiKey });
  const prompt = `Provide the 3 most significant recent financial news items for ${name} (${ticker}). Format: HEADLINE, SOURCE_DATE, SUMMARY. Separate items with ---ITEM_SEPARATOR---.`;
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ parts: [{ text: prompt }] }],
      config: { 
        tools: [{ googleSearch: {} }] 
      },
    });

    return { 
      text: response.text || "", 
      groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("Error fetching stock news:", error);
    throw error;
  }
};
