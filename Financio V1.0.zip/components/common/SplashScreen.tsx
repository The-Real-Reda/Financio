
import React, { useEffect, useState } from 'react';
import Logo from './Logo';

interface SplashScreenProps {
  onFinish: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [showText, setShowText] = useState(false);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Show captions after a short delay
    const textTimer = setTimeout(() => setShowText(true), 800);
    
    // Auto-finish splash after 4.5 seconds
    const finishTimer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onFinish, 800); // Wait for fade out animation
    }, 4500);

    return () => {
      clearTimeout(textTimer);
      clearTimeout(finishTimer);
    };
  }, [onFinish]);

  return (
    <div 
      className={`fixed inset-0 bg-[#020617] z-[100] flex flex-col items-center justify-center overflow-hidden select-none transition-opacity duration-700 ${isVisible ? 'opacity-100' : 'opacity-0'}`}
    >
      {/* Background Ambience */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-brand-primary/10 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-brand-success/5 rounded-full blur-[100px] animate-float"></div>
      </div>

      <div className="relative z-10 flex flex-col items-center gap-12">
        {/* Central Logo Animation */}
        <div className="relative group">
          <div className="absolute inset-0 bg-brand-primary/20 blur-[60px] rounded-full scale-150 animate-pulse"></div>
          <div className="relative animate-in zoom-in-50 duration-1000 cubic-bezier(0.16, 1, 0.3, 1)">
            <Logo className="w-32 h-32 md:w-48 md:h-48 drop-shadow-[0_0_30px_rgba(99,102,241,0.4)]" />
          </div>
          
          {/* Circular progress around logo */}
          <svg className="absolute inset-0 -rotate-90 w-full h-full p-2 opacity-30" viewBox="0 0 100 100">
             <circle 
                cx="50" cy="50" r="48" 
                fill="none" stroke="white" strokeWidth="1" 
                strokeDasharray="301.59" strokeDashoffset="301.59"
                className="animate-draw-circle"
             />
          </svg>
        </div>

        <div className="text-center space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-300">
            <h2 className="text-white text-4xl font-black tracking-[0.3em] uppercase">Financio</h2>
            <div className="flex items-center justify-center gap-3">
              <span className="h-px w-8 bg-white/20"></span>
              <p className="text-brand-success text-[10px] font-black uppercase tracking-[0.5em]">Global Secure Node</p>
              <span className="h-px w-8 bg-white/20"></span>
            </div>
        </div>
      </div>

      {/* Brand Caption Overlay */}
      <div className={`absolute bottom-24 left-0 right-0 text-center px-6 transition-all duration-[1200ms] cubic-bezier(0.16, 1, 0.3, 1) transform pointer-events-none ${showText ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}>
        <div className="inline-block p-1 bg-gradient-to-b from-white/10 to-transparent rounded-[2rem] shadow-2xl ring-1 ring-white/5 overflow-hidden">
          <div className="bg-black/80 backdrop-blur-3xl px-10 py-5 rounded-[1.8rem] border border-white/5">
            <p className="text-brand-success text-[10px] md:text-xs font-black uppercase tracking-[0.4em] opacity-80">
              Financio Security Protocol
            </p>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translate(0, 0); }
          50% { transform: translate(-20px, 30px); }
        }
        .animate-float {
          animation: float 8s ease-in-out infinite;
        }
        @keyframes draw-circle {
          0% { stroke-dashoffset: 301.59; }
          100% { stroke-dashoffset: 0; }
        }
        .animate-draw-circle {
          animation: draw-circle 4s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default SplashScreen;
