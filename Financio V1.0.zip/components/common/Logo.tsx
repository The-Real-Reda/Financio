
import React, { useState } from 'react';
import { GoogleGenAI, Modality } from "@google/genai";

interface LogoProps {
  className?: string;
  disableInteractive?: boolean;
}

// Decoding helpers for TTS
function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const Logo: React.FC<LogoProps> = ({ className = "w-10 h-10", disableInteractive = false }) => {
  const [isPopping, setIsPopping] = useState(false);

  const playFinancioSound = async () => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: 'Shout "Financio!" in a very high-pitched, energetic, fast, and cute voice. Make it sound exactly like the Discord easter egg startup sound. Short and snappy!' }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Puck' },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const decoded = decodeBase64(base64Audio);
        const buffer = await decodeAudioData(decoded, audioCtx, 24000, 1);
        const source = audioCtx.createBufferSource();
        source.buffer = buffer;
        source.playbackRate.value = 1.15;
        source.connect(audioCtx.destination);
        source.start();
      }
    } catch (e) {
      console.error("Failed to play Financio sound:", e);
    }
  };

  const handleClick = (e: React.MouseEvent) => {
    if (disableInteractive) return;
    e.stopPropagation();
    
    // Trigger animation
    setIsPopping(true);
    setTimeout(() => setIsPopping(false), 800);
    
    // Play sound
    playFinancioSound();
  };

  return (
    <div className="relative inline-block">
      <svg 
        viewBox="0 0 100 100" 
        className={`${className} cursor-pointer hover:scale-110 active:scale-95 transition-transform duration-300`} 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        onClick={handleClick}
      >
        <defs>
          <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#10B981" />
            <stop offset="100%" stopColor="#059669" />
          </linearGradient>
        </defs>
        <circle cx="50" cy="50" r="50" fill="url(#logoGradient)" />
        <path d="M35 25H75C77.7614 25 80 27.2386 80 30V35C80 37.7614 77.7614 40 75 40H45V50H70C72.7614 50 75 52.2386 75 55V60C75 62.7614 72.7614 65 70 65H45V75C45 77.7614 42.7614 80 40 80H35C32.2386 80 30 77.7614 30 75V30C30 27.2386 32.2386 25 35 25Z" fill="white" />
      </svg>

      {/* Pop-out F Animation */}
      {isPopping && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-[60]">
           <div className="bg-brand-success text-white font-black text-xl w-8 h-8 rounded-lg flex items-center justify-center animate-pop-f shadow-2xl border border-white/20">
             F
           </div>
        </div>
      )}

      <style>{`
        @keyframes pop-f {
          0% { transform: translateY(0) scale(0); opacity: 0; }
          40% { transform: translateY(-60px) scale(1.4); opacity: 1; }
          100% { transform: translateY(-90px) scale(0); opacity: 0; }
        }
        .animate-pop-f {
          animation: pop-f 0.8s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default Logo;
