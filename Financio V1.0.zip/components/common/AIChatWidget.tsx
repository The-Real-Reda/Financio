
import React, { useState, useRef, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { getChatResponse } from '../../services/geminiService';
import Icon from './Icon';

const AIChatWidget: React.FC = () => {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{sender: 'user' | 'bot', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [hasUnread, setHasUnread] = useState(true);
  const [isPopping, setIsPopping] = useState(false);
  const chatRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const isAdvisorPage = location.pathname === '/advisor';

  const toggleChat = () => {
    // Animation logic for the pop-out F (Green)
    if (!isOpen) {
      setIsPopping(true);
      setTimeout(() => setIsPopping(false), 800);
    }
    
    setIsOpen(!isOpen);
    if (!isOpen) {
      setHasUnread(false);
      if (messages.length === 0) {
        setMessages([{ sender: 'bot', text: 'Welcome to Financio Support. I can help with account issues, platform navigation, or generic trading questions. How can I assist you today?' }]);
      }
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) scrollToBottom();
  }, [messages, isOpen, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userText = input;
    setMessages(prev => [...prev, { sender: 'user', text: userText }]);
    setInput('');
    setIsLoading(true);

    try {
      if (!chatRef.current) {
        chatRef.current = getChatResponse("You are a helpful customer support agent for the Financio app. Keep responses concise and focused on helping the user navigate the app or understand financial terms.");
      }
      
      const stream = await chatRef.current.sendMessageStream({ message: userText });
      
      let botResponse = '';
      setMessages(prev => [...prev, { sender: 'bot', text: '' }]);
      
      for await (const chunk of stream) {
        if (chunk.text) {
             botResponse += chunk.text;
             setMessages(prev => {
                const newArr = [...prev];
                if (newArr.length > 0) {
                  newArr[newArr.length - 1].text = botResponse;
                }
                return newArr;
             });
        }
      }
    } catch (error) {
      console.error("Support chat error:", error);
      setMessages(prev => {
          const newArr = prev.filter(m => m.text !== ''); 
          return [...newArr, { sender: 'bot', text: "Service temporarily unavailable. Our agents are monitoring the system." }];
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (isAdvisorPage) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Pop-out F Animation - Green */}
      {isPopping && (
        <div className="absolute top-0 left-0 w-12 h-12 flex items-center justify-center pointer-events-none z-10">
           <div className="bg-brand-success text-white font-black text-2xl w-10 h-10 rounded-xl flex items-center justify-center animate-pop-f shadow-2xl">
             F
           </div>
        </div>
      )}
      <style>{`
        @keyframes pop-f {
          0% { transform: translateY(0) scale(0); opacity: 0; }
          40% { transform: translateY(-80px) scale(1.4); opacity: 1; }
          100% { transform: translateY(-120px) scale(0); opacity: 0; }
        }
        .animate-pop-f {
          animation: pop-f 0.8s ease-out forwards;
        }
      `}</style>

      {/* Chat Window */}
      {isOpen && (
        <div className="mb-4 w-80 sm:w-96 bg-brand-surface border border-brand-border rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-5 fade-in duration-200 origin-bottom-right ring-1 ring-white/10">
          <div className="bg-brand-primary p-4 flex justify-between items-center">
            <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 bg-brand-success rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.8)]"></div>
                <h3 className="text-white font-bold text-sm tracking-tight">Financio Concierge</h3>
            </div>
            <button onClick={toggleChat} className="text-white/60 hover:text-white transition-colors">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                 <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
               </svg>
            </button>
          </div>
          
          <div className="h-80 overflow-y-auto p-4 space-y-4 bg-brand-bg/95 backdrop-blur-xl no-scrollbar">
             {messages.map((msg, idx) => {
               if (msg.sender === 'bot' && !msg.text) return null;
               
               return (
                <div key={idx} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-1`}>
                    <div className={`max-w-[85%] p-3.5 rounded-2xl text-xs sm:text-sm shadow-sm leading-relaxed ${
                        msg.sender === 'user' 
                        ? 'bg-brand-primary text-white rounded-tr-none border border-white/10' 
                        : 'bg-brand-surface border border-brand-border text-brand-text-primary rounded-tl-none'
                    }`}>
                        {msg.text}
                    </div>
                </div>
               );
             })}
             
             {isLoading && (
                 <div className="flex justify-start">
                     <div className="bg-brand-surface border border-brand-border p-3 rounded-2xl rounded-tl-none flex gap-1.5 shadow-sm">
                         <div className="w-1.5 h-1.5 bg-brand-primary rounded-full animate-bounce"></div>
                         <div className="w-1.5 h-1.5 bg-brand-primary rounded-full animate-bounce delay-75"></div>
                         <div className="w-1.5 h-1.5 bg-brand-primary rounded-full animate-bounce delay-150"></div>
                     </div>
                 </div>
             )}
             <div ref={messagesEndRef}></div>
          </div>

          <div className="p-4 border-t border-brand-border bg-brand-surface/80">
            <div className="flex gap-2">
                <input 
                    type="text" 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Describe your issue..."
                    className="flex-1 bg-brand-bg border border-white/10 rounded-xl px-4 py-2.5 text-xs sm:text-sm focus:outline-none focus:border-brand-primary text-white transition-all shadow-inner"
                />
                <button 
                    onClick={handleSend}
                    disabled={!input.trim() || isLoading}
                    className="w-10 h-10 bg-brand-primary text-white rounded-xl hover:bg-brand-secondary disabled:opacity-30 transition-all shadow-lg active:scale-95 flex items-center justify-center"
                >
                    <Icon name="send" className="w-4 h-4" />
                </button>
            </div>
            <p className="text-[8px] text-center text-brand-text-secondary mt-3 uppercase tracking-widest font-bold opacity-30">AI Encrypted Support Line</p>
          </div>
        </div>
      )}

      {/* Toggle Button */}
      <button 
        onClick={toggleChat}
        className="relative w-14 h-14 bg-brand-primary hover:bg-brand-secondary text-white rounded-full shadow-2xl flex items-center justify-center transition-all hover:scale-105 active:scale-95 group ring-4 ring-brand-bg"
      >
        {hasUnread && !isOpen && (
            <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 rounded-full border-2 border-brand-bg animate-bounce z-10 shadow-lg"></span>
        )}
        {isOpen ? (
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 9l-7 7-7-7" />
             </svg>
        ) : (
             <Icon name="advisor" className="w-7 h-7 group-hover:rotate-12 transition-transform" />
        )}
      </button>
    </div>
  );
};

export default AIChatWidget;
