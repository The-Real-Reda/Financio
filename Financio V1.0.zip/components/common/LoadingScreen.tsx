
import React, { useState, useEffect } from 'react';
import Icon from './Icon';

const TIPS = [
  "Diversification is the key to a stable portfolio.",
  "Always keep an emergency fund of 3-6 months of expenses.",
  "Compound interest is the eighth wonder of the world.",
  "Don't time the market; time in the market is better.",
  "Gold often acts as a hedge against inflation.",
  "Only invest in what you understand.",
  "Review your portfolio at least once every quarter.",
  "Crypto assets can be highly volatile; invest responsibly.",
  "Ethical investing focuses on sustainable and moral industries.",
  "Consistency in saving is more important than the initial amount."
];

const LoadingScreen: React.FC = () => {
  const [tip, setTip] = useState("");
  const [showBubble, setShowBubble] = useState(false);

  useEffect(() => {
    const randomTip = TIPS[Math.floor(Math.random() * TIPS.length)];
    setTip(randomTip);

    // Show the "Hi!" bubble shortly before the 5s loading finishes
    const timer = setTimeout(() => setShowBubble(true), 3200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed inset-0 bg-brand-bg flex flex-col items-center justify-center z-50 overflow-hidden">
      <div className="relative w-72 h-72 mb-12 flex items-center justify-center">
        
        {/* Floating Financial Particles */}
        <div className="absolute inset-0 pointer-events-none">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                <div key={i} className={`absolute text-brand-success font-black text-3xl opacity-20 animate-particle-${i}`}>
                    {['$', '7', '₿', '📈', '5', 'G', '¥', '€'][i-1]}
                </div>
            ))}
        </div>

        {/* Mascot Character: The Green 'Full F' */}
        <div className="relative z-10 animate-mascot-sequence">
            {/* The Body as a solid, blocky Letter 'F' character */}
            <div className="w-28 h-40 relative flex items-center justify-center">
                <svg viewBox="0 0 100 140" className="w-full h-full drop-shadow-[0_25px_40px_rgba(16,185,129,0.4)]">
                    {/* Block F Shape */}
                    <path 
                        d="M20 10 H85 C87.76 10 90 12.24 90 15 V40 C90 42.76 87.76 45 85 45 H55 V65 H80 C82.76 65 85 67.24 85 70 V90 C85 92.76 82.76 95 80 95 H55 V135 C55 137.76 52.76 140 50 140 H25 C22.24 140 20 137.76 20 135 V15 C20 12.24 22.24 10 25 10 Z" 
                        fill="#10B981" 
                        className="stroke-emerald-300 stroke-[3px]"
                    />
                    
                    {/* Eyes on the top of the F */}
                    <circle cx="45" cy="27" r="5" fill="#020617" />
                    <circle cx="70" cy="27" r="5" fill="#020617" />
                    
                    {/* Sparkles in eyes */}
                    <circle cx="47" cy="25" r="1.5" fill="white" className="animate-blink" />
                    <circle cx="72" cy="25" r="1.5" fill="white" className="animate-blink" />
                </svg>

                {/* Hand for Hi gesture */}
                <div className="absolute right-0 top-[65px] w-12 h-12 bg-emerald-500 rounded-full border-4 border-brand-bg animate-wave origin-bottom-left shadow-2xl flex items-center justify-center">
                     <div className="grid grid-cols-2 gap-0.5 p-1">
                        <div className="w-1.5 h-1.5 bg-white/40 rounded-full"></div>
                        <div className="w-1.5 h-1.5 bg-white/40 rounded-full"></div>
                        <div className="w-1.5 h-1.5 bg-white/40 rounded-full"></div>
                     </div>
                </div>
            </div>
            
            {/* Speech Bubble */}
            {showBubble && (
                <div className="absolute -top-16 -right-12 bg-white text-brand-bg px-6 py-3 rounded-3xl font-black text-2xl animate-bubble-pop shadow-2xl flex items-center justify-center ring-4 ring-brand-success/20 after:content-[''] after:absolute after:top-full after:left-6 after:border-[12px] after:border-transparent after:border-t-white">
                    Hi!
                </div>
            )}
        </div>
      </div>
      
      <div className="text-center px-6 max-w-sm z-20">
        <h2 className="text-brand-success font-black text-5xl tracking-[0.2em] mb-10 animate-title-glow drop-shadow-[0_0_15px_rgba(16,185,129,0.7)]">FINANCIO</h2>
        <div className="bg-brand-surface/80 backdrop-blur-2xl border border-white/10 p-6 rounded-[2.5rem] shadow-3xl transform transition-all duration-700 hover:scale-[1.03] ring-1 ring-white/10 relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-primary via-brand-success to-brand-primary animate-shine"></div>
            <div className="flex items-center justify-center gap-3 mb-3">
                <Icon name="invest" className="w-4 h-4 text-brand-success animate-pulse" />
                <p className="text-[11px] text-brand-primary uppercase font-black tracking-[0.25em]">Investor Wisdom</p>
                <Icon name="invest" className="w-4 h-4 text-brand-success animate-pulse" />
            </div>
            <p className="text-base text-brand-text-primary leading-relaxed font-bold italic">"{tip}"</p>
        </div>
      </div>

      {/* Sleek Modern Loading Bar */}
      <div className="absolute bottom-16 w-80">
         <div className="flex justify-between items-end mb-2.5 px-2">
            <span className="text-[10px] font-black text-brand-text-secondary uppercase tracking-[0.2em] opacity-40">System Init</span>
            <span className="text-[10px] font-black text-brand-success uppercase tracking-[0.2em] animate-pulse">Processing...</span>
         </div>
         <div className="h-3 bg-brand-surface/50 rounded-full overflow-hidden shadow-2xl ring-2 ring-white/5 p-0.5">
            <div className="h-full bg-gradient-to-r from-brand-primary via-brand-success to-emerald-400 animate-progress-sync rounded-full shadow-[0_0_25px_rgba(16,185,129,0.8)] relative">
                <div className="absolute inset-0 bg-white/20 animate-bar-shimmer"></div>
            </div>
         </div>
      </div>

      <style>{`
        @keyframes progress-sync {
          0% { width: 0%; }
          100% { width: 100%; }
        }
        .animate-progress-sync {
          animation: progress-sync 5s cubic-bezier(0.7, 0, 0.3, 1) forwards;
        }

        @keyframes bar-shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        .animate-bar-shimmer {
            animation: bar-shimmer 1.5s infinite;
        }

        @keyframes shine {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        .animate-shine {
            animation: shine 3s infinite linear;
        }

        @keyframes title-glow {
            0%, 100% { filter: drop-shadow(0 0 10px rgba(16,185,129,0.5)); }
            50% { filter: drop-shadow(0 0 25px rgba(16,185,129,0.9)); }
        }
        .animate-title-glow {
            animation: title-glow 2s infinite ease-in-out;
        }
        
        @keyframes blink {
          0%, 90%, 100% { transform: scaleY(1); }
          95% { transform: scaleY(0.1); }
        }
        .animate-blink {
          animation: blink 3s infinite;
        }

        @keyframes wave {
          0%, 55% { transform: rotate(0deg); opacity: 0; scale: 0.8; }
          60%, 80% { transform: rotate(-30deg); opacity: 1; scale: 1.1; }
          70%, 90% { transform: rotate(30deg); opacity: 1; scale: 1.1; }
          100% { transform: rotate(0deg); opacity: 1; scale: 1; }
        }
        .animate-wave {
          animation: wave 5s infinite cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        @keyframes bubble-pop {
            0% { transform: scale(0) translateY(20px); opacity: 0; }
            70% { transform: scale(1.1) translateY(-5px); opacity: 1; }
            100% { transform: scale(1) translateY(0); opacity: 1; }
        }
        .animate-bubble-pop {
            animation: bubble-pop 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
        }

        @keyframes mascot-sequence {
          0% { transform: translateY(100px) scale(0.5); opacity: 0; }
          30% { transform: translateY(-20px) scale(1.1) rotate(5deg); opacity: 1; }
          60% { transform: translateY(0) rotate(-5deg) scale(0.95); }
          80% { transform: scale(1.3) translateY(-10px); }
          100% { transform: scale(1.2) translateY(0); }
        }
        .animate-mascot-sequence {
          animation: mascot-sequence 5s forwards cubic-bezier(0.22, 1, 0.36, 1);
        }

        ${[1, 2, 3, 4, 5, 6, 7, 8].map(i => `
          @keyframes particle-${i} {
            0% { transform: translate(0, 0) scale(0); opacity: 0; }
            20% { opacity: 0.8; scale: 1; }
            100% { transform: translate(${(Math.random() - 0.5) * 400}px, ${(Math.random() - 0.5) * 400}px) rotate(${Math.random() * 720}deg); opacity: 0; }
          }
          .animate-particle-${i} { animation: particle-${i} ${3 + Math.random() * 3}s infinite ${Math.random() * 2}s; }
        `).join('')}
      `}</style>
    </div>
  );
};

export default LoadingScreen;
