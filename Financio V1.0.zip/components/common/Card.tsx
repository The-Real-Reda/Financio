
import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '' }) => {
  return (
    <div className={`glass rounded-2xl p-6 sm:p-8 hover:border-white/10 transition-all duration-300 ${className}`}>
      {children}
    </div>
  );
};

export default Card;
