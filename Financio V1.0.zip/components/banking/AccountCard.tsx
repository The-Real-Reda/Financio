
import React from 'react';
import { BankAccount } from '../../types';
import Card from '../common/Card';
import Icon from '../common/Icon';

interface AccountCardProps {
  account: BankAccount;
  onDelete: () => void;
}

const AccountCard: React.FC<AccountCardProps> = ({ account, onDelete }) => {
  return (
    <Card className="flex flex-col justify-between relative group overflow-hidden !border-0 bg-gradient-to-br from-brand-surface to-brand-bg shadow-2xl ring-1 ring-white/5 h-64 hover:ring-brand-primary/50 transition-all duration-300">
      
      {/* Background Decor */}
      <div className="absolute top-0 right-0 w-40 h-40 bg-brand-primary/5 rounded-full blur-3xl -mr-12 -mt-12 pointer-events-none"></div>

      <div className="flex justify-between items-start z-10">
        <div>
            <div className="flex items-center gap-2 mb-1">
                <div className="w-2 h-2 rounded-full bg-brand-success shadow-[0_0_8px_rgba(35,134,54,0.6)]"></div>
                <p className="text-[10px] uppercase tracking-widest text-brand-text-secondary font-bold">Connected</p>
            </div>
            <p className="text-brand-text-secondary font-medium text-sm bg-white/5 px-2 py-0.5 rounded inline-block">{account.provider}</p>
        </div>
        
        {/* Delete Button - Always visible now */}
        <button 
          onClick={(e) => { 
            e.stopPropagation(); 
            onDelete(); 
          }}
          className="p-2.5 bg-brand-bg/80 border border-white/5 hover:bg-brand-danger/10 hover:border-brand-danger/30 hover:text-brand-danger text-brand-text-secondary rounded-lg transition-all duration-200 backdrop-blur-sm shadow-sm"
          title="Delete Account"
          aria-label="Delete Account"
        >
          <Icon name="trash" className="w-4 h-4" />
        </button>
      </div>

      <div className="z-10 mt-auto mb-6">
        <p className="text-xl font-bold text-white tracking-tight truncate pr-4">{account.name}</p>
        <p className="text-sm text-brand-text-secondary font-mono opacity-60 tracking-wider">{account.accountNumber}</p>
      </div>

      <div className="pt-4 border-t border-white/5 z-10">
        <p className="text-xs text-brand-text-secondary uppercase tracking-wider font-bold mb-1">Available Balance</p>
        <p className="text-3xl font-bold text-white tracking-tight">
           {account.balance.toLocaleString('en-US', { style: 'currency', currency: account.currency })}
        </p>
      </div>
    </Card>
  );
};

export default AccountCard;
