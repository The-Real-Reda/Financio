
import React from 'react';
import { NavLink } from 'react-router-dom';
import Icon from '../common/Icon';
import Logo from '../common/Logo';
import { UserProfile } from '../../types';

interface BottomNavProps {
  user: UserProfile | null;
  onLogout: () => void;
  onOpenProfile: () => void;
}

const navItems = [
  { name: 'Home', path: '/', icon: 'dashboard' as const },
  { name: 'Trade', path: '/invest', icon: 'invest' as const },
  { name: 'Bank', path: '/banking', icon: 'banking' as const },
  { name: 'Ethics', path: '/sharia', icon: 'sharia' as const },
  { name: 'AI', path: '/advisor', icon: 'advisor' as const },
];

const BottomNav: React.FC<BottomNavProps> = ({ user, onLogout, onOpenProfile }) => {
  return (
    <>
      {/* Mobile Nav */}
      <nav className="fixed bottom-0 left-0 right-0 h-20 bg-brand-surface border-t border-brand-border flex items-center justify-around px-2 z-40 lg:hidden pb-safe">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center flex-1 transition-all ${
                isActive ? 'text-brand-primary' : 'text-brand-text-secondary'
              }`
            }
          >
            <Icon name={item.icon} className="w-6 h-6 mb-1" />
            <span className="text-[9px] font-bold uppercase tracking-wider">{item.name}</span>
          </NavLink>
        ))}
      </nav>

      {/* Desktop Sidebar */}
      <nav className="fixed left-0 top-0 bottom-0 w-20 bg-brand-surface border-r border-brand-border hidden lg:flex flex-col items-center py-8 z-40">
        {/* Brand Logo - Interactive */}
        <div className="mb-12">
            <Logo className="w-12 h-12" />
        </div>

        {/* Navigation Items */}
        <div className="flex-1 flex flex-col gap-8">
            {navItems.map((item) => (
                <NavLink
                    key={item.name}
                    to={item.path}
                    className={({ isActive }) =>
                        `p-3 rounded-xl transition-all ${
                          isActive ? 'bg-brand-primary/10 text-brand-primary shadow-sm' : 'text-brand-text-secondary hover:text-white hover:bg-white/5'
                        }`
                    }
                >
                    <Icon name={item.icon} className="w-6 h-6" />
                </NavLink>
            ))}
        </div>

        {/* User Account Widget - Desktop */}
        <div className="mt-auto flex flex-col items-center gap-3">
          <button 
            onClick={onOpenProfile} 
            className="w-11 h-11 rounded-full bg-brand-border overflow-hidden border border-brand-primary/30 hover:ring-2 hover:ring-brand-primary/50 transition-all shadow-lg active:scale-95"
            title="Open Profile"
          >
               {user?.avatar ? (
                 <img src={user.avatar} className="w-full h-full object-cover" alt="User" />
               ) : (
                 <span className="text-xs font-bold text-white">{user?.name[0]}</span>
               )}
          </button>

          {/* Log Out button under avatar */}
          <button 
            onClick={onLogout}
            className="group p-2 rounded-lg bg-brand-danger/10 border border-brand-danger/20 hover:bg-brand-danger transition-all active:scale-90"
            title="Log Out"
          >
            <Icon name="logout" className="w-3 h-3 text-brand-danger group-hover:text-white" />
          </button>
        </div>
      </nav>
    </>
  );
};

export default BottomNav;
