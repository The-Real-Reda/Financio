
import React from 'react';
import { UserProfile } from '../../types';
import Icon from '../common/Icon';

interface AccountWidgetProps {
  user: UserProfile | null;
  onLogout?: () => void;
  onAddAccount?: () => void;
  onOpenProfile?: () => void;
  compact?: boolean;
}

const AccountWidget: React.FC<AccountWidgetProps> = ({ user, onLogout, onAddAccount, onOpenProfile, compact = false }) => {
  const username = user?.name || 'Guest';
  const initial = username.charAt(0).toUpperCase();

  return (
    <div className={`flex flex-col gap-3 bg-brand-surface border border-brand-border rounded-2xl p-4 shadow-xl`}>
      <div className={`flex flex-col items-center ${compact ? '' : 'lg:flex-row lg:items-start lg:gap-4'} gap-3`}>
        {/* Profile Avatar Group */}
        <div className="flex flex-col items-center gap-2">
          <div 
            className={`relative group cursor-pointer`}
            onClick={onOpenProfile}
            title="View Profile"
          >
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-brand-success to-brand-primary flex items-center justify-center text-white font-bold text-2xl shadow-inner ring-2 ring-brand-bg overflow-hidden group-hover:ring-brand-primary/50 transition-all">
              {user?.avatar ? (
                  <img src={user.avatar} alt={username} className="w-full h-full object-cover" />
              ) : (
                  initial
              )}
            </div>
            <div className="absolute bottom-0 right-0 w-4 h-4 bg-brand-success border-2 border-brand-surface rounded-full"></div>
          </div>
          
          {/* LOG OUT button directly under avatar */}
          <button 
            onClick={onLogout}
            className="text-[9px] font-black uppercase tracking-widest text-brand-danger hover:text-red-400 transition-colors bg-brand-danger/10 px-2 py-1 rounded-md border border-brand-danger/20"
          >
            Log Out
          </button>
        </div>
        
        {!compact && (
          <div className="flex-1 min-w-0 text-center lg:text-left mt-1">
            <p 
              className="text-base font-bold text-brand-text-primary truncate hover:text-brand-primary transition-colors cursor-pointer"
              onClick={onOpenProfile}
            >
              {username}
            </p>
            <p className="text-[10px] text-brand-text-secondary uppercase tracking-wider font-bold">Premium Investor</p>
          </div>
        )}
      </div>

      {!compact && (
        <>
          <div className="flex flex-col gap-2 mt-2">
            <button 
              onClick={onAddAccount}
              className="w-full text-xs bg-brand-bg hover:bg-white/5 text-brand-text-primary font-bold py-2.5 rounded-xl border border-white/5 transition-all flex items-center justify-center gap-2"
            >
              <span className="text-brand-primary text-lg">+</span> Manage Accounts
            </button>
            <button 
              onClick={onLogout}
              className="w-full text-xs bg-brand-danger hover:bg-red-600 text-white font-bold py-2.5 rounded-xl shadow-lg shadow-brand-danger/20 transition-all flex items-center justify-center gap-2"
            >
              <Icon name="logout" className="w-4 h-4" />
              SECURE LOGOUT
            </button>
          </div>
          <div className="mt-2 pt-3 border-t border-white/5">
             <p className="text-[9px] text-center text-brand-text-secondary uppercase tracking-[0.15em] font-black opacity-60">
               Developed by: <span className="text-brand-success">SADAOUI Med Reda</span>
             </p>
          </div>
        </>
      )}
    </div>
  );
};

export default AccountWidget;
