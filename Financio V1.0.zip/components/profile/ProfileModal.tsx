
import React, { useState, useEffect } from 'react';
import Modal from '../common/Modal';
import { UserProfile } from '../../types';
import { useAuth } from '../../context/AuthContext';
import Icon from '../common/Icon';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose }) => {
  const { user, updateProfile } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [avatar, setAvatar] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [msg, setMsg] = useState<{ text: string, type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    if (user) {
      setName(user.name);
      setEmail(user.email);
      setAvatar(user.avatar || '');
    }
  }, [user, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    
    const result = await updateProfile({ name, email, avatar });
    if (result.success) {
      setMsg({ text: result.message, type: 'success' });
      setIsEditing(false);
      setTimeout(() => setMsg(null), 3000);
    } else {
      setMsg({ text: result.message, type: 'error' });
    }
  };

  if (!user) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="User Profile">
      <div className="flex flex-col items-center mb-6">
        <div className="relative w-24 h-24 mb-4 group cursor-pointer">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-brand-success to-brand-primary flex items-center justify-center text-white font-bold text-4xl shadow-lg ring-4 ring-brand-surface overflow-hidden">
                {avatar ? (
                    <img src={avatar} alt={name} className="w-full h-full object-cover" />
                ) : (
                    name.charAt(0).toUpperCase()
                )}
            </div>
            {isEditing && (
                <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center text-white text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                    Change
                </div>
            )}
        </div>
        <h2 className="text-2xl font-bold text-white">{user.name}</h2>
        <p className="text-brand-text-secondary">{user.email}</p>
        <div className="mt-2 text-xs bg-brand-bg px-2 py-1 rounded text-brand-text-secondary border border-white/5">
            Member since {new Date(user.joinedDate).toLocaleDateString()}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {isEditing ? (
            <>
                <div className="space-y-1">
                    <label className="text-sm text-brand-text-secondary">Full Name</label>
                    <input 
                        type="text" 
                        value={name} 
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-brand-bg border border-white/10 rounded-lg p-3 text-white focus:border-brand-primary outline-none"
                    />
                </div>
                <div className="space-y-1">
                    <label className="text-sm text-brand-text-secondary">Email Address</label>
                    <input 
                        type="email" 
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-brand-bg border border-white/10 rounded-lg p-3 text-white focus:border-brand-primary outline-none"
                    />
                </div>
                <div className="space-y-1">
                    <label className="text-sm text-brand-text-secondary">Avatar URL (Optional)</label>
                    <input 
                        type="text" 
                        value={avatar} 
                        onChange={(e) => setAvatar(e.target.value)}
                        placeholder="https://example.com/image.png"
                        className="w-full bg-brand-bg border border-white/10 rounded-lg p-3 text-white focus:border-brand-primary outline-none"
                    />
                </div>
            </>
        ) : (
            <div className="grid grid-cols-2 gap-4">
                <div className="bg-brand-bg/50 p-4 rounded-xl border border-white/5">
                     <p className="text-xs text-brand-text-secondary uppercase mb-1">Account Type</p>
                     <p className="font-semibold text-brand-primary">Premium</p>
                </div>
                <div className="bg-brand-bg/50 p-4 rounded-xl border border-white/5">
                     <p className="text-xs text-brand-text-secondary uppercase mb-1">Security</p>
                     <p className="font-semibold text-brand-success">Verified</p>
                </div>
            </div>
        )}

        {msg && (
            <div className={`p-3 rounded-lg text-sm text-center ${msg.type === 'success' ? 'bg-brand-success/10 text-brand-success' : 'bg-brand-danger/10 text-brand-danger'}`}>
                {msg.text}
            </div>
        )}

        <div className="pt-4 flex gap-3">
            {isEditing ? (
                <>
                    <button 
                        type="button" 
                        onClick={() => { setIsEditing(false); setMsg(null); }}
                        className="flex-1 py-2 rounded-xl text-brand-text-secondary hover:bg-white/5 transition-colors"
                    >
                        Cancel
                    </button>
                    <button 
                        type="submit" 
                        className="flex-1 py-2 rounded-xl bg-brand-primary text-white font-semibold hover:bg-brand-secondary transition-all shadow-lg"
                    >
                        Save Changes
                    </button>
                </>
            ) : (
                <button 
                    type="button" 
                    onClick={() => setIsEditing(true)}
                    className="w-full py-3 rounded-xl bg-brand-surface border border-brand-border hover:bg-brand-border text-brand-text-primary font-semibold transition-all flex items-center justify-center gap-2"
                >
                    <Icon name="advisor" className="w-5 h-5" />
                    Edit Profile
                </button>
            )}
        </div>
      </form>
    </Modal>
  );
};

export default ProfileModal;
