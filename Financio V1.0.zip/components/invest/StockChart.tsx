
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ChartDataPoint } from '../../types';

interface StockChartProps {
  data: ChartDataPoint[];
  positive: boolean;
}

const StockChart: React.FC<StockChartProps> = ({ data, positive }) => {
  const color = positive ? '#238636' : '#DA3633';
  const gradientId = `chartGradient-${positive ? 'up' : 'down'}`;

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart
        data={data}
        margin={{
          top: 5,
          right: 5,
          left: 5,
          bottom: 5,
        }}
      >
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={color} stopOpacity={0.5}/>
            <stop offset="95%" stopColor={color} stopOpacity={0}/>
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#30363D" vertical={false} opacity={0.5} />
        <XAxis 
            dataKey="date" 
            stroke="#8B949E" 
            tick={{fontSize: 10}} 
            axisLine={false} 
            tickLine={false}
            dy={5}
        />
        <YAxis 
            stroke="#8B949E" 
            domain={['auto', 'auto']} 
            tickFormatter={(value) => `$${value}`} 
            width={40}
            tick={{fontSize: 10}}
            axisLine={false}
            tickLine={false}
        />
        <Tooltip
          contentStyle={{
            backgroundColor: 'rgba(22, 27, 34, 0.9)',
            borderColor: '#30363D',
            color: '#C9D1D9',
            borderRadius: '8px'
          }}
          formatter={(value) => [`$${Number(value).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 'Price']}
          labelStyle={{ color: '#8B949E' }}
        />
        <Area 
            type="monotone" 
            dataKey="price" 
            stroke={color} 
            fillOpacity={1} 
            fill={`url(#${gradientId})`} 
            strokeWidth={2} 
            animationDuration={1000}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
};

export default StockChart;
