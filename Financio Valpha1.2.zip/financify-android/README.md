# Financify Android - Application de Gestion d'Investissements

## 📱 Description
Financify est une application Android native pour gérer vos investissements en actions, crypto-monnaies, or et comptes bancaires.

## 🌟 Fonctionnalités
- ✅ Dashboard avec vue d'ensemble du portfolio
- ✅ Suivi des actions, crypto-monnaies, or et argent
- ✅ Gestion des comptes bancaires
- ✅ Historique des transactions
- ✅ Conseiller financier IA (interface)
- ✅ Base de données SQLite locale
- ✅ Interface Material Design moderne

## 🛠️ Technologies Utilisées
- **Language**: Java
- **UI**: Material Design Components
- **Database**: SQLite
- **Architecture**: MVVM avec Fragments
- **API Level**: Min 24 (Android 7.0), Target 34 (Android 14)

## 📦 Structure du Projet

```
financify-android/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/financify/
│   │       │   ├── activities/          # Activités principales
│   │       │   ├── fragments/           # Fragments pour navigation
│   │       │   ├── models/              # Modèles de données
│   │       │   ├── adapters/            # RecyclerView adapters
│   │       │   ├── services/            # Services (DB, API)
│   │       │   └── utils/               # Utilitaires
│   │       ├── res/                     # Ressources
│   │       │   ├── layout/              # Layouts XML
│   │       │   ├── values/              # Strings, Colors, Themes
│   │       │   ├── drawable/            # Images et drawables
│   │       │   └── menu/                # Menus
│   │       └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
└── settings.gradle
```

## 🚀 Compilation et Installation

### Option 1: Utiliser Android Studio (Recommandé)
1. Installer Android Studio: https://developer.android.com/studio
2. Ouvrir le projet dans Android Studio
3. Attendre la synchronisation Gradle
4. Connecter votre téléphone Android en mode développeur (activer USB Debugging)
5. Cliquer sur "Run" (▶) ou Shift+F10

### Option 2: Compilation en ligne de commande
```bash
# 1. Installer Android SDK et configurer ANDROID_HOME
export ANDROID_HOME=/path/to/android/sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools

# 2. Donner les permissions d'exécution au gradlew
chmod +x gradlew

# 3. Compiler l'APK debug
./gradlew assembleDebug

# 4. L'APK sera dans: app/build/outputs/apk/debug/app-debug.apk

# 5. Installer sur le téléphone (avec téléphone connecté)
./gradlew installDebug
```

### Option 3: Build APK Release (pour distribution)
```bash
# Créer un keystore pour signer l'APK (une seule fois)
keytool -genkey -v -keystore financify-release.keystore -alias financify -keyalg RSA -keysize 2048 -validity 10000

# Compiler APK Release
./gradlew assembleRelease

# APK signé sera dans: app/build/outputs/apk/release/app-release.apk
```

## 📱 Installation Directe de l'APK

### Depuis votre ordinateur:
1. Activer "Sources inconnues" dans les paramètres Android
2. Transférer le fichier APK sur votre téléphone
3. Ouvrir le fichier APK sur le téléphone
4. Accepter l'installation

### Depuis ADB (Android Debug Bridge):
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

## 📋 Configuration Requise

### Pour l'appareil Android:
- Android 7.0 (API 24) ou supérieur
- 50 MB d'espace libre
- Connexion Internet (pour récupérer les prix du marché)

### Pour le développement:
- JDK 8 ou supérieur
- Android SDK (API Level 34)
- Gradle 8.0+

## 🔐 Connexion
L'application utilise un système de connexion simple :
- Entrer n'importe quel nom d'utilisateur
- Entrer une adresse email
- L'application créera automatiquement un compte avec des données de démonstration

## 📊 Données de Démonstration
À la première connexion, l'application crée automatiquement :
- **Actions**: AAPL, GOOGL, MSFT
- **Crypto**: BTC, ETH
- **Or**: Gold
- **Comptes bancaires**: Checking, Savings, Investment

## 🛡️ Sécurité
- Base de données SQLite locale
- Aucune donnée envoyée sur Internet (sauf API de prix)
- Pas de stockage de mots de passe (app de démonstration)

## 🐛 Dépannage

### Erreur "SDK not found"
```bash
# Définir ANDROID_HOME
export ANDROID_HOME=/path/to/Android/Sdk
```

### Erreur "Build failed"
```bash
# Nettoyer et rebuild
./gradlew clean
./gradlew build
```

### L'APK ne s'installe pas
- Vérifier que "Sources inconnues" est activé
- Désinstaller l'ancienne version si elle existe
- Vérifier que la version Android est >= 7.0

## 📄 Licence
Ce projet est fourni à des fins de démonstration et d'éducation.

## 👤 Auteur
Financify Team - 2024

## 🤝 Support
Pour toute question ou problème, ouvrir une issue sur le dépôt du projet.

---

## 📝 Notes de Développement

### Fichiers Manquants à Créer
Certains fichiers supplémentaires peuvent être nécessaires pour une compilation complète:

1. **fragments/** - Créer les autres fragments:
   - InvestFragment.java
   - BankingFragment.java
   - AdvisorFragment.java

2. **adapters/** - Créer les adapters:
   - AssetAdapter.java
   - BankAccountAdapter.java
   - TransactionAdapter.java

3. **layouts/** - Créer les layouts manquants:
   - fragment_dashboard.xml
   - fragment_invest.xml
   - fragment_banking.xml
   - fragment_advisor.xml
   - item_asset.xml
   - item_bank_account.xml
   - item_transaction.xml

4. **drawables/** - Ajouter les ressources:
   - splash_background.xml
   - bottom_nav_color.xml (selector)
   - ic_launcher.png (icons pour différentes densités)

5. **Configuration files**:
   - gradle.properties
   - settings.gradle
   - proguard-rules.pro

### Commandes Utiles

```bash
# Lister les appareils connectés
adb devices

# Voir les logs de l'application
adb logcat | grep Financify

# Désinstaller l'application
adb uninstall com.financify

# Prendre un screenshot
adb shell screencap -p /sdcard/screen.png
adb pull /sdcard/screen.png

# Ouvrir l'application
adb shell am start -n com.financify/.activities.SplashActivity
```

## 🎯 Roadmap Futur
- [ ] Synchronisation Cloud
- [ ] Notifications de prix
- [ ] Graphiques avancés
- [ ] Mode sombre
- [ ] Exportation PDF des rapports
- [ ] Widget pour écran d'accueil
- [ ] Biométrie pour sécurité
```
