# 📱 Guide de Compilation - Financify Android APK

## 🎯 Objectif
Ce guide vous explique comment compiler l'application Financify Android et générer l'APK pour l'installer sur votre téléphone.

## 📋 Prérequis

### Option 1: Android Studio (RECOMMANDÉ - Le plus simple)
1. Télécharger Android Studio: https://developer.android.com/studio
2. Installer Android Studio
3. Lors de l'installation, accepter l'installation du SDK Android

### Option 2: Ligne de commande (Pour utilisateurs avancés)
1. Installer Java JDK 11 ou supérieur
2. Installer Android SDK
3. Configurer les variables d'environnement

## 🚀 Méthode 1: Avec Android Studio (FACILE)

### Étape 1: Importer le projet
1. Ouvrir Android Studio
2. Cliquer sur "File" → "Open"
3. Sélectionner le dossier `financify-android`
4. Attendre la synchronisation Gradle (5-10 minutes la première fois)

### Étape 2: Compiler l'APK
1. Dans la barre de menu: "Build" → "Build Bundle(s) / APK(s)" → "Build APK(s)"
2. Attendre la compilation (2-5 minutes)
3. Une notification apparaîtra: "APK(s) generated successfully"
4. Cliquer sur "locate" pour voir l'APK

### Étape 3: Localisation de l'APK
L'APK se trouve dans:
```
financify-android/app/build/outputs/apk/debug/app-debug.apk
```

## 🚀 Méthode 2: Ligne de commande

### Sur Windows:
```cmd
cd financify-android
gradlew.bat assembleDebug
```

### Sur Mac/Linux:
```bash
cd financify-android
chmod +x gradlew
./gradlew assembleDebug
```

L'APK sera généré dans: `app/build/outputs/apk/debug/app-debug.apk`

## 📲 Installation de l'APK sur votre téléphone

### Méthode A: Transfert par câble USB
1. Connecter votre téléphone à l'ordinateur via USB
2. Copier le fichier `app-debug.apk` vers votre téléphone
3. Sur le téléphone, ouvrir le gestionnaire de fichiers
4. Localiser et appuyer sur `app-debug.apk`
5. Si demandé, autoriser l'installation d'applications de sources inconnues
6. Suivre les instructions d'installation

### Méthode B: Partage par email/cloud
1. Envoyer le fichier `app-debug.apk` par email à vous-même
2. Sur le téléphone, ouvrir l'email et télécharger l'APK
3. Ouvrir le fichier téléchargé
4. Autoriser les sources inconnues si demandé
5. Installer l'application

### Méthode C: Installation directe depuis Android Studio
1. Connecter le téléphone via USB
2. Activer "Mode développeur" sur le téléphone:
   - Aller dans Paramètres → À propos du téléphone
   - Appuyer 7 fois sur "Numéro de build"
3. Activer "Débogage USB" dans Paramètres → Options pour les développeurs
4. Dans Android Studio, cliquer sur le bouton "Run" (▶)
5. Sélectionner votre appareil dans la liste
6. L'app s'installe et se lance automatiquement

## ⚙️ Activer l'installation d'applications de sources inconnues

### Android 8.0 et supérieur:
1. Aller dans **Paramètres** → **Sécurité & confidentialité**
2. Chercher **Installer des applications inconnues**
3. Sélectionner l'application qui va installer l'APK (par exemple: Chrome, Fichiers, Gmail)
4. Activer **Autoriser cette source**

### Android 7.x et inférieur:
1. Aller dans **Paramètres** → **Sécurité**
2. Activer **Sources inconnues**

## 🔧 Dépannage

### Problème: "SDK not found"
**Solution:**
1. Dans Android Studio: File → Project Structure → SDK Location
2. Vérifier que le chemin du SDK est correct
3. Si vide, télécharger le SDK via Tools → SDK Manager

### Problème: "Build failed"
**Solutions:**
1. Nettoyer le projet:
   ```bash
   ./gradlew clean
   ```
2. Synchroniser Gradle: File → Sync Project with Gradle Files
3. Invalider les caches: File → Invalidate Caches / Restart

### Problème: "OutOfMemoryError" pendant la compilation
**Solution:**
Modifier `gradle.properties` et augmenter la mémoire:
```properties
org.gradle.jvmargs=-Xmx4096m
```

### Problème: L'APK ne s'installe pas sur le téléphone
**Solutions:**
1. Vérifier que Android >= 7.0
2. Vérifier que les sources inconnues sont autorisées
3. Désinstaller l'ancienne version si elle existe
4. Redémarrer le téléphone

### Problème: "App keeps stopping" après installation
**Solutions:**
1. Désinstaller complètement l'app
2. Vider le cache du téléphone
3. Recompiler l'APK en mode Release:
   ```bash
   ./gradlew assembleRelease
   ```

## 📊 Taille de l'APK
- **APK Debug**: ~15-20 MB
- **APK Release**: ~8-12 MB (après ProGuard/R8)

## 🔐 APK Signée (Pour distribution)

### Créer un keystore:
```bash
keytool -genkey -v -keystore financify.keystore \
  -alias financify \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

### Signer l'APK:
```bash
./gradlew assembleRelease
```

L'APK signée sera dans: `app/build/outputs/apk/release/app-release.apk`

## 📱 Utilisation de l'Application

### Première connexion:
1. Lancer l'application Financify
2. Entrer n'importe quel nom d'utilisateur (ex: "demo")
3. Entrer n'importe quel email (ex: "demo@test.com")
4. Appuyer sur "Login / Sign Up"

### Données de démonstration:
L'application crée automatiquement:
- **5 actifs** (AAPL, GOOGL, BTC, ETH, GOLD)
- **3 comptes bancaires** (Checking, Savings, Investment)
- **Portfolio total**: ~$250,000 USD

### Navigation:
- **Dashboard** 📊: Vue d'ensemble du portfolio
- **Invest** 📈: Zone d'investissement (à venir)
- **Banking** 🏦: Comptes bancaires
- **Advisor** 🤖: Conseiller IA (à venir)

## 🎉 Félicitations !
Vous avez maintenant l'application Financify installée sur votre téléphone Android !

## 📞 Support
En cas de problème, vérifier:
1. La version Android (min 7.0)
2. L'espace de stockage disponible (min 50 MB)
3. Les permissions d'installation

## 🔄 Mises à jour
Pour mettre à jour l'application:
1. Désinstaller l'ancienne version
2. Installer la nouvelle version APK

Ou simplement installer par-dessus (si même signature).
