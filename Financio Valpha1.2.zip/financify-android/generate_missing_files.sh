#!/bin/bash

# Script pour créer tous les fichiers manquants du projet Financify Android

PROJECT_DIR="/home/claude/financify-android"
echo "Génération des fichiers manquants pour Financify Android..."

# Créer fragment_dashboard.xml
cat > "$PROJECT_DIR/app/src/main/res/layout/fragment_dashboard.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/background">
    
    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:padding="16dp">
        
        <com.google.android.material.card.MaterialCardView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            style="@style/CardStyle">
            
            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:padding="16dp">
                
                <TextView
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Total Portfolio Value"
                    style="@style/SubtitleTextStyle" />
                
                <TextView
                    android:id="@+id/totalBalanceText"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="$0.00"
                    android:textSize="32sp"
                    android:textStyle="bold"
                    android:textColor="@color/text_primary" />
                
                <TextView
                    android:id="@+id/portfolioChangeText"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="+0.00%"
                    android:textSize="18sp"
                    android:textStyle="bold" />
            </LinearLayout>
        </com.google.android.material.card.MaterialCardView>
        
        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="16dp"
            android:layout_marginBottom="8dp"
            android:text="My Assets"
            style="@style/TitleTextStyle" />
        
        <androidx.recyclerview.widget.RecyclerView
            android:id="@+id/assetsRecyclerView"
            android:layout_width="match_parent"
            android:layout_height="wrap_content" />
    </LinearLayout>
</ScrollView>
EOF

# Créer fragment_invest.xml
cat > "$PROJECT_DIR/app/src/main/res/layout/fragment_invest.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="16dp"
    android:gravity="center">
    
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="📈"
        android:textSize="64sp" />
    
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Invest"
        style="@style/TitleTextStyle"
        android:layout_marginTop="16dp" />
    
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Search and trade stocks, crypto, and commodities"
        style="@style/SubtitleTextStyle"
        android:layout_marginTop="8dp"
        android:textAlignment="center" />
</LinearLayout>
EOF

# Créer fragment_banking.xml
cat > "$PROJECT_DIR/app/src/main/res/layout/fragment_banking.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="16dp">
    
    <TextView
        android:id="@+id/totalBankBalanceText"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Total: $0.00"
        style="@style/TitleTextStyle"
        android:layout_marginBottom="16dp" />
    
    <androidx.recyclerview.widget.RecyclerView
        android:id="@+id/bankAccountsRecyclerView"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
</LinearLayout>
EOF

# Créer item_asset.xml
cat > "$PROJECT_DIR/app/src/main/res/layout/item_asset.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<com.google.android.material.card.MaterialCardView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    style="@style/CardStyle">
    
    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:padding="16dp">
        
        <LinearLayout
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:orientation="vertical">
            
            <TextView
                android:id="@+id/assetSymbolText"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="BTC"
                android:textStyle="bold"
                android:textSize="16sp" />
            
            <TextView
                android:id="@+id/assetNameText"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Bitcoin"
                style="@style/CaptionTextStyle" />
        </LinearLayout>
        
        <LinearLayout
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            android:gravity="end">
            
            <TextView
                android:id="@+id/assetPriceText"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="$43,500.00"
                style="@style/BodyTextStyle" />
            
            <TextView
                android:id="@+id/assetChangeText"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="+2.5%"
                style="@style/CaptionTextStyle" />
        </LinearLayout>
        
        <TextView
            android:id="@+id/assetValueText"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginStart="16dp"
            android:text="$21,750.00"
            android:textStyle="bold"
            android:textSize="16sp" />
    </LinearLayout>
</com.google.android.material.card.MaterialCardView>
EOF

# Créer item_bank_account.xml
cat > "$PROJECT_DIR/app/src/main/res/layout/item_bank_account.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<com.google.android.material.card.MaterialCardView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    style="@style/CardStyle">
    
    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:padding="16dp">
        
        <TextView
            android:id="@+id/accountNameText"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Main Checking"
            android:textStyle="bold"
            android:textSize="18sp" />
        
        <TextView
            android:id="@+id/accountNumberText"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="****1234"
            style="@style/CaptionTextStyle"
            android:layout_marginTop="4dp" />
        
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:layout_marginTop="8dp">
            
            <TextView
                android:id="@+id/accountTypeText"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="Checking"
                style="@style/CaptionTextStyle" />
            
            <TextView
                android:id="@+id/accountBalanceText"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="$25,000.00"
                android:textStyle="bold"
                android:textSize="18sp"
                android:textColor="@color/profit_green" />
        </LinearLayout>
    </LinearLayout>
</com.google.android.material.card.MaterialCardView>
EOF

# Créer bottom_nav_color.xml
cat > "$PROJECT_DIR/app/src/main/res/drawable/bottom_nav_color.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<selector xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:color="@color/primary" android:state_checked="true" />
    <item android:color="@color/text_secondary" />
</selector>
EOF

# Créer splash_background.xml
cat > "$PROJECT_DIR/app/src/main/res/drawable/splash_background.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@color/primary" />
</layer-list>
EOF

# Créer backup_rules.xml
mkdir -p "$PROJECT_DIR/app/src/main/res/xml"
cat > "$PROJECT_DIR/app/src/main/res/xml/backup_rules.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<full-backup-content>
    <include domain="sharedpref" path="." />
    <include domain="database" path="." />
</full-backup-content>
EOF

# Créer data_extraction_rules.xml
cat > "$PROJECT_DIR/app/src/main/res/xml/data_extraction_rules.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <include domain="sharedpref" path="." />
        <include domain="database" path="." />
    </cloud-backup>
</data-extraction-rules>
EOF

# Créer proguard-rules.pro
cat > "$PROJECT_DIR/app/proguard-rules.pro" << 'EOF'
# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keep public class * extends java.lang.Exception

# Keep models
-keep class com.financify.models.** { *; }

# SQLite
-keep class ** extends android.database.sqlite.SQLiteOpenHelper { *; }

# Gson
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
EOF

echo "✅ Tous les fichiers manquants ont été créés!"
echo "📱 Le projet est maintenant prêt pour compilation"
echo ""
echo "Pour compiler l'APK:"
echo "  cd $PROJECT_DIR"
echo "  ./gradlew assembleDebug"
echo ""
echo "L'APK sera dans: app/build/outputs/apk/debug/app-debug.apk"
