package com.financify.models;

import java.io.Serializable;
import java.util.Date;

/**
 * Represents a financial asset (Stock, Crypto, Gold, etc.)
 */
public class Asset implements Serializable {
    
    private long id;
    private String symbol;
    private String name;
    private AssetType type;
    private double currentPrice;
    private double previousPrice;
    private double changePercent;
    private double quantity;
    private double totalValue;
    private Date lastUpdated;
    private String userId;
    
    public enum AssetType {
        STOCK("Stock", "📈"),
        CRYPTO("Crypto", "₿"),
        GOLD("Gold", "🥇"),
        SILVER("Silver", "🥈"),
        COMMODITY("Commodity", "📦");
        
        private final String displayName;
        private final String icon;
        
        AssetType(String displayName, String icon) {
            this.displayName = displayName;
            this.icon = icon;
        }
        
        public String getDisplayName() {
            return displayName;
        }
        
        public String getIcon() {
            return icon;
        }
    }
    
    // Constructors
    public Asset() {
        this.lastUpdated = new Date();
    }
    
    public Asset(String symbol, String name, AssetType type) {
        this();
        this.symbol = symbol;
        this.name = name;
        this.type = type;
    }
    
    // Getters and Setters
    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }
    
    public String getSymbol() {
        return symbol;
    }
    
    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public AssetType getType() {
        return type;
    }
    
    public void setType(AssetType type) {
        this.type = type;
    }
    
    public double getCurrentPrice() {
        return currentPrice;
    }
    
    public void setCurrentPrice(double currentPrice) {
        this.currentPrice = currentPrice;
        calculateChangePercent();
        calculateTotalValue();
    }
    
    public double getPreviousPrice() {
        return previousPrice;
    }
    
    public void setPreviousPrice(double previousPrice) {
        this.previousPrice = previousPrice;
        calculateChangePercent();
    }
    
    public double getChangePercent() {
        return changePercent;
    }
    
    private void calculateChangePercent() {
        if (previousPrice > 0) {
            this.changePercent = ((currentPrice - previousPrice) / previousPrice) * 100;
        }
    }
    
    public double getQuantity() {
        return quantity;
    }
    
    public void setQuantity(double quantity) {
        this.quantity = quantity;
        calculateTotalValue();
    }
    
    public double getTotalValue() {
        return totalValue;
    }
    
    private void calculateTotalValue() {
        this.totalValue = currentPrice * quantity;
    }
    
    public Date getLastUpdated() {
        return lastUpdated;
    }
    
    public void setLastUpdated(Date lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
    
    public String getUserId() {
        return userId;
    }
    
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public boolean isPositiveChange() {
        return changePercent >= 0;
    }
    
    public String getFormattedPrice() {
        return String.format("$%.2f", currentPrice);
    }
    
    public String getFormattedChange() {
        return String.format("%+.2f%%", changePercent);
    }
    
    public String getFormattedTotalValue() {
        return String.format("$%.2f", totalValue);
    }
    
    public String getFormattedQuantity() {
        if (type == AssetType.CRYPTO) {
            return String.format("%.6f", quantity);
        } else {
            return String.format("%.2f", quantity);
        }
    }
    
    @Override
    public String toString() {
        return String.format("%s (%s) - %s @ %s", name, symbol, type.getDisplayName(), getFormattedPrice());
    }
}
