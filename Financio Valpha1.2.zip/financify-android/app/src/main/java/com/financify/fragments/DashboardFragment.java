package com.financify.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.financify.FinancifyApplication;
import com.financify.R;
import com.financify.adapters.AssetAdapter;
import com.financify.models.Asset;
import com.financify.services.DatabaseHelper;
import com.financify.services.PreferenceManager;

import java.util.List;

/**
 * Dashboard Fragment showing portfolio overview
 */
public class DashboardFragment extends Fragment {
    
    private TextView totalBalanceText;
    private TextView portfolioChangeText;
    private RecyclerView assetsRecyclerView;
    private AssetAdapter assetAdapter;
    
    private DatabaseHelper databaseHelper;
    private PreferenceManager preferenceManager;
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);
        
        databaseHelper = FinancifyApplication.getInstance().getDatabaseHelper();
        preferenceManager = FinancifyApplication.getInstance().getPreferenceManager();
        
        initializeViews(view);
        loadData();
        
        return view;
    }
    
    private void initializeViews(View view) {
        totalBalanceText = view.findViewById(R.id.totalBalanceText);
        portfolioChangeText = view.findViewById(R.id.portfolioChangeText);
        assetsRecyclerView = view.findViewById(R.id.assetsRecyclerView);
        
        assetsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
    }
    
    private void loadData() {
        long userId = preferenceManager.getUserId();
        List<Asset> assets = databaseHelper.getAssetsByUser(userId);
        
        // Calculate total portfolio value
        double totalValue = assets.stream()
                .mapToDouble(Asset::getTotalValue)
                .sum();
        
        // Calculate total change
        double totalChange = assets.stream()
                .mapToDouble(a -> (a.getCurrentPrice() - a.getPreviousPrice()) * a.getQuantity())
                .sum();
        
        double changePercent = totalValue > 0 ? (totalChange / (totalValue - totalChange)) * 100 : 0;
        
        // Update UI
        totalBalanceText.setText(String.format("$%.2f", totalValue));
        portfolioChangeText.setText(String.format("%+.2f%%", changePercent));
        portfolioChangeText.setTextColor(getResources().getColor(
                changePercent >= 0 ? R.color.profit_green : R.color.loss_red, null));
        
        // Setup RecyclerView
        assetAdapter = new AssetAdapter(getContext(), assets);
        assetsRecyclerView.setAdapter(assetAdapter);
    }
    
    @Override
    public void onResume() {
        super.onResume();
        loadData(); // Refresh data when fragment resumes
    }
}
