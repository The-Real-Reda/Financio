package com.financify.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.financify.FinancifyApplication;
import com.financify.R;
import com.financify.models.User;
import com.financify.services.DatabaseHelper;
import com.financify.services.PreferenceManager;

import java.util.Date;

/**
 * Login Activity
 */
public class LoginActivity extends AppCompatActivity {
    
    private EditText usernameInput;
    private EditText emailInput;
    private Button loginButton;
    
    private DatabaseHelper databaseHelper;
    private PreferenceManager preferenceManager;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        
        databaseHelper = FinancifyApplication.getInstance().getDatabaseHelper();
        preferenceManager = FinancifyApplication.getInstance().getPreferenceManager();
        
        initializeViews();
        setupListeners();
    }
    
    private void initializeViews() {
        usernameInput = findViewById(R.id.usernameInput);
        emailInput = findViewById(R.id.emailInput);
        loginButton = findViewById(R.id.loginButton);
    }
    
    private void setupListeners() {
        loginButton.setOnAction(v -> handleLogin());
    }
    
    private void handleLogin() {
        String username = usernameInput.getText().toString().trim();
        String email = emailInput.getText().toString().trim();
        
        if (username.isEmpty()) {
            Toast.makeText(this, "Please enter username", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if (email.isEmpty()) {
            Toast.makeText(this, "Please enter email", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Check if user exists
        User existingUser = databaseHelper.getUserByUsername(username);
        
        if (existingUser == null) {
            // Create new user
            User newUser = new User(username, email);
            newUser.setFirstName("Demo");
            newUser.setLastName("User");
            newUser.setCountry("Morocco");
            newUser.setCreatedDate(new Date());
            newUser.setLastLogin(new Date());
            
            long userId = databaseHelper.insertUser(newUser);
            newUser.setId(userId);
            
            // Create demo data
            createDemoData(userId);
            
            saveUserToPreferences(newUser);
        } else {
            // Update last login
            existingUser.setLastLogin(new Date());
            saveUserToPreferences(existingUser);
        }
        
        // Navigate to main activity
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
    
    private void saveUserToPreferences(User user) {
        preferenceManager.setLoggedIn(true);
        preferenceManager.setUserId(user.getId());
        preferenceManager.setUsername(user.getUsername());
        preferenceManager.setEmail(user.getEmail());
        preferenceManager.setFirstName(user.getFirstName());
        preferenceManager.setLastName(user.getLastName());
    }
    
    private void createDemoData(long userId) {
        // Create demo assets
        createDemoAsset(userId, "AAPL", "Apple Inc.", com.financify.models.Asset.AssetType.STOCK, 175.50, 173.20, 10);
        createDemoAsset(userId, "GOOGL", "Alphabet Inc.", com.financify.models.Asset.AssetType.STOCK, 142.30, 140.80, 15);
        createDemoAsset(userId, "BTC", "Bitcoin", com.financify.models.Asset.AssetType.CRYPTO, 43500.00, 42800.00, 0.5);
        createDemoAsset(userId, "ETH", "Ethereum", com.financify.models.Asset.AssetType.CRYPTO, 2350.00, 2310.00, 2.5);
        createDemoAsset(userId, "GOLD", "Gold", com.financify.models.Asset.AssetType.GOLD, 2050.50, 2045.00, 5);
        
        // Create demo bank accounts
        createDemoBankAccount(userId, "1234567890", "Main Checking", com.financify.models.BankAccount.AccountType.CHECKING, 25000.00);
        createDemoBankAccount(userId, "0987654321", "Savings Account", com.financify.models.BankAccount.AccountType.SAVINGS, 50000.00);
        createDemoBankAccount(userId, "5555666677", "Investment Account", com.financify.models.BankAccount.AccountType.INVESTMENT, 150000.00);
    }
    
    private void createDemoAsset(long userId, String symbol, String name, 
                                  com.financify.models.Asset.AssetType type,
                                  double currentPrice, double previousPrice, double quantity) {
        com.financify.models.Asset asset = new com.financify.models.Asset(symbol, name, type);
        asset.setCurrentPrice(currentPrice);
        asset.setPreviousPrice(previousPrice);
        asset.setQuantity(quantity);
        asset.setLastUpdated(new Date());
        databaseHelper.insertAsset(asset, userId);
    }
    
    private void createDemoBankAccount(long userId, String accountNumber, String accountName,
                                       com.financify.models.BankAccount.AccountType type, double balance) {
        com.financify.models.BankAccount account = new com.financify.models.BankAccount(accountNumber, accountName, type);
        account.setBalance(balance);
        account.setCreatedDate(new Date());
        databaseHelper.insertBankAccount(account, userId);
    }
}
