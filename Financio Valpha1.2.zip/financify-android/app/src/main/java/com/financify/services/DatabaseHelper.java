package com.financify.services;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.financify.models.Asset;
import com.financify.models.BankAccount;
import com.financify.models.Transaction;
import com.financify.models.User;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * SQLite Database Helper for Financify
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    
    private static final String DATABASE_NAME = "financify.db";
    private static final int DATABASE_VERSION = 1;
    
    private static final SimpleDateFormat DATE_FORMAT = 
        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
    
    // Table Names
    private static final String TABLE_USERS = "users";
    private static final String TABLE_ASSETS = "assets";
    private static final String TABLE_ACCOUNTS = "bank_accounts";
    private static final String TABLE_TRANSACTIONS = "transactions";
    
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "email TEXT UNIQUE NOT NULL, " +
                "first_name TEXT, " +
                "last_name TEXT, " +
                "phone TEXT, " +
                "country TEXT, " +
                "created_date TEXT NOT NULL, " +
                "last_login TEXT, " +
                "profile_image_url TEXT)";
        db.execSQL(createUsersTable);
        
        // Create Assets table
        String createAssetsTable = "CREATE TABLE " + TABLE_ASSETS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "symbol TEXT NOT NULL, " +
                "name TEXT NOT NULL, " +
                "type TEXT NOT NULL, " +
                "current_price REAL NOT NULL, " +
                "previous_price REAL, " +
                "quantity REAL NOT NULL, " +
                "last_updated TEXT NOT NULL, " +
                "FOREIGN KEY (user_id) REFERENCES " + TABLE_USERS + "(id))";
        db.execSQL(createAssetsTable);
        
        // Create Bank Accounts table
        String createAccountsTable = "CREATE TABLE " + TABLE_ACCOUNTS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "account_number TEXT UNIQUE NOT NULL, " +
                "account_name TEXT NOT NULL, " +
                "type TEXT NOT NULL, " +
                "balance REAL NOT NULL, " +
                "currency TEXT NOT NULL, " +
                "is_active INTEGER NOT NULL, " +
                "created_date TEXT NOT NULL, " +
                "FOREIGN KEY (user_id) REFERENCES " + TABLE_USERS + "(id))";
        db.execSQL(createAccountsTable);
        
        // Create Transactions table
        String createTransactionsTable = "CREATE TABLE " + TABLE_TRANSACTIONS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "account_id INTEGER NOT NULL, " +
                "type TEXT NOT NULL, " +
                "amount REAL NOT NULL, " +
                "description TEXT, " +
                "category TEXT, " +
                "transaction_date TEXT NOT NULL, " +
                "status TEXT NOT NULL, " +
                "FOREIGN KEY (account_id) REFERENCES " + TABLE_ACCOUNTS + "(id))";
        db.execSQL(createTransactionsTable);
    }
    
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRANSACTIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ACCOUNTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ASSETS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }
    
    // USER OPERATIONS
    public long insertUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", user.getUsername());
        values.put("email", user.getEmail());
        values.put("first_name", user.getFirstName());
        values.put("last_name", user.getLastName());
        values.put("phone", user.getPhone());
        values.put("country", user.getCountry());
        values.put("created_date", DATE_FORMAT.format(user.getCreatedDate()));
        if (user.getLastLogin() != null) {
            values.put("last_login", DATE_FORMAT.format(user.getLastLogin()));
        }
        values.put("profile_image_url", user.getProfileImageUrl());
        
        long id = db.insert(TABLE_USERS, null, values);
        user.setId(id);
        return id;
    }
    
    public User getUserByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, "username = ?", 
                new String[]{username}, null, null, null);
        
        User user = null;
        if (cursor.moveToFirst()) {
            user = cursorToUser(cursor);
        }
        cursor.close();
        return user;
    }
    
    public User getUserById(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, "id = ?", 
                new String[]{String.valueOf(userId)}, null, null, null);
        
        User user = null;
        if (cursor.moveToFirst()) {
            user = cursorToUser(cursor);
        }
        cursor.close();
        return user;
    }
    
    private User cursorToUser(Cursor cursor) {
        User user = new User();
        user.setId(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
        user.setUsername(cursor.getString(cursor.getColumnIndexOrThrow("username")));
        user.setEmail(cursor.getString(cursor.getColumnIndexOrThrow("email")));
        user.setFirstName(cursor.getString(cursor.getColumnIndexOrThrow("first_name")));
        user.setLastName(cursor.getString(cursor.getColumnIndexOrThrow("last_name")));
        user.setPhone(cursor.getString(cursor.getColumnIndexOrThrow("phone")));
        user.setCountry(cursor.getString(cursor.getColumnIndexOrThrow("country")));
        
        try {
            String createdDateStr = cursor.getString(cursor.getColumnIndexOrThrow("created_date"));
            user.setCreatedDate(DATE_FORMAT.parse(createdDateStr));
            
            String lastLoginStr = cursor.getString(cursor.getColumnIndexOrThrow("last_login"));
            if (lastLoginStr != null) {
                user.setLastLogin(DATE_FORMAT.parse(lastLoginStr));
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        
        user.setProfileImageUrl(cursor.getString(cursor.getColumnIndexOrThrow("profile_image_url")));
        return user;
    }
    
    // ASSET OPERATIONS
    public long insertAsset(Asset asset, long userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("symbol", asset.getSymbol());
        values.put("name", asset.getName());
        values.put("type", asset.getType().name());
        values.put("current_price", asset.getCurrentPrice());
        values.put("previous_price", asset.getPreviousPrice());
        values.put("quantity", asset.getQuantity());
        values.put("last_updated", DATE_FORMAT.format(asset.getLastUpdated()));
        
        long id = db.insert(TABLE_ASSETS, null, values);
        asset.setId(id);
        return id;
    }
    
    public List<Asset> getAssetsByUser(long userId) {
        List<Asset> assets = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ASSETS, null, "user_id = ?", 
                new String[]{String.valueOf(userId)}, null, null, "symbol");
        
        if (cursor.moveToFirst()) {
            do {
                assets.add(cursorToAsset(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return assets;
    }
    
    public void updateAsset(Asset asset) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("current_price", asset.getCurrentPrice());
        values.put("previous_price", asset.getPreviousPrice());
        values.put("quantity", asset.getQuantity());
        values.put("last_updated", DATE_FORMAT.format(new Date()));
        
        db.update(TABLE_ASSETS, values, "id = ?", 
                new String[]{String.valueOf(asset.getId())});
    }
    
    private Asset cursorToAsset(Cursor cursor) {
        Asset asset = new Asset();
        asset.setId(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
        asset.setSymbol(cursor.getString(cursor.getColumnIndexOrThrow("symbol")));
        asset.setName(cursor.getString(cursor.getColumnIndexOrThrow("name")));
        asset.setType(Asset.AssetType.valueOf(cursor.getString(cursor.getColumnIndexOrThrow("type"))));
        asset.setCurrentPrice(cursor.getDouble(cursor.getColumnIndexOrThrow("current_price")));
        asset.setPreviousPrice(cursor.getDouble(cursor.getColumnIndexOrThrow("previous_price")));
        asset.setQuantity(cursor.getDouble(cursor.getColumnIndexOrThrow("quantity")));
        
        try {
            String dateStr = cursor.getString(cursor.getColumnIndexOrThrow("last_updated"));
            asset.setLastUpdated(DATE_FORMAT.parse(dateStr));
        } catch (ParseException e) {
            asset.setLastUpdated(new Date());
        }
        
        return asset;
    }
    
    // BANK ACCOUNT OPERATIONS
    public long insertBankAccount(BankAccount account, long userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("account_number", account.getAccountNumber());
        values.put("account_name", account.getAccountName());
        values.put("type", account.getType().name());
        values.put("balance", account.getBalance());
        values.put("currency", account.getCurrency());
        values.put("is_active", account.isActive() ? 1 : 0);
        values.put("created_date", DATE_FORMAT.format(account.getCreatedDate()));
        
        long id = db.insert(TABLE_ACCOUNTS, null, values);
        account.setId(id);
        return id;
    }
    
    public List<BankAccount> getBankAccountsByUser(long userId) {
        List<BankAccount> accounts = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ACCOUNTS, null, "user_id = ?", 
                new String[]{String.valueOf(userId)}, null, null, "created_date DESC");
        
        if (cursor.moveToFirst()) {
            do {
                accounts.add(cursorToBankAccount(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return accounts;
    }
    
    private BankAccount cursorToBankAccount(Cursor cursor) {
        BankAccount account = new BankAccount();
        account.setId(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
        account.setAccountNumber(cursor.getString(cursor.getColumnIndexOrThrow("account_number")));
        account.setAccountName(cursor.getString(cursor.getColumnIndexOrThrow("account_name")));
        account.setType(BankAccount.AccountType.valueOf(cursor.getString(cursor.getColumnIndexOrThrow("type"))));
        account.setBalance(cursor.getDouble(cursor.getColumnIndexOrThrow("balance")));
        account.setCurrency(cursor.getString(cursor.getColumnIndexOrThrow("currency")));
        account.setActive(cursor.getInt(cursor.getColumnIndexOrThrow("is_active")) == 1);
        
        try {
            String dateStr = cursor.getString(cursor.getColumnIndexOrThrow("created_date"));
            account.setCreatedDate(DATE_FORMAT.parse(dateStr));
        } catch (ParseException e) {
            account.setCreatedDate(new Date());
        }
        
        return account;
    }
    
    // TRANSACTION OPERATIONS
    public long insertTransaction(Transaction transaction) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("account_id", transaction.getAccountId());
        values.put("type", transaction.getType().name());
        values.put("amount", transaction.getAmount());
        values.put("description", transaction.getDescription());
        values.put("category", transaction.getCategory());
        values.put("transaction_date", DATE_FORMAT.format(transaction.getTransactionDate()));
        values.put("status", transaction.getStatus().name());
        
        long id = db.insert(TABLE_TRANSACTIONS, null, values);
        transaction.setId(id);
        return id;
    }
    
    public List<Transaction> getTransactionsByAccount(long accountId) {
        List<Transaction> transactions = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_TRANSACTIONS, null, "account_id = ?", 
                new String[]{String.valueOf(accountId)}, null, null, "transaction_date DESC");
        
        if (cursor.moveToFirst()) {
            do {
                transactions.add(cursorToTransaction(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return transactions;
    }
    
    private Transaction cursorToTransaction(Cursor cursor) {
        Transaction transaction = new Transaction();
        transaction.setId(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
        transaction.setAccountId(cursor.getLong(cursor.getColumnIndexOrThrow("account_id")));
        transaction.setType(Transaction.TransactionType.valueOf(cursor.getString(cursor.getColumnIndexOrThrow("type"))));
        transaction.setAmount(cursor.getDouble(cursor.getColumnIndexOrThrow("amount")));
        transaction.setDescription(cursor.getString(cursor.getColumnIndexOrThrow("description")));
        transaction.setCategory(cursor.getString(cursor.getColumnIndexOrThrow("category")));
        transaction.setStatus(Transaction.TransactionStatus.valueOf(cursor.getString(cursor.getColumnIndexOrThrow("status"))));
        
        try {
            String dateStr = cursor.getString(cursor.getColumnIndexOrThrow("transaction_date"));
            transaction.setTransactionDate(DATE_FORMAT.parse(dateStr));
        } catch (ParseException e) {
            transaction.setTransactionDate(new Date());
        }
        
        return transaction;
    }
}
