package com.financify.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Represents a bank account
 */
public class BankAccount implements Serializable {
    
    private long id;
    private String accountNumber;
    private String accountName;
    private AccountType type;
    private double balance;
    private String currency;
    private boolean isActive;
    private Date createdDate;
    private String userId;
    private List<Transaction> transactions;
    
    public enum AccountType {
        CHECKING("Checking Account", "💳"),
        SAVINGS("Savings Account", "💰"),
        INVESTMENT("Investment Account", "📊"),
        CREDIT("Credit Card", "💳");
        
        private final String displayName;
        private final String icon;
        
        AccountType(String displayName, String icon) {
            this.displayName = displayName;
            this.icon = icon;
        }
        
        public String getDisplayName() {
            return displayName;
        }
        
        public String getIcon() {
            return icon;
        }
    }
    
    // Constructor
    public BankAccount() {
        this.currency = "USD";
        this.isActive = true;
        this.createdDate = new Date();
        this.transactions = new ArrayList<>();
    }
    
    public BankAccount(String accountNumber, String accountName, AccountType type) {
        this();
        this.accountNumber = accountNumber;
        this.accountName = accountName;
        this.type = type;
    }
    
    // Getters and Setters
    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }
    
    public String getAccountNumber() {
        return accountNumber;
    }
    
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
    
    public String getAccountName() {
        return accountName;
    }
    
    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }
    
    public AccountType getType() {
        return type;
    }
    
    public void setType(AccountType type) {
        this.type = type;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public void setBalance(double balance) {
        this.balance = balance;
    }
    
    public String getCurrency() {
        return currency;
    }
    
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean active) {
        isActive = active;
    }
    
    public Date getCreatedDate() {
        return createdDate;
    }
    
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
    
    public String getUserId() {
        return userId;
    }
    
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public List<Transaction> getTransactions() {
        return transactions;
    }
    
    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions;
    }
    
    public void addTransaction(Transaction transaction) {
        this.transactions.add(transaction);
        updateBalance(transaction);
    }
    
    private void updateBalance(Transaction transaction) {
        if (transaction.getType() == Transaction.TransactionType.DEPOSIT || 
            transaction.getType() == Transaction.TransactionType.CREDIT) {
            this.balance += transaction.getAmount();
        } else {
            this.balance -= transaction.getAmount();
        }
    }
    
    public String getFormattedBalance() {
        return String.format("%s %.2f", currency, balance);
    }
    
    public String getMaskedAccountNumber() {
        if (accountNumber != null && accountNumber.length() >= 4) {
            return "****" + accountNumber.substring(accountNumber.length() - 4);
        }
        return accountNumber;
    }
    
    @Override
    public String toString() {
        return String.format("%s (%s) - %s", accountName, getMaskedAccountNumber(), getFormattedBalance());
    }
}
