package com.financify.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.financify.R;
import com.financify.fragments.DashboardFragment;
import com.financify.fragments.InvestFragment;
import com.financify.fragments.BankingFragment;
import com.financify.fragments.AdvisorFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * Main Activity with bottom navigation
 */
public class MainActivity extends AppCompatActivity {
    
    private BottomNavigationView bottomNavigationView;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initializeViews();
        setupBottomNavigation();
        
        // Load default fragment
        if (savedInstanceState == null) {
            loadFragment(new DashboardFragment());
        }
    }
    
    private void initializeViews() {
        bottomNavigationView = findViewById(R.id.bottomNavigation);
    }
    
    private void setupBottomNavigation() {
        bottomNavigationView.setOnItemSelectedListener(item -> {
            Fragment fragment = null;
            int itemId = item.getItemId();
            
            if (itemId == R.id.nav_dashboard) {
                fragment = new DashboardFragment();
            } else if (itemId == R.id.nav_invest) {
                fragment = new InvestFragment();
            } else if (itemId == R.id.nav_banking) {
                fragment = new BankingFragment();
            } else if (itemId == R.id.nav_advisor) {
                fragment = new AdvisorFragment();
            }
            
            return fragment != null && loadFragment(fragment);
        });
    }
    
    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragmentContainer, fragment)
                    .commit();
            return true;
        }
        return false;
    }
}
