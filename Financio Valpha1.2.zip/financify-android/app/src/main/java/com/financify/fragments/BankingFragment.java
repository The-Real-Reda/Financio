package com.financify.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.financify.FinancifyApplication;
import com.financify.R;
import com.financify.adapters.BankAccountAdapter;
import com.financify.models.BankAccount;
import com.financify.services.DatabaseHelper;
import com.financify.services.PreferenceManager;
import java.util.List;

public class BankingFragment extends Fragment {
    private RecyclerView accountsRecyclerView;
    private TextView totalBalanceText;
    
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_banking, container, false);
        
        DatabaseHelper db = FinancifyApplication.getInstance().getDatabaseHelper();
        PreferenceManager prefs = FinancifyApplication.getInstance().getPreferenceManager();
        
        totalBalanceText = view.findViewById(R.id.totalBankBalanceText);
        accountsRecyclerView = view.findViewById(R.id.bankAccountsRecyclerView);
        accountsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        
        List<BankAccount> accounts = db.getBankAccountsByUser(prefs.getUserId());
        double total = accounts.stream().mapToDouble(BankAccount::getBalance).sum();
        
        totalBalanceText.setText(String.format("Total: $%.2f", total));
        accountsRecyclerView.setAdapter(new BankAccountAdapter(getContext(), accounts));
        
        return view;
    }
}
