package com.financify.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.financify.R;
import com.financify.models.Asset;
import java.util.List;

public class AssetAdapter extends RecyclerView.Adapter<AssetAdapter.ViewHolder> {
    private Context context;
    private List<Asset> assets;
    
    public AssetAdapter(Context context, List<Asset> assets) {
        this.context = context;
        this.assets = assets;
    }
    
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_asset, parent, false);
        return new ViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Asset asset = assets.get(position);
        holder.symbolText.setText(asset.getType().getIcon() + " " + asset.getSymbol());
        holder.nameText.setText(asset.getName());
        holder.priceText.setText(asset.getFormattedPrice());
        holder.changeText.setText(asset.getFormattedChange());
        holder.changeText.setTextColor(context.getResources().getColor(
            asset.isPositiveChange() ? R.color.profit_green : R.color.loss_red, null));
        holder.valueText.setText(asset.getFormattedTotalValue());
    }
    
    @Override
    public int getItemCount() {
        return assets.size();
    }
    
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView symbolText, nameText, priceText, changeText, valueText;
        
        ViewHolder(View view) {
            super(view);
            symbolText = view.findViewById(R.id.assetSymbolText);
            nameText = view.findViewById(R.id.assetNameText);
            priceText = view.findViewById(R.id.assetPriceText);
            changeText = view.findViewById(R.id.assetChangeText);
            valueText = view.findViewById(R.id.assetValueText);
        }
    }
}
