package com.financify;

import android.app.Application;
import com.financify.services.DatabaseHelper;
import com.financify.services.PreferenceManager;

/**
 * Main Application class for Financify
 */
public class FinancifyApplication extends Application {
    
    private static FinancifyApplication instance;
    private DatabaseHelper databaseHelper;
    private PreferenceManager preferenceManager;
    
    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        
        // Initialize services
        databaseHelper = new DatabaseHelper(this);
        preferenceManager = new PreferenceManager(this);
    }
    
    public static FinancifyApplication getInstance() {
        return instance;
    }
    
    public DatabaseHelper getDatabaseHelper() {
        return databaseHelper;
    }
    
    public PreferenceManager getPreferenceManager() {
        return preferenceManager;
    }
}
