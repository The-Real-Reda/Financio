package com.financify.services;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Manages shared preferences for the application
 */
public class PreferenceManager {
    
    private static final String PREF_NAME = "FinancifyPrefs";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_ID = "userId";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_FIRST_NAME = "firstName";
    private static final String KEY_LAST_NAME = "lastName";
    
    private final SharedPreferences preferences;
    private final SharedPreferences.Editor editor;
    
    public PreferenceManager(Context context) {
        preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = preferences.edit();
    }
    
    public void setLoggedIn(boolean isLoggedIn) {
        editor.putBoolean(KEY_IS_LOGGED_IN, isLoggedIn);
        editor.apply();
    }
    
    public boolean isLoggedIn() {
        return preferences.getBoolean(KEY_IS_LOGGED_IN, false);
    }
    
    public void setUserId(long userId) {
        editor.putLong(KEY_USER_ID, userId);
        editor.apply();
    }
    
    public long getUserId() {
        return preferences.getLong(KEY_USER_ID, -1);
    }
    
    public void setUsername(String username) {
        editor.putString(KEY_USERNAME, username);
        editor.apply();
    }
    
    public String getUsername() {
        return preferences.getString(KEY_USERNAME, "");
    }
    
    public void setEmail(String email) {
        editor.putString(KEY_EMAIL, email);
        editor.apply();
    }
    
    public String getEmail() {
        return preferences.getString(KEY_EMAIL, "");
    }
    
    public void setFirstName(String firstName) {
        editor.putString(KEY_FIRST_NAME, firstName);
        editor.apply();
    }
    
    public String getFirstName() {
        return preferences.getString(KEY_FIRST_NAME, "");
    }
    
    public void setLastName(String lastName) {
        editor.putString(KEY_LAST_NAME, lastName);
        editor.apply();
    }
    
    public String getLastName() {
        return preferences.getString(KEY_LAST_NAME, "");
    }
    
    public String getFullName() {
        String firstName = getFirstName();
        String lastName = getLastName();
        
        if (!firstName.isEmpty() && !lastName.isEmpty()) {
            return firstName + " " + lastName;
        } else if (!firstName.isEmpty()) {
            return firstName;
        } else if (!lastName.isEmpty()) {
            return lastName;
        }
        return getUsername();
    }
    
    public void clearAll() {
        editor.clear();
        editor.apply();
    }
}
