package com.financify.models;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Represents a financial transaction
 */
public class Transaction implements Serializable {
    
    private long id;
    private long accountId;
    private TransactionType type;
    private double amount;
    private String description;
    private String category;
    private Date transactionDate;
    private TransactionStatus status;
    
    public enum TransactionType {
        DEPOSIT("Deposit", "+", "💵"),
        WITHDRAWAL("Withdrawal", "-", "💸"),
        TRANSFER("Transfer", "↔", "🔄"),
        PURCHASE("Purchase", "-", "🛒"),
        SALE("Sale", "+", "💰"),
        CREDIT("Credit", "+", "➕"),
        DEBIT("Debit", "-", "➖");
        
        private final String displayName;
        private final String symbol;
        private final String icon;
        
        TransactionType(String displayName, String symbol, String icon) {
            this.displayName = displayName;
            this.symbol = symbol;
            this.icon = icon;
        }
        
        public String getDisplayName() {
            return displayName;
        }
        
        public String getSymbol() {
            return symbol;
        }
        
        public String getIcon() {
            return icon;
        }
    }
    
    public enum TransactionStatus {
        PENDING("Pending", "⏳"),
        COMPLETED("Completed", "✅"),
        FAILED("Failed", "❌"),
        CANCELLED("Cancelled", "🚫");
        
        private final String displayName;
        private final String icon;
        
        TransactionStatus(String displayName, String icon) {
            this.displayName = displayName;
            this.icon = icon;
        }
        
        public String getDisplayName() {
            return displayName;
        }
        
        public String getIcon() {
            return icon;
        }
    }
    
    // Constructor
    public Transaction() {
        this.transactionDate = new Date();
        this.status = TransactionStatus.COMPLETED;
    }
    
    public Transaction(TransactionType type, double amount, String description) {
        this();
        this.type = type;
        this.amount = amount;
        this.description = description;
    }
    
    // Getters and Setters
    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }
    
    public long getAccountId() {
        return accountId;
    }
    
    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }
    
    public TransactionType getType() {
        return type;
    }
    
    public void setType(TransactionType type) {
        this.type = type;
    }
    
    public double getAmount() {
        return amount;
    }
    
    public void setAmount(double amount) {
        this.amount = amount;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public Date getTransactionDate() {
        return transactionDate;
    }
    
    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }
    
    public TransactionStatus getStatus() {
        return status;
    }
    
    public void setStatus(TransactionStatus status) {
        this.status = status;
    }
    
    public String getFormattedAmount() {
        String sign = (type == TransactionType.DEPOSIT || 
                      type == TransactionType.CREDIT || 
                      type == TransactionType.SALE) ? "+" : "-";
        return String.format("%s$%.2f", sign, Math.abs(amount));
    }
    
    public String getFormattedDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault());
        return sdf.format(transactionDate);
    }
    
    public String getShortDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd", Locale.getDefault());
        return sdf.format(transactionDate);
    }
    
    public boolean isPositive() {
        return type == TransactionType.DEPOSIT || 
               type == TransactionType.CREDIT || 
               type == TransactionType.SALE;
    }
    
    @Override
    public String toString() {
        return String.format("%s - %s: %s (%s)", 
            getFormattedDate(), 
            type.getDisplayName(), 
            getFormattedAmount(), 
            description
        );
    }
}
