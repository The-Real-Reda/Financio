package com.financify.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.financify.R;
import com.financify.models.BankAccount;
import java.util.List;

public class BankAccountAdapter extends RecyclerView.Adapter<BankAccountAdapter.ViewHolder> {
    private Context context;
    private List<BankAccount> accounts;
    
    public BankAccountAdapter(Context context, List<BankAccount> accounts) {
        this.context = context;
        this.accounts = accounts;
    }
    
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_bank_account, parent, false);
        return new ViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BankAccount account = accounts.get(position);
        holder.accountNameText.setText(account.getType().getIcon() + " " + account.getAccountName());
        holder.accountNumberText.setText(account.getMaskedAccountNumber());
        holder.balanceText.setText(account.getFormattedBalance());
        holder.typeText.setText(account.getType().getDisplayName());
    }
    
    @Override
    public int getItemCount() {
        return accounts.size();
    }
    
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView accountNameText, accountNumberText, balanceText, typeText;
        
        ViewHolder(View view) {
            super(view);
            accountNameText = view.findViewById(R.id.accountNameText);
            accountNumberText = view.findViewById(R.id.accountNumberText);
            balanceText = view.findViewById(R.id.accountBalanceText);
            typeText = view.findViewById(R.id.accountTypeText);
        }
    }
}
