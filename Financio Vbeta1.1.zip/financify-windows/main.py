"""
Financify Desktop Application
Investment Hub for Stocks, Crypto, and Gold
"""
import sys
from PyQt6.QtWidgets import QApplication, QSplashScreen
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QPixmap, QPainter, QColor, QFont
from src.ui.main_window import FinancifyMainWindow

def create_splash_screen():
    """Create a splash screen"""
    splash_pix = QPixmap(600, 400)
    splash_pix.fill(QColor("#1e3a5f"))
    
    painter = QPainter(splash_pix)
    painter.setPen(QColor("#ffffff"))
    
    # Draw icon
    icon_font = QFont("Segoe UI", 72)
    painter.setFont(icon_font)
    painter.drawText(splash_pix.rect(), Qt.AlignmentFlag.AlignCenter, "💰")
    
    # Draw title
    title_font = QFont("Segoe UI", 36, QFont.Weight.Bold)
    painter.setFont(title_font)
    painter.drawText(50, 250, "Financify")
    
    # Draw subtitle
    subtitle_font = QFont("Segoe UI", 16)
    painter.setFont(subtitle_font)
    painter.drawText(50, 280, "Your Investment Hub")
    
    # Draw loading text
    loading_font = QFont("Segoe UI", 12)
    painter.setFont(loading_font)
    painter.drawText(50, 350, "Loading...")
    
    painter.end()
    
    return QSplashScreen(splash_pix)

def main():
    """Main application entry point"""
    app = QApplication(sys.argv)
    app.setApplicationName("Financify")
    app.setOrganizationName("Financify Team")
    
    # Show splash screen
    splash = create_splash_screen()
    splash.show()
    app.processEvents()
    
    # Create and show main window after 2 seconds
    def show_main_window():
        window = FinancifyMainWindow()
        window.show()
        splash.finish(window)
    
    QTimer.singleShot(2000, show_main_window)
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
