# 🚀 Guide Rapide - Financify Windows EXE

## ⚡ Génération de l'EXE en 3 étapes

### Étape 1 : Installer Python
**Windows :**
1. Télécharger : https://www.python.org/downloads/
2. Installer (⚠️ **COCHER** "Add Python to PATH")
3. Redémarrer l'ordinateur

### Étape 2 : Générer l'EXE
**Double-cliquer** sur `BUILD_EXE.bat`

C'est tout ! ✨

### Étape 3 : Utiliser l'application
L'EXE est dans : `dist/Financify.exe`

---

## 💻 Utilisation

### Lancer l'application :
Double-cliquer sur `Financify.exe`

### Navigation :
- **📊 Dashboard** : Vue portfolio
- **📈 Invest** : Trading (interface)
- **🏦 Banking** : Comptes bancaires
- **🤖 AI Advisor** : Conseiller IA (interface)

### Données incluses :
✅ Portfolio : $250,000  
✅ 8 actifs (actions, crypto, or)  
✅ 3 comptes bancaires

---

## ⚙️ Options Avancées

### Lancer depuis le code (Développeurs) :
```bash
pip install -r requirements.txt
python main.py
```

### Recompiler l'EXE :
```bash
pyinstaller --clean --noconfirm financify.spec
```

---

## ❓ Problèmes Courants

### Python non reconnu ?
Réinstaller Python et cocher "Add Python to PATH"

### Erreur de module ?
```bash
pip install -r requirements.txt
```

### L'EXE ne se lance pas ?
1. Désactiver l'antivirus temporairement
2. Exécuter en tant qu'administrateur

---

## 📊 Caractéristiques

✅ Interface moderne avec thème sombre  
✅ Aucune installation requise (après génération)  
✅ Base de données SQLite locale  
✅ Auto-refresh toutes les 60 secondes  
✅ Tableaux interactifs  
✅ Compatible Windows 7/8/10/11

---

## ⏱️ Temps estimé :
- **Installation Python** : 5 minutes
- **Génération EXE** : 5-10 minutes
- **Total** : 15 minutes maximum

---

## 🎯 C'est prêt !

Votre application Windows desktop est prête à l'emploi ! 

**L'EXE peut être partagé** sans avoir besoin d'installer Python sur les autres ordinateurs.

---

**Profitez de Financify ! 💰📊**
