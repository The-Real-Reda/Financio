# 💰 Financify Desktop - Windows Application

## 📱 Description
Application de bureau moderne pour gérer vos investissements en actions, crypto-monnaies, or et comptes bancaires.

**Version Windows améliorée** avec interface graphique PyQt6 moderne et thème sombre.

## ✨ Caractéristiques

### 🎨 Interface Moderne
- ✅ Thème sombre élégant (Catppuccin inspired)
- ✅ Interface intuitive avec onglets
- ✅ Tableaux interactifs
- ✅ Cartes statistiques en temps réel
- ✅ Splash screen au démarrage

### 💼 Fonctionnalités
- 📊 **Dashboard** : Vue d'ensemble complète du portfolio
- 📈 **Invest** : Section investissement (interface)
- 🏦 **Banking** : Gestion des comptes bancaires
- 🤖 **AI Advisor** : Conseiller financier IA (interface)
- 💾 **Base de données** SQLite locale sécurisée
- 🔄 **Auto-refresh** : Mise à jour automatique chaque minute

### 📦 Données Incluses
- Portfolio démo : ~$250,000 USD
- 8 actifs (AAPL, GOOGL, MSFT, BTC, ETH, SOL, GOLD, SILVER)
- 3 comptes bancaires
- Interface responsive et rapide

## 🚀 Génération de l'EXE

### Méthode Simple (Un seul double-clic!)

#### Sur Windows :
1. **Télécharger** et extraire le projet
2. **Double-cliquer** sur `BUILD_EXE.bat`
3. **Attendre** 5-10 minutes ⏳
4. **C'est prêt!** L'EXE est dans le dossier `dist/`

#### Sur Mac/Linux :
```bash
chmod +x BUILD_EXE.sh
./BUILD_EXE.sh
```

### Prérequis
**Python 3.8 ou supérieur**
- Windows/Mac : https://www.python.org/downloads/
- Linux : `sudo apt install python3 python3-pip`

## 📥 Installation et Utilisation

### Option 1 : Lancer depuis le code source (Développeur)
```bash
# Installer les dépendances
pip install -r requirements.txt

# Lancer l'application
python main.py
```

### Option 2 : Utiliser l'EXE (Utilisateur final)
1. Double-cliquer sur `Financify.exe`
2. L'application se lance immédiatement
3. Aucune installation nécessaire!

## 🎯 Premier lancement

1. L'application démarre avec un **splash screen**
2. L'interface principale s'ouvre automatiquement
3. Les **données de démonstration** sont créées automatiquement
4. Explorez les différents onglets !

## 📂 Structure du Projet

```
financify-windows/
├── main.py                 # Point d'entrée
├── requirements.txt        # Dépendances Python
├── financify.spec         # Configuration PyInstaller
├── BUILD_EXE.bat          # Script de build Windows
├── BUILD_EXE.sh           # Script de build Mac/Linux
├── src/
│   ├── models/            # Modèles de données
│   │   ├── asset.py
│   │   └── bank_account.py
│   ├── services/          # Services (DB, API)
│   │   └── database.py
│   └── ui/                # Interface graphique
│       └── main_window.py
├── data/                  # Base de données SQLite
└── assets/                # Ressources (icons, images)
```

## 🛠️ Technologies Utilisées

- **Python 3.8+**
- **PyQt6** : Framework GUI moderne
- **PyQt6-Charts** : Graphiques et visualisations
- **SQLite** : Base de données locale
- **PyInstaller** : Conversion en EXE
- **Requests** : Appels API (futur)

## 📋 Configuration Requise

### Pour le développement :
- Python 3.8 ou supérieur
- 500 MB d'espace disque
- Windows 7/8/10/11, macOS, ou Linux

### Pour l'exécutable :
- Windows 7 ou supérieur (64-bit recommandé)
- 100 MB d'espace disque
- Aucune installation additionnelle nécessaire

## 🎨 Personnalisation

### Changer le thème de couleurs
Modifier les styles dans `src/ui/main_window.py` :
```python
self.setStyleSheet("""
    QMainWindow {
        background-color: #1e1e2e;  # Couleur de fond
    }
    ...
""")
```

### Ajouter des assets
Modifier `src/services/database.py` dans la méthode `create_demo_user()`.

## 🔧 Compilation Avancée

### Compiler avec options personnalisées :
```bash
pyinstaller --onefile --windowed --name="Financify" --icon=icon.ico main.py
```

### Options PyInstaller :
- `--onefile` : Un seul fichier EXE
- `--windowed` : Pas de console (GUI uniquement)
- `--icon=icon.ico` : Icône personnalisée
- `--add-data` : Ajouter des fichiers de données

## 📊 Taille de l'EXE

- **Taille estimée** : 50-80 MB
- **Avec UPX compression** : 30-50 MB
- **Temps de compilation** : 5-10 minutes

## 🐛 Dépannage

### Problème : "Python n'est pas reconnu"
**Solution :**
1. Réinstaller Python depuis https://www.python.org/
2. **Cocher** "Add Python to PATH" pendant l'installation
3. Redémarrer l'ordinateur

### Problème : "Module PyQt6 not found"
**Solution :**
```bash
pip install --upgrade pip
pip install PyQt6 PyQt6-Charts
```

### Problème : L'EXE ne se lance pas
**Solution :**
1. Vérifier que Windows Defender ne bloque pas l'EXE
2. Exécuter en tant qu'administrateur
3. Vérifier les logs dans `dist/`

### Problème : "Failed to execute script"
**Solution :**
```bash
# Compiler sans --windowed pour voir les erreurs
pyinstaller --onefile --name="Financify" main.py
```

## 🎁 Distribution

### Partager l'application :
1. L'EXE se trouve dans `dist/Financify.exe`
2. **Compresser** en ZIP pour partager
3. Aucune installation nécessaire pour l'utilisateur final
4. Compatible Windows 7/8/10/11

### Créer un installateur (Optionnel) :
- Utiliser **Inno Setup** : https://jrsoftware.org/isinfo.php
- Ou **NSIS** : https://nsis.sourceforge.io/

## 📈 Fonctionnalités Futures

- [ ] Connexion API en temps réel pour les prix
- [ ] Export PDF des rapports
- [ ] Graphiques interactifs avancés
- [ ] Notifications de prix
- [ ] Synchronisation cloud
- [ ] Mode clair/sombre commutable
- [ ] Support multi-devises
- [ ] Import/Export de données

## 🔐 Sécurité

- ✅ Base de données locale (pas de cloud)
- ✅ Aucune donnée personnelle collectée
- ✅ Code source open source
- ✅ Pas de connexion Internet requise

## 📄 Licence

Ce projet est fourni à des fins de démonstration et d'éducation.

## 👤 Auteur

Financify Team - 2024

## 🤝 Contribution

Les contributions sont les bienvenues ! N'hésitez pas à :
- Signaler des bugs
- Proposer des améliorations
- Ajouter des fonctionnalités

## 📞 Support

Pour toute question :
1. Vérifier la section Dépannage
2. Consulter les logs dans `dist/`
3. Ouvrir une issue sur le dépôt

---

## 🎉 Démarrage Rapide

```bash
# 1. Extraire le projet
unzip financify-windows.zip

# 2. Compiler l'EXE
BUILD_EXE.bat    # Windows
./BUILD_EXE.sh   # Mac/Linux

# 3. Lancer l'application
dist/Financify.exe
```

**C'est tout ! Profitez de Financify ! 💰**

---

## 📸 Captures d'écran

L'application inclut :
- 📊 Dashboard avec cartes statistiques
- 📈 Tableau des actifs avec couleurs
- 🏦 Gestion des comptes bancaires
- 🎨 Thème sombre moderne et élégant

---

**Version** : 1.0.0  
**Date** : 2024  
**Plateforme** : Windows 7/8/10/11 (64-bit)
