"""
Main Window - Financify Desktop Application
"""
from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                              QLabel, QPushButton, QTableWidget, QTableWidgetItem,
                              QTabWidget, QFrame, QScrollArea, QGridLayout, QMessageBox)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont, QColor
from PyQt6.QtCharts import QChart, QChartView, QPieSeries, QLineSeries
from src.services.database import DatabaseService

class FinancifyMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.db = DatabaseService()
        self.user_id = self.db.create_demo_user()
        self.init_ui()
        self.load_data()
        
    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle("💰 Financify - Investment Hub")
        self.setGeometry(100, 100, 1400, 900)
        self.setMinimumSize(1200, 800)
        
        # Set dark theme colors
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1e1e2e;
            }
            QLabel {
                color: #cdd6f4;
            }
            QPushButton {
                background-color: #313244;
                color: #cdd6f4;
                border: none;
                padding: 10px 20px;
                border-radius: 8px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #45475a;
            }
            QTableWidget {
                background-color: #181825;
                color: #cdd6f4;
                border: none;
                border-radius: 8px;
            }
            QTableWidget::item {
                padding: 10px;
            }
            QHeaderView::section {
                background-color: #313244;
                color: #cdd6f4;
                padding: 8px;
                border: none;
            }
            QTabWidget::pane {
                border: none;
                background-color: #1e1e2e;
            }
            QTabBar::tab {
                background-color: #313244;
                color: #cdd6f4;
                padding: 12px 24px;
                margin-right: 4px;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
            }
            QTabBar::tab:selected {
                background-color: #45475a;
            }
            QScrollArea {
                border: none;
                background-color: #1e1e2e;
            }
        """)
        
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(20, 20, 20, 20)
        
        # Header
        header = self.create_header()
        main_layout.addWidget(header)
        
        # Tabs
        self.tabs = QTabWidget()
        self.tabs.addTab(self.create_dashboard_tab(), "📊 Dashboard")
        self.tabs.addTab(self.create_invest_tab(), "📈 Invest")
        self.tabs.addTab(self.create_banking_tab(), "🏦 Banking")
        self.tabs.addTab(self.create_advisor_tab(), "🤖 AI Advisor")
        main_layout.addWidget(self.tabs)
        
        # Setup auto-refresh (every 60 seconds)
        self.timer = QTimer()
        self.timer.timeout.connect(self.refresh_data)
        self.timer.start(60000)  # 60 seconds
        
    def create_header(self):
        """Create application header"""
        header = QFrame()
        header.setStyleSheet("""
            QFrame {
                background-color: #313244;
                border-radius: 12px;
                padding: 15px;
            }
        """)
        layout = QHBoxLayout(header)
        
        # App title
        title = QLabel("💰 Financify")
        title_font = QFont("Segoe UI", 24, QFont.Weight.Bold)
        title.setFont(title_font)
        layout.addWidget(title)
        
        layout.addStretch()
        
        # User info
        user_label = QLabel("👤 Demo User")
        user_font = QFont("Segoe UI", 12)
        user_label.setFont(user_font)
        layout.addWidget(user_label)
        
        return header
    
    def create_dashboard_tab(self):
        """Create dashboard tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(20)
        
        # Portfolio summary cards
        cards_layout = QHBoxLayout()
        
        # Total Balance Card
        self.total_balance_card = self.create_stat_card("Total Portfolio Value", "$0.00", "+$0.00 (+0.00%)")
        cards_layout.addWidget(self.total_balance_card)
        
        # Assets Card
        self.assets_count_card = self.create_stat_card("Total Assets", "0", "Stocks, Crypto, Gold")
        cards_layout.addWidget(self.assets_count_card)
        
        # Accounts Card
        self.accounts_count_card = self.create_stat_card("Bank Accounts", "0", "Checking, Savings, Investment")
        cards_layout.addWidget(self.accounts_count_card)
        
        layout.addLayout(cards_layout)
        
        # Assets table
        table_label = QLabel("📈 My Assets")
        table_label.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        layout.addWidget(table_label)
        
        self.assets_table = QTableWidget()
        self.assets_table.setColumnCount(7)
        self.assets_table.setHorizontalHeaderLabels([
            "Symbol", "Name", "Type", "Price", "Change", "Quantity", "Total Value"
        ])
        self.assets_table.horizontalHeader().setStretchLastSection(True)
        self.assets_table.setAlternatingRowColors(True)
        self.assets_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        layout.addWidget(self.assets_table)
        
        return widget
    
    def create_invest_tab(self):
        """Create invest tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        icon = QLabel("📈")
        icon.setFont(QFont("Segoe UI", 72))
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(icon)
        
        title = QLabel("Investment Trading")
        title.setFont(QFont("Segoe UI", 24, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        subtitle = QLabel("Search and trade stocks, crypto, and commodities")
        subtitle.setFont(QFont("Segoe UI", 14))
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("color: #a6adc8;")
        layout.addWidget(subtitle)
        
        return widget
    
    def create_banking_tab(self):
        """Create banking tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(20)
        
        # Bank total
        self.bank_total_label = QLabel("Total Bank Balance: $0.00")
        self.bank_total_label.setFont(QFont("Segoe UI", 20, QFont.Weight.Bold))
        layout.addWidget(self.bank_total_label)
        
        # Accounts table
        self.accounts_table = QTableWidget()
        self.accounts_table.setColumnCount(4)
        self.accounts_table.setHorizontalHeaderLabels([
            "Account Name", "Account Number", "Type", "Balance"
        ])
        self.accounts_table.horizontalHeader().setStretchLastSection(True)
        self.accounts_table.setAlternatingRowColors(True)
        layout.addWidget(self.accounts_table)
        
        return widget
    
    def create_advisor_tab(self):
        """Create AI advisor tab"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        icon = QLabel("🤖")
        icon.setFont(QFont("Segoe UI", 72))
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(icon)
        
        title = QLabel("AI Financial Advisor")
        title.setFont(QFont("Segoe UI", 24, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        subtitle = QLabel("Get personalized investment recommendations and financial insights")
        subtitle.setFont(QFont("Segoe UI", 14))
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("color: #a6adc8;")
        layout.addWidget(subtitle)
        
        return widget
    
    def create_stat_card(self, title, value, subtitle):
        """Create a statistics card"""
        card = QFrame()
        card.setStyleSheet("""
            QFrame {
                background-color: #313244;
                border-radius: 12px;
                padding: 20px;
            }
        """)
        layout = QVBoxLayout(card)
        
        title_label = QLabel(title)
        title_label.setFont(QFont("Segoe UI", 12))
        title_label.setStyleSheet("color: #a6adc8;")
        layout.addWidget(title_label)
        
        value_label = QLabel(value)
        value_label.setFont(QFont("Segoe UI", 28, QFont.Weight.Bold))
        value_label.setObjectName("value_label")
        layout.addWidget(value_label)
        
        subtitle_label = QLabel(subtitle)
        subtitle_label.setFont(QFont("Segoe UI", 11))
        subtitle_label.setStyleSheet("color: #a6adc8;")
        subtitle_label.setObjectName("subtitle_label")
        layout.addWidget(subtitle_label)
        
        return card
    
    def load_data(self):
        """Load all data"""
        self.load_assets()
        self.load_bank_accounts()
        self.update_summary()
    
    def load_assets(self):
        """Load assets into table"""
        assets = self.db.get_assets(self.user_id)
        self.assets_table.setRowCount(len(assets))
        
        for i, asset in enumerate(assets):
            self.assets_table.setItem(i, 0, QTableWidgetItem(f"{asset.get_icon()} {asset.symbol}"))
            self.assets_table.setItem(i, 1, QTableWidgetItem(asset.name))
            self.assets_table.setItem(i, 2, QTableWidgetItem(asset.type.value))
            self.assets_table.setItem(i, 3, QTableWidgetItem(asset.formatted_price()))
            
            change_item = QTableWidgetItem(asset.formatted_change())
            if asset.is_positive:
                change_item.setForeground(QColor("#a6e3a1"))  # Green
            else:
                change_item.setForeground(QColor("#f38ba8"))  # Red
            self.assets_table.setItem(i, 4, change_item)
            
            self.assets_table.setItem(i, 5, QTableWidgetItem(asset.formatted_quantity()))
            self.assets_table.setItem(i, 6, QTableWidgetItem(asset.formatted_value()))
    
    def load_bank_accounts(self):
        """Load bank accounts into table"""
        accounts = self.db.get_bank_accounts(self.user_id)
        self.accounts_table.setRowCount(len(accounts))
        
        total_balance = sum(acc.balance for acc in accounts)
        self.bank_total_label.setText(f"Total Bank Balance: ${total_balance:,.2f}")
        
        for i, account in enumerate(accounts):
            self.accounts_table.setItem(i, 0, QTableWidgetItem(f"{account.get_icon()} {account.account_name}"))
            self.accounts_table.setItem(i, 1, QTableWidgetItem(account.masked_account_number()))
            self.accounts_table.setItem(i, 2, QTableWidgetItem(account.type.value))
            self.accounts_table.setItem(i, 3, QTableWidgetItem(account.formatted_balance()))
    
    def update_summary(self):
        """Update summary cards"""
        assets = self.db.get_assets(self.user_id)
        accounts = self.db.get_bank_accounts(self.user_id)
        
        # Calculate totals
        total_assets_value = sum(asset.total_value for asset in assets)
        total_bank_balance = sum(acc.balance for acc in accounts)
        total_portfolio = total_assets_value + total_bank_balance
        
        total_change = sum(asset.change_amount for asset in assets)
        change_percent = (total_change / (total_portfolio - total_change) * 100) if total_portfolio > 0 else 0
        
        # Update cards
        value_label = self.total_balance_card.findChild(QLabel, "value_label")
        subtitle_label = self.total_balance_card.findChild(QLabel, "subtitle_label")
        
        value_label.setText(f"${total_portfolio:,.2f}")
        subtitle_label.setText(f"${total_change:+,.2f} ({change_percent:+.2f}%)")
        
        if total_change >= 0:
            subtitle_label.setStyleSheet("color: #a6e3a1;")
        else:
            subtitle_label.setStyleSheet("color: #f38ba8;")
        
        # Update assets count
        assets_value_label = self.assets_count_card.findChild(QLabel, "value_label")
        assets_value_label.setText(str(len(assets)))
        
        # Update accounts count
        accounts_value_label = self.accounts_count_card.findChild(QLabel, "value_label")
        accounts_value_label.setText(str(len(accounts)))
    
    def refresh_data(self):
        """Refresh all data"""
        self.load_data()
