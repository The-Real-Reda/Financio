"""
Database Service - SQLite database management
"""
import sqlite3
import os
from datetime import datetime
from src.models.asset import Asset, AssetType
from src.models.bank_account import BankAccount, AccountType

class DatabaseService:
    def __init__(self, db_path="data/financify.db"):
        self.db_path = db_path
        self.ensure_db_directory()
        self.init_database()
    
    def ensure_db_directory(self):
        """Create data directory if it doesn't exist"""
        db_dir = os.path.dirname(self.db_path)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir)
    
    def get_connection(self):
        return sqlite3.connect(self.db_path)
    
    def init_database(self):
        """Initialize database with tables"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                first_name TEXT,
                last_name TEXT,
                created_date TEXT NOT NULL
            )
        ''')
        
        # Assets table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS assets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                symbol TEXT NOT NULL,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                current_price REAL NOT NULL,
                previous_price REAL,
                quantity REAL NOT NULL,
                last_updated TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        
        # Bank Accounts table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bank_accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                account_number TEXT UNIQUE NOT NULL,
                account_name TEXT NOT NULL,
                type TEXT NOT NULL,
                balance REAL NOT NULL,
                currency TEXT NOT NULL,
                is_active INTEGER NOT NULL,
                created_date TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def create_demo_user(self):
        """Create demo user with sample data"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Check if demo user exists
        cursor.execute("SELECT id FROM users WHERE username = ?", ("demo",))
        result = cursor.fetchone()
        
        if result:
            user_id = result[0]
        else:
            # Create demo user
            cursor.execute('''
                INSERT INTO users (username, email, first_name, last_name, created_date)
                VALUES (?, ?, ?, ?, ?)
            ''', ("demo", "demo@financify.com", "Demo", "User", datetime.now().isoformat()))
            user_id = cursor.lastrowid
            
            # Create demo assets
            demo_assets = [
                ("AAPL", "Apple Inc.", "STOCK", 175.50, 173.20, 10),
                ("GOOGL", "Alphabet Inc.", "STOCK", 142.30, 140.80, 15),
                ("MSFT", "Microsoft Corp.", "STOCK", 380.25, 378.90, 8),
                ("BTC", "Bitcoin", "CRYPTO", 43500.00, 42800.00, 0.5),
                ("ETH", "Ethereum", "CRYPTO", 2350.00, 2310.00, 2.5),
                ("SOL", "Solana", "CRYPTO", 98.75, 95.20, 25),
                ("GOLD", "Gold", "GOLD", 2050.50, 2045.00, 5),
                ("SILVER", "Silver", "SILVER", 24.75, 24.50, 100),
            ]
            
            for symbol, name, asset_type, current, previous, qty in demo_assets:
                cursor.execute('''
                    INSERT INTO assets (user_id, symbol, name, type, current_price, previous_price, quantity, last_updated)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (user_id, symbol, name, asset_type, current, previous, qty, datetime.now().isoformat()))
            
            # Create demo bank accounts
            demo_accounts = [
                ("1234567890", "Main Checking", "CHECKING", 25000.00),
                ("0987654321", "Savings Account", "SAVINGS", 50000.00),
                ("5555666677", "Investment Account", "INVESTMENT", 150000.00),
            ]
            
            for acc_num, acc_name, acc_type, balance in demo_accounts:
                cursor.execute('''
                    INSERT INTO bank_accounts (user_id, account_number, account_name, type, balance, currency, is_active, created_date)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', (user_id, acc_num, acc_name, acc_type, balance, "USD", 1, datetime.now().isoformat()))
        
        conn.commit()
        conn.close()
        return user_id
    
    def get_assets(self, user_id):
        """Get all assets for a user"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, symbol, name, type, current_price, previous_price, quantity, last_updated
            FROM assets WHERE user_id = ?
        ''', (user_id,))
        
        assets = []
        for row in cursor.fetchall():
            asset = Asset(row[1], row[2], AssetType[row[3]], row[4], row[5], row[6])
            asset.id = row[0]
            assets.append(asset)
        
        conn.close()
        return assets
    
    def get_bank_accounts(self, user_id):
        """Get all bank accounts for a user"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, account_number, account_name, type, balance, currency, is_active, created_date
            FROM bank_accounts WHERE user_id = ?
        ''', (user_id,))
        
        accounts = []
        for row in cursor.fetchall():
            account = BankAccount(row[1], row[2], AccountType[row[3]])
            account.id = row[0]
            account.balance = row[4]
            account.currency = row[5]
            account.is_active = bool(row[6])
            accounts.append(account)
        
        conn.close()
        return accounts
    
    def update_asset_prices(self, asset_id, current_price):
        """Update asset prices"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Get current price to set as previous
        cursor.execute("SELECT current_price FROM assets WHERE id = ?", (asset_id,))
        result = cursor.fetchone()
        
        if result:
            previous_price = result[0]
            cursor.execute('''
                UPDATE assets 
                SET current_price = ?, previous_price = ?, last_updated = ?
                WHERE id = ?
            ''', (current_price, previous_price, datetime.now().isoformat(), asset_id))
            conn.commit()
        
        conn.close()
