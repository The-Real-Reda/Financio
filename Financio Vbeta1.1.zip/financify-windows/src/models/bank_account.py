"""
BankAccount Model
"""
from datetime import datetime
from enum import Enum

class AccountType(Enum):
    CHECKING = "Checking Account"
    SAVINGS = "Savings Account"
    INVESTMENT = "Investment Account"
    CREDIT = "Credit Card"

class BankAccount:
    def __init__(self, account_number, account_name, account_type):
        self.id = None
        self.account_number = account_number
        self.account_name = account_name
        self.type = account_type
        self.balance = 0.0
        self.currency = "USD"
        self.is_active = True
        self.created_date = datetime.now()
        self.transactions = []
    
    def formatted_balance(self):
        return f"{self.currency} {self.balance:,.2f}"
    
    def masked_account_number(self):
        if len(self.account_number) >= 4:
            return "****" + self.account_number[-4:]
        return self.account_number
    
    def get_icon(self):
        icons = {
            AccountType.CHECKING: "💳",
            AccountType.SAVINGS: "💰",
            AccountType.INVESTMENT: "📊",
            AccountType.CREDIT: "💳"
        }
        return icons.get(self.type, "🏦")
    
    def __repr__(self):
        return f"{self.account_name} ({self.masked_account_number()}) - {self.formatted_balance()}"
