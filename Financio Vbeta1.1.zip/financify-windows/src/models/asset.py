"""
Asset Model - Represents financial assets
"""
from datetime import datetime
from enum import Enum

class AssetType(Enum):
    STOCK = "Stock"
    CRYPTO = "Crypto"
    GOLD = "Gold"
    SILVER = "Silver"
    COMMODITY = "Commodity"

class Asset:
    def __init__(self, symbol, name, asset_type, current_price=0.0, previous_price=0.0, quantity=0.0):
        self.id = None
        self.symbol = symbol
        self.name = name
        self.type = asset_type
        self.current_price = current_price
        self.previous_price = previous_price
        self.quantity = quantity
        self.last_updated = datetime.now()
        
    @property
    def total_value(self):
        return self.current_price * self.quantity
    
    @property
    def change_percent(self):
        if self.previous_price > 0:
            return ((self.current_price - self.previous_price) / self.previous_price) * 100
        return 0.0
    
    @property
    def change_amount(self):
        return (self.current_price - self.previous_price) * self.quantity
    
    @property
    def is_positive(self):
        return self.change_percent >= 0
    
    def formatted_price(self):
        return f"${self.current_price:,.2f}"
    
    def formatted_change(self):
        return f"{self.change_percent:+.2f}%"
    
    def formatted_value(self):
        return f"${self.total_value:,.2f}"
    
    def formatted_quantity(self):
        if self.type == AssetType.CRYPTO:
            return f"{self.quantity:.6f}"
        return f"{self.quantity:.2f}"
    
    def get_icon(self):
        icons = {
            AssetType.STOCK: "📈",
            AssetType.CRYPTO: "₿",
            AssetType.GOLD: "🥇",
            AssetType.SILVER: "🥈",
            AssetType.COMMODITY: "📦"
        }
        return icons.get(self.type, "💰")
    
    def __repr__(self):
        return f"{self.symbol} ({self.name}) - {self.formatted_price()}"
