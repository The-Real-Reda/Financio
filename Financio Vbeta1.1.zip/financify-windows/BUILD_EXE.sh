#!/bin/bash

echo "========================================"
echo " FINANCIFY - Générateur EXE Windows"
echo "========================================"
echo ""

# Vérifier Python
if ! command -v python3 &> /dev/null && ! command -v python &> /dev/null; then
    echo "[ERREUR] Python n'est pas installé!"
    echo ""
    echo "Installez Python:"
    echo "  Ubuntu/Debian: sudo apt install python3 python3-pip"
    echo "  Mac: brew install python3"
    echo "  Ou téléchargez: https://www.python.org/downloads/"
    exit 1
fi

# Use python3 if available, otherwise python
PYTHON_CMD="python3"
if ! command -v python3 &> /dev/null; then
    PYTHON_CMD="python"
fi

echo "[OK] Python détecté: $($PYTHON_CMD --version)"

echo ""
echo "[ETAPE 1/4] Installation des dépendances..."
$PYTHON_CMD -m pip install --upgrade pip
$PYTHON_CMD -m pip install -r requirements.txt

echo ""
echo "[ETAPE 2/4] Test de l'application..."
echo "Démarrage de l'application pour test (fermez-la pour continuer)..."
sleep 2
$PYTHON_CMD main.py &
APP_PID=$!
sleep 5
kill $APP_PID 2>/dev/null

echo ""
echo "[ETAPE 3/4] Compilation en EXE avec PyInstaller..."
$PYTHON_CMD -m PyInstaller --clean --noconfirm financify.spec

echo ""
echo "[ETAPE 4/4] Vérification..."

if [ -f "dist/Financify.exe" ] || [ -f "dist/Financify" ]; then
    echo ""
    echo "========================================"
    echo " SUCCES! Exécutable généré avec succès!"
    echo "========================================"
    echo ""
    if [ -f "dist/Financify.exe" ]; then
        echo "L'exécutable se trouve ici:"
        echo "$(pwd)/dist/Financify.exe"
        ls -lh dist/Financify.exe
    else
        echo "L'exécutable se trouve ici:"
        echo "$(pwd)/dist/Financify"
        ls -lh dist/Financify
    fi
    echo ""
    echo "Vous pouvez maintenant:"
    echo "1. Double-cliquer sur l'exécutable pour lancer l'app"
    echo "2. Partager ce fichier (aucune installation nécessaire!)"
else
    echo ""
    echo "[ERREUR] L'exécutable n'a pas été généré."
    echo "Consultez les erreurs ci-dessus."
    exit 1
fi

echo ""
