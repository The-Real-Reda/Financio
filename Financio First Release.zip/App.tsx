
import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Sidebar from './components/layout/Sidebar';
import DashboardPage from './pages/DashboardPage';
import InvestPage from './pages/InvestPage';
import BankingPage from './pages/BankingPage';
import AdvisorPage from './pages/AdvisorPage';
import LoginPage from './pages/LoginPage';
import AIChatWidget from './components/common/AIChatWidget';
import { useGeolocation } from './hooks/useGeolocation';
import { FinanceProvider } from './context/FinanceContext';

const App: React.FC = () => {
  const { location, error, requestLocation } = useGeolocation();
  const [user, setUser] = useState<string | null>(null);

  React.useEffect(() => {
    if (user) {
      requestLocation();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const handleLogin = (username: string) => {
    setUser(username);
  };

  const handleLogout = () => {
    setUser(null);
  };

  if (!user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <FinanceProvider>
      <div className="flex h-screen bg-brand-bg font-sans">
        <Sidebar user={user} onLogout={handleLogout} />
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 relative">
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/invest" element={<InvestPage />} />
            <Route path="/banking" element={<BankingPage />} />
            <Route path="/advisor" element={<AdvisorPage location={location} locationError={error} />} />
          </Routes>
          <AIChatWidget />
        </main>
      </div>
    </FinanceProvider>
  );
};

export default App;
