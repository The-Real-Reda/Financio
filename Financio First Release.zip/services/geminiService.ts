
import { GoogleGenAI, Chat } from '@google/genai';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const getChatResponse = (systemInstruction: string): Chat => {
  const model = 'gemini-2.5-flash';
  
  const chat = ai.chats.create({
    model: model,
    config: {
      systemInstruction,
    },
  });

  return chat;
};

export const fetchStockNews = async (name: string, ticker: string) => {
  const model = 'gemini-2.5-flash';
  
  // Refined prompt for structured text parsing to enable card UI
  const prompt = `Find the latest important financial news for ${name} (${ticker}). 
  Select the top 3 most relevant stories from the last 7 days.
  
  You MUST format the output as a list of articles separated by "---ITEM_SEPARATOR---".
  For each article, follow this exact pattern:
  
  HEADLINE: [The headline of the news]
  SOURCE_DATE: [Source Name] • [Date/Time]
  SUMMARY: [A concise 1-2 sentence summary]
  
  Do not add any intro or outro text, just the list of items.`;

  const response = await ai.models.generateContent({
    model: model,
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  return { 
    text: response.text, 
    // Extract grounding chunks to display source links
    groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks 
  };
};
