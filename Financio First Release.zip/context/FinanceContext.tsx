
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Asset, BankAccount, Transaction } from '../types';
import { MOCK_ASSETS, MOCK_ACCOUNTS, MOCK_TRANSACTIONS } from '../constants';

interface FinanceContextType {
  assets: Asset[];
  accounts: BankAccount[];
  transactions: Transaction[];
  updateAccountBalance: (accountId: string, newBalance: number) => void;
  addTransaction: (description: string, amount: number, type: 'credit' | 'debit') => void;
  addBankAccount: (name: string, provider: string, balance: number) => void;
  executeTrade: (assetId: string, type: 'buy' | 'sell', amount: number) => { success: boolean; message: string };
}

const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

export const useFinance = () => {
  const context = useContext(FinanceContext);
  if (!context) {
    throw new Error('useFinance must be used within a FinanceProvider');
  }
  return context;
};

export const FinanceProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [assets, setAssets] = useState<Asset[]>(MOCK_ASSETS);
  const [accounts, setAccounts] = useState<BankAccount[]>(MOCK_ACCOUNTS);
  const [transactions, setTransactions] = useState<Transaction[]>(MOCK_TRANSACTIONS);

  // 5-second Price Update Loop
  useEffect(() => {
    const interval = setInterval(() => {
      setAssets((prevAssets) =>
        prevAssets.map((asset) => {
          // Simulate random price movement between -1% and +1%
          const changePercent = (Math.random() * 2 - 1) / 100;
          const newPrice = asset.price * (1 + changePercent);
          const priceDiff = newPrice - asset.price;
          
          return {
            ...asset,
            price: newPrice,
            change24h: asset.change24h + priceDiff,
            change24h_percent: asset.change24h_percent + (changePercent * 100),
            value: newPrice * asset.holdings
          };
        })
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const updateAccountBalance = (accountId: string, newBalance: number) => {
    setAccounts(prev => prev.map(acc => 
      acc.id === accountId ? { ...acc, balance: newBalance } : acc
    ));
  };

  const addBankAccount = (name: string, provider: string, balance: number) => {
    const newAcc: BankAccount = {
      id: Date.now().toString(),
      name,
      provider,
      accountNumber: '**** ' + Math.floor(1000 + Math.random() * 9000).toString(),
      balance,
      currency: 'USD'
    };
    setAccounts(prev => [...prev, newAcc]);
  };

  const addTransaction = (description: string, amount: number, type: 'credit' | 'debit') => {
    const newTxn: Transaction = {
      id: Date.now().toString(),
      date: new Date().toISOString().split('T')[0],
      description,
      amount,
      type
    };
    setTransactions(prev => [newTxn, ...prev]);

    // Automatically adjust the first account (checking) for income/expenses
    if (accounts.length > 0) {
      const targetAcc = accounts[0];
      const balanceChange = type === 'credit' ? amount : -amount;
      updateAccountBalance(targetAcc.id, targetAcc.balance + balanceChange);
    }
  };

  const executeTrade = (assetId: string, type: 'buy' | 'sell', quantity: number) => {
    const asset = assets.find(a => a.id === assetId);
    if (!asset) return { success: false, message: 'Asset not found' };

    const totalCost = asset.price * quantity;
    
    // Use the investment account (acc3) or fallback to first account
    const investmentAccount = accounts.find(a => a.provider === 'Fidelity') || accounts[0];

    if (!investmentAccount) {
        return { success: false, message: 'No bank account available for trading. Please add one in Banking.' };
    }

    if (type === 'buy') {
      if (investmentAccount.balance < totalCost) {
        return { success: false, message: 'Insufficient funds in account' };
      }
      
      // Deduct money
      updateAccountBalance(investmentAccount.id, investmentAccount.balance - totalCost);
      
      // Update Holdings
      setAssets(prev => prev.map(a => 
        a.id === assetId ? { ...a, holdings: a.holdings + quantity, value: (a.holdings + quantity) * a.price } : a
      ));

      // Add Transaction
      const newTxn: Transaction = {
        id: Date.now().toString(),
        date: new Date().toISOString().split('T')[0],
        description: `Bought ${quantity} ${asset.ticker}`,
        amount: totalCost,
        type: 'debit'
      };
      setTransactions(prev => [newTxn, ...prev]);

    } else {
      if (asset.holdings < quantity) {
        return { success: false, message: 'Insufficient holdings to sell' };
      }

      // Add money
      updateAccountBalance(investmentAccount.id, investmentAccount.balance + totalCost);

      // Update Holdings
      setAssets(prev => prev.map(a => 
        a.id === assetId ? { ...a, holdings: a.holdings - quantity, value: (a.holdings - quantity) * a.price } : a
      ));

      // Add Transaction
      const newTxn: Transaction = {
        id: Date.now().toString(),
        date: new Date().toISOString().split('T')[0],
        description: `Sold ${quantity} ${asset.ticker}`,
        amount: totalCost,
        type: 'credit'
      };
      setTransactions(prev => [newTxn, ...prev]);
    }

    return { success: true, message: 'Trade executed successfully' };
  };

  return (
    <FinanceContext.Provider value={{ assets, accounts, transactions, updateAccountBalance, addBankAccount, addTransaction, executeTrade }}>
      {children}
    </FinanceContext.Provider>
  );
};
