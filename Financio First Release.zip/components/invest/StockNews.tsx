
import React, { useEffect, useState } from 'react';
import { fetchStockNews } from '../../services/geminiService';

interface StockNewsProps {
  name: string;
  ticker: string;
}

interface NewsItem {
  headline: string;
  sourceDate: string;
  summary: string;
}

const StockNews: React.FC<StockNewsProps> = ({ name, ticker }) => {
  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);
  const [sources, setSources] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    const loadNews = async () => {
      setLoading(true);
      setError(null);
      setNewsItems([]);
      setSources([]);
      
      try {
        const { text, groundingChunks } = await fetchStockNews(name, ticker);
        if (isMounted) {
          if (text) {
             const items = text.split('---ITEM_SEPARATOR---')
                .map(item => item.trim())
                .filter(item => item.length > 0)
                .map(item => {
                    const headlineMatch = item.match(/HEADLINE:\s*(.*)/);
                    const sourceMatch = item.match(/SOURCE_DATE:\s*(.*)/);
                    
                    // Fallback regex to handle multi-line summaries
                    const summaryStartIndex = item.indexOf('SUMMARY:');
                    let summaryText = '';
                    if (summaryStartIndex !== -1) {
                        summaryText = item.substring(summaryStartIndex + 8).trim();
                    }

                    return {
                        headline: headlineMatch ? headlineMatch[1].trim() : 'News Update',
                        sourceDate: sourceMatch ? sourceMatch[1].trim() : 'Recent',
                        summary: summaryText
                    };
                });
             setNewsItems(items);
          }
          setSources(groundingChunks || []);
        }
      } catch (err) {
        if (isMounted) {
          setError('Failed to load latest news. Please try again later.');
          console.error(err);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    loadNews();

    return () => {
      isMounted = false;
    };
  }, [name, ticker]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between px-1">
        <h2 className="text-xl font-semibold">Market News</h2>
        <span className="flex items-center gap-1.5 text-xs font-mono text-brand-primary bg-brand-primary/10 px-2.5 py-1 rounded-full border border-brand-primary/20">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-primary opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-primary"></span>
          </span>
          LIVE SEARCH
        </span>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
             <div key={i} className="bg-brand-surface border border-brand-border rounded-xl p-5 animate-pulse">
                <div className="h-6 bg-brand-border rounded w-3/4 mb-3"></div>
                <div className="h-3 bg-brand-border rounded w-1/4 mb-5"></div>
                <div className="space-y-2">
                    <div className="h-3 bg-brand-bg rounded w-full"></div>
                    <div className="h-3 bg-brand-bg rounded w-5/6"></div>
                </div>
             </div>
          ))}
        </div>
      ) : error ? (
        <div className="text-brand-danger bg-brand-danger/10 p-4 rounded-lg border border-brand-danger/20 text-sm flex items-center gap-2">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          {error}
        </div>
      ) : (
        <div className="space-y-4">
          {newsItems.length === 0 ? (
             <div className="text-center py-8 bg-brand-surface border border-brand-border rounded-xl">
                 <p className="text-brand-text-secondary">No recent news found for this asset.</p>
             </div>
          ) : (
             newsItems.map((item, idx) => (
                <div key={idx} className="group bg-brand-surface hover:bg-brand-surface/80 border border-brand-border hover:border-brand-primary/40 transition-all duration-300 rounded-xl p-5 shadow-sm hover:shadow-lg hover:-translate-y-0.5">
                    <div className="flex flex-col gap-3">
                         <h3 className="text-lg font-bold text-brand-text-primary leading-snug group-hover:text-white transition-colors">
                            {item.headline}
                         </h3>
                         <div className="flex items-center gap-2 text-xs text-brand-text-secondary uppercase tracking-wider font-bold">
                            <span className="bg-brand-bg px-2 py-0.5 rounded border border-brand-border">{item.sourceDate}</span>
                         </div>
                         <p className="text-sm text-brand-text-secondary leading-relaxed pl-3 border-l-2 border-brand-border group-hover:border-brand-primary group-hover:text-brand-text-primary/90 transition-all">
                            {item.summary}
                         </p>
                    </div>
                </div>
             ))
          )}

          {/* Grounding Sources */}
          {sources.length > 0 && (
            <div className="mt-6 pt-4 border-t border-brand-border/50">
              <p className="text-[10px] text-brand-text-secondary mb-3 uppercase tracking-widest font-bold opacity-60">Verified Sources & Citations</p>
              <div className="flex flex-wrap gap-2">
                {sources.map((chunk, idx) => {
                  if (chunk.web?.uri && chunk.web?.title) {
                    return (
                      <a 
                        key={idx} 
                        href={chunk.web.uri} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 text-[11px] bg-brand-bg hover:bg-brand-primary/10 text-brand-text-secondary hover:text-brand-primary border border-brand-border hover:border-brand-primary/50 rounded-full px-3 py-1.5 transition-all max-w-full truncate"
                      >
                        <svg className="w-3 h-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>
                        <span className="truncate">{chunk.web.title}</span>
                      </a>
                    );
                  }
                  return null;
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default StockNews;
