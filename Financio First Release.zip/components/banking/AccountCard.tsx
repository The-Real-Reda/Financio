
import React from 'react';
import { BankAccount } from '../../types';
import Card from '../common/Card';

interface AccountCardProps {
  account: BankAccount;
}

const AccountCard: React.FC<AccountCardProps> = ({ account }) => {
  return (
    <Card className="flex flex-col justify-between">
      <div>
        <p className="text-brand-text-secondary">{account.provider}</p>
        <p className="text-lg font-semibold">{account.name}</p>
        <p className="text-sm text-brand-text-secondary">{account.accountNumber}</p>
      </div>
      <div className="mt-6 text-right">
        <p className="text-sm text-brand-text-secondary">Balance</p>
        <p className="text-3xl font-bold text-brand-primary">
          {account.balance.toLocaleString('en-US', { style: 'currency', currency: account.currency })}
        </p>
      </div>
    </Card>
  );
};

export default AccountCard;
