
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import Icon from '../common/Icon';
import Logo from '../common/Logo';
import AccountWidget from './AccountWidget';

interface SidebarProps {
  user: string | null;
  onLogout: () => void;
}

const navItems = [
  { name: 'Dashboard', path: '/', icon: 'dashboard' as const },
  { name: 'Invest', path: '/invest', icon: 'invest' as const },
  { name: 'Banking', path: '/banking', icon: 'banking' as const },
  { name: 'AI Advisor', path: '/advisor', icon: 'advisor' as const },
];

const Sidebar: React.FC<SidebarProps> = ({ user, onLogout }) => {
  const navigate = useNavigate();

  return (
    <aside className="w-20 lg:w-64 bg-brand-surface border-r border-brand-border flex flex-col justify-between transition-all duration-300">
      <div>
        <div className="flex items-center justify-center lg:justify-start lg:pl-6 h-20 border-b border-brand-border gap-3">
          <Logo className="w-10 h-10 flex-shrink-0" />
          <h1 className="text-2xl font-bold hidden lg:block tracking-tight text-white">Financio</h1>
        </div>
        <nav className="mt-6 px-3">
          <ul className="space-y-2">
            {navItems.map((item) => (
              <li key={item.name}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `flex items-center p-3 rounded-xl transition-all duration-200 group ${
                      isActive
                        ? 'bg-brand-primary/10 text-brand-primary border border-brand-primary/20'
                        : 'text-brand-text-secondary hover:bg-brand-bg hover:text-brand-text-primary'
                    }`
                  }
                >
                  <Icon name={item.icon} className={`w-6 h-6 group-hover:scale-110 transition-transform`} />
                  <span className="ml-4 font-medium hidden lg:block">{item.name}</span>
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      <div className="p-3 lg:p-6 border-t border-brand-border space-y-4">
        <div className="hidden lg:block">
           <AccountWidget 
             user={user} 
             onLogout={onLogout} 
             onAddAccount={() => navigate('/banking')}
           />
        </div>
        <div className="lg:hidden">
            <AccountWidget user={user} compact={true} />
        </div>

        <button
          onClick={onLogout}
          className="lg:hidden w-full flex items-center justify-center p-3 rounded-lg transition-colors duration-200 text-brand-text-secondary hover:bg-brand-danger/10 hover:text-brand-danger"
        >
          <Icon name="logout" className="w-6 h-6" />
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
