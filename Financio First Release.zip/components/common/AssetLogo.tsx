
import React, { useState, useEffect } from 'react';

interface AssetLogoProps {
  logo?: string;
  name: string;
  ticker: string;
  className?: string;
}

const AssetLogo: React.FC<AssetLogoProps> = ({ logo, name, ticker, className = "w-10 h-10" }) => {
  const [error, setError] = useState(false);

  // Reset error state if logo url changes
  useEffect(() => {
    setError(false);
  }, [logo]);

  if (!logo || error) {
    // Generate a consistent color based on the ticker char code
    const colors = [
        'bg-blue-900 text-blue-200',
        'bg-green-900 text-green-200',
        'bg-purple-900 text-purple-200',
        'bg-yellow-900 text-yellow-200',
        'bg-red-900 text-red-200',
        'bg-indigo-900 text-indigo-200',
    ];
    const charCode = ticker.charCodeAt(0) || 0;
    const colorClass = colors[charCode % colors.length];

    return (
      <div className={`${className} ${colorClass} rounded-full flex items-center justify-center font-bold border border-white/10 shadow-sm overflow-hidden`}>
        <span className="text-[0.6em]">{ticker.substring(0, 3)}</span>
      </div>
    );
  }

  return (
    <div className={`${className} bg-white rounded-full p-[2px] flex items-center justify-center overflow-hidden shadow-sm ring-1 ring-white/20`}>
      <img 
        src={logo} 
        alt={`${name} logo`} 
        className="w-full h-full object-contain rounded-full"
        onError={() => setError(true)}
      />
    </div>
  );
};

export default AssetLogo;
