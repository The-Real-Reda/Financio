
import { Asset, AssetType, BankAccount, Transaction, ChartDataPoint } from './types';

export const MOCK_ASSETS: Asset[] = [
  // Tech Giants
  { id: '1', name: 'Apple Inc.', ticker: 'AAPL', type: AssetType.Stock, price: 172.25, change24h: 2.50, change24h_percent: 1.47, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/apple.com' },
  { id: '2', name: 'Microsoft', ticker: 'MSFT', type: AssetType.Stock, price: 420.55, change24h: 3.20, change24h_percent: 0.76, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/microsoft.com' },
  { id: '3', name: 'Google', ticker: 'GOOGL', type: AssetType.Stock, price: 173.90, change24h: 1.10, change24h_percent: 0.64, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/google.com' },
  { id: '4', name: 'Amazon', ticker: 'AMZN', type: AssetType.Stock, price: 180.30, change24h: -1.50, change24h_percent: -0.83, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/amazon.com' },
  { id: '5', name: 'NVIDIA', ticker: 'NVDA', type: AssetType.Stock, price: 880.08, change24h: 15.12, change24h_percent: 1.75, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/nvidia.com' },
  { id: '6', name: 'Meta', ticker: 'META', type: AssetType.Stock, price: 495.10, change24h: 8.50, change24h_percent: 1.75, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/meta.com' },
  { id: '7', name: 'Tesla', ticker: 'TSLA', type: AssetType.Stock, price: 175.00, change24h: -5.20, change24h_percent: -2.89, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/tesla.com' },
  { id: '8', name: 'Netflix', ticker: 'NFLX', type: AssetType.Stock, price: 620.25, change24h: 4.30, change24h_percent: 0.70, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/netflix.com' },
  { id: '9', name: 'AMD', ticker: 'AMD', type: AssetType.Stock, price: 170.40, change24h: 3.10, change24h_percent: 1.85, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/amd.com' },
  { id: '10', name: 'Intel', ticker: 'INTC', type: AssetType.Stock, price: 30.50, change24h: -0.40, change24h_percent: -1.29, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/intel.com' },
  { id: '11', name: 'Salesforce', ticker: 'CRM', type: AssetType.Stock, price: 298.50, change24h: 1.20, change24h_percent: 0.40, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/salesforce.com' },
  { id: '12', name: 'Adobe', ticker: 'ADBE', type: AssetType.Stock, price: 485.20, change24h: -2.30, change24h_percent: -0.47, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/adobe.com' },
  { id: '13', name: 'Oracle', ticker: 'ORCL', type: AssetType.Stock, price: 125.80, change24h: 0.90, change24h_percent: 0.72, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/oracle.com' },
  { id: '14', name: 'IBM', ticker: 'IBM', type: AssetType.Stock, price: 190.10, change24h: 1.50, change24h_percent: 0.79, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/ibm.com' },

  // Crypto
  { id: '15', name: 'Bitcoin', ticker: 'BTC', type: AssetType.Crypto, price: 68134.78, change24h: -1200.45, change24h_percent: -1.73, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/bitcoin.org' },
  { id: '16', name: 'Ethereum', ticker: 'ETH', type: AssetType.Crypto, price: 3540.12, change24h: 80.23, change24h_percent: 2.31, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/ethereum.org' },
  { id: '17', name: 'Solana', ticker: 'SOL', type: AssetType.Crypto, price: 145.20, change24h: 5.40, change24h_percent: 3.86, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/solana.com' },
  { id: '18', name: 'Cardano', ticker: 'ADA', type: AssetType.Crypto, price: 0.45, change24h: 0.01, change24h_percent: 2.27, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/cardano.org' },
  { id: '19', name: 'Polkadot', ticker: 'DOT', type: AssetType.Crypto, price: 7.20, change24h: -0.10, change24h_percent: -1.37, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/polkadot.network' },
  { id: '20', name: 'Dogecoin', ticker: 'DOGE', type: AssetType.Crypto, price: 0.16, change24h: 0.01, change24h_percent: 6.66, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/dogecoin.com' },
  { id: '21', name: 'Chainlink', ticker: 'LINK', type: AssetType.Crypto, price: 18.50, change24h: 0.50, change24h_percent: 2.78, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/chain.link' },
  { id: '22', name: 'Polygon', ticker: 'MATIC', type: AssetType.Crypto, price: 0.95, change24h: 0.02, change24h_percent: 2.15, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/polygon.technology' },
  { id: '23', name: 'Avalanche', ticker: 'AVAX', type: AssetType.Crypto, price: 45.20, change24h: 1.10, change24h_percent: 2.49, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/avax.network' },
  { id: '24', name: 'Uniswap', ticker: 'UNI', type: AssetType.Crypto, price: 11.50, change24h: 0.30, change24h_percent: 2.68, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/uniswap.org' },

  // Finance
  { id: '25', name: 'JPMorgan', ticker: 'JPM', type: AssetType.Stock, price: 195.40, change24h: 1.10, change24h_percent: 0.57, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/jpmorganchase.com' },
  { id: '26', name: 'Bank of America', ticker: 'BAC', type: AssetType.Stock, price: 38.20, change24h: 0.15, change24h_percent: 0.39, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/bankofamerica.com' },
  { id: '27', name: 'Visa', ticker: 'V', type: AssetType.Stock, price: 278.50, change24h: 1.80, change24h_percent: 0.65, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/visa.com' },
  { id: '28', name: 'Mastercard', ticker: 'MA', type: AssetType.Stock, price: 455.10, change24h: 2.20, change24h_percent: 0.49, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/mastercard.com' },
  { id: '29', name: 'Goldman Sachs', ticker: 'GS', type: AssetType.Stock, price: 410.30, change24h: 3.50, change24h_percent: 0.86, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/goldmansachs.com' },
  { id: '30', name: 'PayPal', ticker: 'PYPL', type: AssetType.Stock, price: 65.40, change24h: -0.80, change24h_percent: -1.21, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/paypal.com' },
  { id: '31', name: 'Block', ticker: 'SQ', type: AssetType.Stock, price: 82.30, change24h: 1.90, change24h_percent: 2.36, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/block.xyz' },
  { id: '32', name: 'Coinbase', ticker: 'COIN', type: AssetType.Stock, price: 255.40, change24h: 12.10, change24h_percent: 4.97, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/coinbase.com' },
  { id: '33', name: 'Robinhood', ticker: 'HOOD', type: AssetType.Stock, price: 18.50, change24h: 0.50, change24h_percent: 2.78, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/robinhood.com' },

  // Consumer
  { id: '34', name: 'Coca-Cola', ticker: 'KO', type: AssetType.Stock, price: 62.10, change24h: 0.20, change24h_percent: 0.32, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/coca-colacompany.com' },
  { id: '35', name: 'PepsiCo', ticker: 'PEP', type: AssetType.Stock, price: 172.50, change24h: 0.40, change24h_percent: 0.23, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/pepsico.com' },
  { id: '36', name: 'McDonald\'s', ticker: 'MCD', type: AssetType.Stock, price: 275.80, change24h: 1.50, change24h_percent: 0.55, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/mcdonalds.com' },
  { id: '37', name: 'Starbucks', ticker: 'SBUX', type: AssetType.Stock, price: 88.40, change24h: -0.50, change24h_percent: -0.56, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/starbucks.com' },
  { id: '38', name: 'Nike', ticker: 'NKE', type: AssetType.Stock, price: 92.30, change24h: 0.80, change24h_percent: 0.87, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/nike.com' },
  { id: '39', name: 'Walmart', ticker: 'WMT', type: AssetType.Stock, price: 60.50, change24h: 0.10, change24h_percent: 0.17, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/walmart.com' },
  { id: '40', name: 'Target', ticker: 'TGT', type: AssetType.Stock, price: 165.20, change24h: 1.20, change24h_percent: 0.73, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/target.com' },
  { id: '41', name: 'Costco', ticker: 'COST', type: AssetType.Stock, price: 780.10, change24h: 5.50, change24h_percent: 0.71, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/costco.com' },
  { id: '42', name: 'Disney', ticker: 'DIS', type: AssetType.Stock, price: 115.40, change24h: 1.10, change24h_percent: 0.96, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/disney.com' },

  // Health
  { id: '43', name: 'Johnson & Johnson', ticker: 'JNJ', type: AssetType.Stock, price: 155.20, change24h: 0.30, change24h_percent: 0.19, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/jnj.com' },
  { id: '44', name: 'Pfizer', ticker: 'PFE', type: AssetType.Stock, price: 27.80, change24h: -0.10, change24h_percent: -0.36, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/pfizer.com' },
  { id: '45', name: 'Eli Lilly', ticker: 'LLY', type: AssetType.Stock, price: 780.50, change24h: 12.50, change24h_percent: 1.63, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/lilly.com' },
  
  // Energy
  { id: '46', name: 'Exxon Mobil', ticker: 'XOM', type: AssetType.Stock, price: 118.20, change24h: 1.40, change24h_percent: 1.20, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/corporate.exxonmobil.com' },
  { id: '47', name: 'Chevron', ticker: 'CVX', type: AssetType.Stock, price: 158.40, change24h: 0.90, change24h_percent: 0.57, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/chevron.com' },

  // Commodities & Others
  { id: '48', name: 'Gold', ticker: 'XAU', type: AssetType.Commodity, price: 2350.10, change24h: 15.80, change24h_percent: 0.68, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/barrick.com' }, // Using major gold miner as proxy logo
  { id: '49', name: 'Uber', ticker: 'UBER', type: AssetType.Stock, price: 78.50, change24h: 2.10, change24h_percent: 2.75, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/uber.com' },
  { id: '50', name: 'Airbnb', ticker: 'ABNB', type: AssetType.Stock, price: 160.20, change24h: 1.50, change24h_percent: 0.95, value: 0, holdings: 0, logo: 'https://logo.clearbit.com/airbnb.com' },
];

export const MOCK_ACCOUNTS: BankAccount[] = [];

export const MOCK_TRANSACTIONS: Transaction[] = [];

export const MOCK_CHART_DATA: ChartDataPoint[] = [
  { date: 'Jan', price: 100 },
  { date: 'Feb', price: 120 },
  { date: 'Mar', price: 115 },
  { date: 'Apr', price: 140 },
  { date: 'May', price: 135 },
  { date: 'Jun', price: 160 },
  { date: 'Jul', price: 180 },
];
