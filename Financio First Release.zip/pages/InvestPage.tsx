
import React, { useState, useEffect } from 'react';
import { MOCK_CHART_DATA } from '../constants';
import Card from '../components/common/Card';
import StockChart from '../components/invest/StockChart';
import StockNews from '../components/invest/StockNews';
import { Asset } from '../types';
import { useFinance } from '../context/FinanceContext';
import { Link } from 'react-router-dom';
import Icon from '../components/common/Icon';
import AssetLogo from '../components/common/AssetLogo';

const InvestPage: React.FC = () => {
  const { assets, executeTrade, accounts } = useFinance();
  const [selectedAssetId, setSelectedAssetId] = useState<string>(assets[0]?.id);
  const [tradeAmount, setTradeAmount] = useState('1');
  const [tradeType, setTradeType] = useState<'buy' | 'sell'>('buy');
  const [feedback, setFeedback] = useState<{msg: string, type: 'success' | 'error'} | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  // Filter assets based on search term
  const filteredAssets = assets.filter(a => 
    a.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    a.ticker.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // If selected asset gets filtered out, select the first visible one
  useEffect(() => {
    if (filteredAssets.length > 0 && !filteredAssets.find(a => a.id === selectedAssetId)) {
        setSelectedAssetId(filteredAssets[0].id);
    }
  }, [searchTerm, filteredAssets, selectedAssetId]);

  // Get current state of the selected asset
  const selectedAsset = assets.find(a => a.id === selectedAssetId) || filteredAssets[0] || assets[0];

  // Find the funding account (assuming 'Investment Account' or first available)
  const fundingAccount = accounts.find(a => a.provider === 'Fidelity') || accounts[0];

  const handleTrade = () => {
    setFeedback(null);
    const amount = parseFloat(tradeAmount);
    if (isNaN(amount) || amount <= 0) {
      setFeedback({ msg: "Please enter a valid amount", type: 'error' });
      return;
    }

    const result = executeTrade(selectedAsset.id, tradeType, amount);
    setFeedback({ 
      msg: result.message, 
      type: result.success ? 'success' : 'error' 
    });
  };

  // Clear feedback after 3 seconds
  useEffect(() => {
    if (feedback) {
      const timer = setTimeout(() => setFeedback(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [feedback]);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h1 className="text-3xl font-bold text-brand-text-primary">Invest</h1>
          <p className="text-brand-text-secondary mt-1">Analyze assets and execute trades.</p>
        </div>
        <div className="relative w-full md:w-64">
           <input 
             type="text" 
             placeholder="Search stocks, crypto..." 
             value={searchTerm}
             onChange={(e) => setSearchTerm(e.target.value)}
             className="w-full bg-brand-surface border border-brand-border rounded-lg pl-10 pr-4 py-2 text-brand-text-primary focus:outline-none focus:border-brand-primary"
           />
           <div className="absolute left-3 top-2.5 text-brand-text-secondary">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
             </svg>
           </div>
        </div>
      </div>

      <div className="flex space-x-2 overflow-x-auto pb-4 scrollbar-hide">
        {filteredAssets.map(asset => (
          <button
            key={asset.id}
            onClick={() => setSelectedAssetId(asset.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all ${
                selectedAsset?.id === asset.id 
                ? 'bg-brand-primary text-white shadow-lg shadow-brand-primary/20 ring-2 ring-brand-primary/50' 
                : 'bg-brand-surface hover:bg-brand-border text-brand-text-secondary'
            }`}
          >
            <AssetLogo logo={asset.logo} name={asset.name} ticker={asset.ticker} className="w-5 h-5" />
            {asset.ticker}
          </button>
        ))}
        {filteredAssets.length === 0 && (
            <p className="text-brand-text-secondary p-2">No assets found matching "{searchTerm}"</p>
        )}
      </div>

      {selectedAsset && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
                <Card className="relative overflow-hidden">
                    {/* Background Glow Effect */}
                    <div className="absolute top-0 right-0 w-64 h-64 bg-brand-primary/10 blur-[80px] rounded-full pointer-events-none -mr-16 -mt-16"></div>
                    
                    <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
                        <div className="flex items-center gap-6">
                        <div className="relative">
                            <div className="absolute inset-0 bg-brand-primary/30 blur-xl rounded-full"></div>
                            <AssetLogo logo={selectedAsset.logo} name={selectedAsset.name} ticker={selectedAsset.ticker} className="w-20 h-20 relative z-10" />
                        </div>
                        <div>
                            <h2 className="text-3xl font-bold">{selectedAsset.name}</h2>
                            <div className="flex items-center gap-2 mt-1">
                                <span className="text-brand-text-secondary font-mono bg-brand-bg px-2 py-0.5 rounded border border-brand-border">{selectedAsset.ticker}</span>
                                <span className="text-sm text-brand-text-secondary">{selectedAsset.type}</span>
                            </div>
                        </div>
                        </div>
                        
                        <div className="text-left sm:text-right">
                            <p className="text-4xl font-bold tracking-tight">${selectedAsset.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                            <p className={`mt-1 font-semibold flex items-center sm:justify-end gap-1 ${selectedAsset.change24h >= 0 ? 'text-brand-success' : 'text-brand-danger'}`}>
                                {selectedAsset.change24h >= 0 ? <Icon name="invest" className="w-5 h-5" /> : <Icon name="invest" className="w-5 h-5 rotate-180" />}
                                {selectedAsset.change24h >= 0 ? '+' : ''}{selectedAsset.change24h.toFixed(2)} ({selectedAsset.change24h_percent.toFixed(2)}%)
                            </p>
                        </div>
                    </div>

                    <div className="h-96 mt-8">
                        <StockChart data={MOCK_CHART_DATA} positive={selectedAsset.change24h >= 0} />
                    </div>
                </Card>

                {/* News Section */}
                <StockNews name={selectedAsset.name} ticker={selectedAsset.ticker} />
            </div>
            
            <Card className="h-fit">
            <h2 className="text-xl font-semibold mb-4">Trade {selectedAsset.ticker}</h2>
            
            <div className="text-sm text-brand-text-secondary mb-4 p-3 bg-brand-bg rounded-lg border border-brand-border">
                <div className="flex justify-between items-center mb-2">
                <span>Available Funds</span>
                <span className="text-brand-text-primary font-bold font-mono text-lg">
                    {fundingAccount 
                    ? `$${fundingAccount.balance.toLocaleString(undefined, {minimumFractionDigits: 2})}`
                    : '$0.00'
                    }
                </span>
                </div>
                {fundingAccount && <div className="text-xs text-brand-text-secondary text-right mb-2">Via: {fundingAccount.name}</div>}
                <div className="w-full h-px bg-brand-border mb-2"></div>
                <div className="flex justify-between items-center">
                <span>Your Holdings</span>
                <span className="text-brand-text-primary font-mono">{selectedAsset.holdings} {selectedAsset.ticker}</span>
                </div>
            </div>

            <div className="flex bg-brand-bg rounded-lg p-1 mb-4 border border-brand-border">
                <button 
                    onClick={() => setTradeType('buy')} 
                    className={`flex-1 py-2 rounded-md transition-all font-medium ${
                        tradeType === 'buy' ? 'bg-brand-success text-white shadow-md' : 'text-brand-text-secondary hover:text-brand-text-primary'
                    }`}
                >
                    Buy
                </button>
                <button 
                    onClick={() => setTradeType('sell')} 
                    className={`flex-1 py-2 rounded-md transition-all font-medium ${
                        tradeType === 'sell' ? 'bg-brand-danger text-white shadow-md' : 'text-brand-text-secondary hover:text-brand-text-primary'
                    }`}
                >
                    Sell
                </button>
            </div>
            <div>
                <label htmlFor="amount" className="text-sm text-brand-text-secondary block mb-2">Quantity ({selectedAsset.ticker})</label>
                <div className="relative">
                    <input
                        type="number"
                        id="amount"
                        value={tradeAmount}
                        onChange={(e) => setTradeAmount(e.target.value)}
                        className="w-full bg-brand-bg border border-brand-border rounded-lg p-3 text-lg font-mono focus:outline-none focus:border-brand-primary transition-colors"
                        min="0"
                    />
                    <div className="absolute right-3 top-3.5 text-xs text-brand-text-secondary font-bold">SHARES</div>
                </div>
            </div>
            <div className="mt-6 space-y-2">
                <div className="flex justify-between text-sm">
                    <span className="text-brand-text-secondary">Estimated Value</span>
                    <span className="font-semibold">${(parseFloat(tradeAmount || '0') * selectedAsset.price).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
                <div className="flex justify-between text-sm">
                    <span className="text-brand-text-secondary">Fees</span>
                    <span className="font-semibold">$1.99</span>
                </div>
                <div className="w-full h-px bg-brand-border my-2"></div>
                <div className="flex justify-between text-base font-bold">
                    <span>Total</span>
                    <span>${((parseFloat(tradeAmount || '0') * selectedAsset.price) + 1.99).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</span>
                </div>
            </div>
            
            {feedback && (
                <div className={`mt-4 p-3 rounded-lg text-sm text-center font-medium animate-in fade-in slide-in-from-top-2 ${
                    feedback.type === 'success' ? 'bg-brand-success/10 text-brand-success border border-brand-success/20' : 'bg-brand-danger/10 text-brand-danger border border-brand-danger/20'
                }`}>
                {feedback.msg}
                </div>
            )}

            {fundingAccount ? (
                <button 
                    onClick={handleTrade}
                    className={`w-full mt-6 py-3.5 font-bold text-white rounded-xl transition-all shadow-lg hover:shadow-xl active:scale-95 ${
                        tradeType === 'buy' 
                        ? 'bg-gradient-to-r from-brand-success to-emerald-600 hover:brightness-110' 
                        : 'bg-gradient-to-r from-brand-danger to-red-600 hover:brightness-110'
                    }`}
                >
                    {tradeType === 'buy' ? 'Confirm Purchase' : 'Confirm Sale'}
                </button>
            ) : (
                <div className="mt-6">
                    <Link to="/banking" className="block w-full text-center py-3.5 font-bold text-brand-bg bg-brand-primary rounded-xl hover:bg-brand-secondary transition-colors">
                        Link Bank Account
                    </Link>
                </div>
            )}
            </Card>
        </div>
      )}
    </div>
  );
};

export default InvestPage;
