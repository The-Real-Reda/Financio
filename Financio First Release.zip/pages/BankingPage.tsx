
import React, { useState } from 'react';
import Card from '../components/common/Card';
import AccountCard from '../components/banking/AccountCard';
import { Transaction } from '../types';
import { useFinance } from '../context/FinanceContext';

const BankingPage: React.FC = () => {
  const { accounts, transactions, updateAccountBalance, addTransaction, addBankAccount } = useFinance();
  
  // State for manual transaction form
  const [txnDesc, setTxnDesc] = useState('');
  const [txnAmount, setTxnAmount] = useState('');
  const [txnType, setTxnType] = useState<'credit' | 'debit'>('debit');

  // State for manual balance update form
  const [selectedAccId, setSelectedAccId] = useState('');
  const [newBalance, setNewBalance] = useState('');

  // State for adding new bank account
  const [newAccName, setNewAccName] = useState('');
  const [newAccProvider, setNewAccProvider] = useState('');
  const [newAccBalance, setNewAccBalance] = useState('');

  const formatCurrency = (value: number) => {
    return value.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
  };

  const handleAddTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!txnDesc || !txnAmount) return;
    addTransaction(txnDesc, parseFloat(txnAmount), txnType);
    setTxnDesc('');
    setTxnAmount('');
    alert('Transaction added and balance updated!');
  };

  const handleUpdateBalance = (e: React.FormEvent) => {
    e.preventDefault();
    const targetId = selectedAccId || accounts[0]?.id;
    if (!targetId || !newBalance) return;
    updateAccountBalance(targetId, parseFloat(newBalance));
    setNewBalance('');
    alert('Account balance updated manually.');
  };

  const handleAddBankAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if(!newAccName || !newAccProvider || !newAccBalance) return;
    addBankAccount(newAccName, newAccProvider, parseFloat(newAccBalance));
    setNewAccName('');
    setNewAccProvider('');
    setNewAccBalance('');
  };
  
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-brand-text-primary">Banking</h1>
        <p className="text-brand-text-secondary mt-1">Manage your connected accounts and transactions.</p>
      </div>
      
      {accounts.length === 0 ? (
        <Card className="text-center py-12">
            <h2 className="text-xl font-semibold mb-2">No Accounts Linked</h2>
            <p className="text-brand-text-secondary mb-4">Add your first bank account to get started.</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {accounts.map(account => (
            <AccountCard key={account.id} account={account} />
            ))}
        </div>
      )}

      {/* Add New Bank Account Form */}
      <Card>
        <h2 className="text-xl font-semibold mb-4">Add Bank Account</h2>
        <form onSubmit={handleAddBankAccount} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label className="block text-sm text-brand-text-secondary mb-1">Bank Name</label>
                <input 
                    type="text" 
                    value={newAccProvider}
                    onChange={(e) => setNewAccProvider(e.target.value)}
                    placeholder="e.g. Chase"
                    className="w-full bg-brand-bg border border-brand-border rounded p-2 text-brand-text-primary focus:outline-none focus:border-brand-primary"
                />
            </div>
            <div>
                <label className="block text-sm text-brand-text-secondary mb-1">Account Nickname</label>
                <input 
                    type="text" 
                    value={newAccName}
                    onChange={(e) => setNewAccName(e.target.value)}
                    placeholder="e.g. Checking"
                    className="w-full bg-brand-bg border border-brand-border rounded p-2 text-brand-text-primary focus:outline-none focus:border-brand-primary"
                />
            </div>
            <div>
                <label className="block text-sm text-brand-text-secondary mb-1">Initial Balance</label>
                <input 
                    type="number" 
                    value={newAccBalance}
                    onChange={(e) => setNewAccBalance(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-brand-bg border border-brand-border rounded p-2 text-brand-text-primary focus:outline-none focus:border-brand-primary"
                />
            </div>
            <div className="md:col-span-3">
                <button type="submit" className="w-full bg-brand-secondary hover:bg-brand-primary text-white font-bold py-2 rounded transition-colors">
                    Add Account
                </button>
            </div>
        </form>
      </Card>

      {accounts.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Manual Balance Update Form */}
            <Card>
                <h2 className="text-xl font-semibold mb-4">Manual Balance Adjustment</h2>
                <form onSubmit={handleUpdateBalance} className="space-y-4">
                    <div>
                        <label className="block text-sm text-brand-text-secondary mb-1">Select Account</label>
                        <select 
                            value={selectedAccId} 
                            onChange={(e) => setSelectedAccId(e.target.value)}
                            className="w-full bg-brand-bg border border-brand-border rounded p-2 text-brand-text-primary focus:outline-none focus:border-brand-primary"
                        >
                            {accounts.map(acc => <option key={acc.id} value={acc.id}>{acc.name} - {acc.provider}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm text-brand-text-secondary mb-1">New Balance Amount</label>
                        <input 
                            type="number" 
                            step="0.01"
                            value={newBalance}
                            onChange={(e) => setNewBalance(e.target.value)}
                            placeholder="e.g. 5000.00"
                            className="w-full bg-brand-bg border border-brand-border rounded p-2 text-brand-text-primary focus:outline-none focus:border-brand-primary"
                        />
                    </div>
                    <button type="submit" className="w-full bg-brand-primary hover:bg-brand-secondary text-white font-bold py-2 rounded transition-colors">
                        Update Balance
                    </button>
                </form>
            </Card>

            {/* Add Income/Expense Form */}
            <Card>
                <h2 className="text-xl font-semibold mb-4">Add Transaction (Income/Output)</h2>
                <form onSubmit={handleAddTransaction} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <button 
                            type="button"
                            onClick={() => setTxnType('credit')}
                            className={`py-2 rounded border ${txnType === 'credit' ? 'bg-brand-success border-brand-success text-white' : 'border-brand-border text-brand-text-secondary'}`}
                        >
                            Income (+)
                        </button>
                        <button 
                             type="button"
                            onClick={() => setTxnType('debit')}
                            className={`py-2 rounded border ${txnType === 'debit' ? 'bg-brand-danger border-brand-danger text-white' : 'border-brand-border text-brand-text-secondary'}`}
                        >
                            Money Output (-)
                        </button>
                    </div>
                    <div>
                        <label className="block text-sm text-brand-text-secondary mb-1">Description</label>
                        <input 
                            type="text" 
                            value={txnDesc}
                            onChange={(e) => setTxnDesc(e.target.value)}
                            placeholder="e.g. Salary, Rent, Grocery"
                            className="w-full bg-brand-bg border border-brand-border rounded p-2 text-brand-text-primary focus:outline-none focus:border-brand-primary"
                        />
                    </div>
                    <div>
                        <label className="block text-sm text-brand-text-secondary mb-1">Amount</label>
                        <input 
                            type="number" 
                            step="0.01"
                            value={txnAmount}
                            onChange={(e) => setTxnAmount(e.target.value)}
                            placeholder="0.00"
                            className="w-full bg-brand-bg border border-brand-border rounded p-2 text-brand-text-primary focus:outline-none focus:border-brand-primary"
                        />
                    </div>
                    <button type="submit" className="w-full bg-brand-surface border border-brand-primary text-brand-primary hover:bg-brand-primary hover:text-white font-bold py-2 rounded transition-colors">
                        Record Transaction
                    </button>
                </form>
            </Card>
          </div>
      )}

      {transactions.length > 0 && (
          <Card>
            <h2 className="text-xl font-semibold mb-4">Recent Transactions</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="border-b border-brand-border text-sm text-brand-text-secondary">
                  <tr>
                    <th className="py-3 px-4 font-medium">Date</th>
                    <th className="py-3 px-4 font-medium">Description</th>
                    <th className="py-3 px-4 font-medium text-right">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((txn: Transaction) => (
                    <tr key={txn.id} className="border-b border-brand-border last:border-b-0 hover:bg-white/5">
                      <td className="py-4 px-4 text-brand-text-secondary">{txn.date}</td>
                      <td className="py-4 px-4 font-medium">{txn.description}</td>
                      <td className={`py-4 px-4 text-right font-semibold ${txn.type === 'credit' ? 'text-brand-success' : 'text-brand-text-primary'}`}>
                        {txn.type === 'debit' ? '-' : '+'}{formatCurrency(txn.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
      )}
    </div>
  );
};

export default BankingPage;
