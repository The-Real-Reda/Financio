
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/common/Card';
import PortfolioChart from '../components/dashboard/PortfolioChart';
import AssetList from '../components/dashboard/AssetList';
import { useFinance } from '../context/FinanceContext';

const DashboardPage: React.FC = () => {
  const { assets } = useFinance();
  const navigate = useNavigate();
  const totalValue = assets.reduce((sum, asset) => sum + asset.value, 0);

  // Calculate total daily change based on current asset performance
  const totalChangeValue = assets.reduce((sum, asset) => sum + (asset.change24h * asset.holdings), 0);
  const totalChangePercent = totalValue > 0 ? (totalChangeValue / totalValue) * 100 : 0;

  // Find best/worst based on current percentage change
  const sortedAssets = [...assets].sort((a, b) => b.change24h_percent - a.change24h_percent);
  const bestPerformer = sortedAssets[0];
  const worstPerformer = sortedAssets[sortedAssets.length - 1];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-brand-text-primary">Dashboard</h1>
        <p className="text-brand-text-secondary mt-1">Welcome back, here's your live financial overview.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <h2 className="text-xl font-semibold mb-1">Portfolio Value</h2>
          <p className="text-4xl font-bold text-brand-primary">
            ${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <div className="h-72 mt-4">
            <PortfolioChart currentValue={totalValue} />
          </div>
        </Card>

        <Card>
          <h2 className="text-xl font-semibold mb-4">Quick Stats</h2>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-brand-text-secondary">24h Change</p>
              <p className={`text-2xl font-bold ${totalChangeValue >= 0 ? 'text-brand-success' : 'text-brand-danger'}`}>
                {totalChangeValue >= 0 ? '+' : ''}${Math.abs(totalChangeValue).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})} ({totalChangePercent.toFixed(2)}%)
              </p>
            </div>
            {bestPerformer && (
              <div>
                <p className="text-sm text-brand-text-secondary">Best Performer</p>
                <p className="text-xl font-semibold">{bestPerformer.name} ({bestPerformer.ticker})</p>
              </div>
            )}
            {worstPerformer && (
              <div>
                <p className="text-sm text-brand-text-secondary">Worst Performer</p>
                <p className="text-xl font-semibold">{worstPerformer.name} ({worstPerformer.ticker})</p>
              </div>
            )}
            <button 
              onClick={() => navigate('/invest')}
              className="w-full bg-brand-primary text-white font-bold py-3 rounded-lg hover:bg-brand-secondary transition-colors"
            >
              Make a Trade
            </button>
          </div>
        </Card>
      </div>
      
      <Card>
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Your Assets</h2>
            <span className="text-xs text-brand-text-secondary animate-pulse">Live Updates Active</span>
        </div>
        <AssetList assets={assets} />
      </Card>
    </div>
  );
};

export default DashboardPage;
