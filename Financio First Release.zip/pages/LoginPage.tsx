
import React, { useState } from 'react';
import Icon from '../components/common/Icon';
import Logo from '../components/common/Logo';

interface LoginPageProps {
  onLogin: (username: string) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username && password) {
      // Simulation of auth
      onLogin(username);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-brand-bg p-4 text-brand-text-primary">
      <div className="w-full max-w-md bg-brand-surface p-8 rounded-2xl border border-brand-border shadow-2xl relative overflow-hidden">
        {/* Background Decoration */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-brand-success to-brand-primary"></div>
        
        <div className="flex flex-col items-center mb-8 z-10 relative">
          <div className="mb-4">
             <Logo className="w-20 h-20 drop-shadow-lg" />
          </div>
          <h1 className="text-3xl font-bold text-center tracking-tight">Financio</h1>
          <p className="text-brand-text-secondary mt-2">Your AI-Powered Finance Hub</p>
        </div>

        <h2 className="text-xl font-semibold mb-6 text-center">
          {isLogin ? 'Welcome Back' : 'Create Account'}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-brand-text-secondary mb-1">Username</label>
            <input 
              type="text" 
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-brand-bg border border-brand-border rounded-lg p-3 text-brand-text-primary focus:outline-none focus:border-brand-primary focus:ring-1 focus:ring-brand-primary transition-all"
              placeholder="Enter your username"
            />
          </div>
          <div>
            <label className="block text-sm text-brand-text-secondary mb-1">Password</label>
            <input 
              type="password" 
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-brand-bg border border-brand-border rounded-lg p-3 text-brand-text-primary focus:outline-none focus:border-brand-primary focus:ring-1 focus:ring-brand-primary transition-all"
              placeholder="••••••••"
            />
          </div>

          <button 
            type="submit" 
            className="w-full bg-gradient-to-r from-brand-success to-brand-primary hover:opacity-90 text-white font-bold py-3 rounded-lg transition-all duration-200 mt-4 shadow-lg"
          >
            {isLogin ? 'Log In' : 'Sign Up'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-brand-text-secondary text-sm">
            {isLogin ? "Don't have an account?" : "Already have an account?"}
          </p>
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="text-brand-primary font-semibold text-sm hover:underline mt-1"
          >
            {isLogin ? 'Make an account' : 'Log In'}
          </button>
        </div>
      </div>
      
      <div className="mt-8 flex items-center gap-2 text-brand-text-secondary opacity-50">
         <Logo className="w-6 h-6 grayscale opacity-70" />
         <span className="text-sm font-medium tracking-widest">FINANCIO</span>
      </div>
    </div>
  );
};

export default LoginPage;
