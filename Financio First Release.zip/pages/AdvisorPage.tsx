import React, { useState, useRef, useEffect, useCallback } from 'react';
import Card from '../components/common/Card';
import Icon from '../components/common/Icon';
import { getChatResponse } from '../services/geminiService';
import { Chat } from '@google/genai';

interface AdvisorPageProps {
  location: GeolocationCoordinates | null;
  locationError: string | null;
}

interface Message {
  sender: 'user' | 'bot';
  text: string;
}

const AdvisorPage: React.FC<AdvisorPageProps> = ({ location, locationError }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const chatRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);
  
  const initializeChat = useCallback(() => {
    let locationInfo = "User location not available.";
    if (location) {
        locationInfo = `User is at latitude ${location.latitude} and longitude ${location.longitude}.`;
    } else if (locationError) {
        locationInfo = `Could not get user location: ${locationError}.`;
    }
    const systemInstruction = `You are a helpful and knowledgeable financial advisor named Financify AI. You provide insightful analysis on stocks, cryptocurrencies, and general market trends. Your advice should be for informational purposes only and not considered legal financial advice. Use markdown for formatting. Current user location context: ${locationInfo}`;
    chatRef.current = getChatResponse(systemInstruction);
  }, [location, locationError]);

  useEffect(() => {
    initializeChat();
  }, [initializeChat]);


  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { sender: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setError(null);
    
    setMessages(prev => [...prev, { sender: 'bot', text: '' }]);

    try {
      if (!chatRef.current) {
         initializeChat();
      }
      if(!chatRef.current) throw new Error("Chat not initialized");

      const stream = await chatRef.current.sendMessageStream({ message: userMessage.text });

      for await (const chunk of stream) {
        const chunkText = chunk.text;
        if(chunkText) {
            setMessages(prev => {
                const newMessages = [...prev];
                newMessages[newMessages.length - 1].text += chunkText;
                return newMessages;
            });
        }
      }
    } catch (e: any) {
      const errorMsg = e instanceof Error 
        ? `API Error: ${e.message}` 
        : `An unexpected error occurred: ${String(e)}`;
      setError(errorMsg);
      setMessages(prev => prev.slice(0, -1)); // Remove the empty bot message
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div>
        <h1 className="text-3xl font-bold text-brand-text-primary">AI Financial Advisor</h1>
        <p className="text-brand-text-secondary mt-1">Ask me anything about the market, your portfolio, or financial strategies.</p>
      </div>
      <Card className="mt-6 flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto pr-4 space-y-4">
          {messages.map((msg, index) => (
            <div key={index} className={`flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
              {msg.sender === 'bot' && <div className="w-8 h-8 bg-brand-primary rounded-full flex-shrink-0 flex items-center justify-center font-bold text-brand-bg">F</div>}
              <div className={`max-w-xl p-3 rounded-xl ${msg.sender === 'user' ? 'bg-brand-primary text-white' : 'bg-brand-border'}`}>
                <p className="whitespace-pre-wrap">{msg.text}</p>
                {isLoading && msg.sender === 'bot' && index === messages.length - 1 && <span className="inline-block w-2 h-2 bg-white rounded-full animate-pulse ml-2"></span>}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        
        {error && <p className="text-brand-danger text-sm mt-2 px-3">{error}</p>}

        <div className="p-4 border-t border-brand-border bg-brand-surface flex items-center gap-2">
            <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type your question..."
                className="flex-1 bg-brand-bg border border-brand-border rounded-full px-4 py-2 focus:outline-none focus:border-brand-primary text-brand-text-primary"
                disabled={isLoading}
            />
            <button
                onClick={handleSend}
                disabled={isLoading || !input.trim()}
                className="p-2 rounded-full bg-brand-primary text-white disabled:bg-brand-text-secondary disabled:cursor-not-allowed hover:bg-brand-secondary transition-colors"
            >
                <Icon name="send" className="w-5 h-5" />
            </button>
        </div>
      </Card>
    </div>
  );
};

export default AdvisorPage;