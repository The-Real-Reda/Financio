
export enum AssetType {
  Stock = 'Stock',
  Crypto = 'Crypto',
  Commodity = 'Commodity',
}

export interface Asset {
  id: string;
  name: string;
  ticker: string;
  type: AssetType;
  price: number;
  change24h: number;
  change24h_percent: number;
  value: number;
  holdings: number;
  logo: string;
}

export interface BankAccount {
  id: string;
  name: string;
  provider: string;
  accountNumber: string;
  balance: number;
  currency: string;
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
}

export interface ChartDataPoint {
  date: string;
  price: number;
}
