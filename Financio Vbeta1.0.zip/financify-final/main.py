"""
Financify Desktop - Version Finale
Point d'entrée de l'application
"""
import sys
import os
from PyQt6.QtWidgets import QApplication, QSplashScreen, QLabel, QProgressBar, QVBoxLayout, QWidget
from PyQt6.QtCore import Qt, QTimer, QRect
from PyQt6.QtGui import QPixmap, QPainter, QColor, QFont, QPen
from src.ui.main_window import FinancifyMainWindow

class ModernSplashScreen(QWidget):
    """Splash screen moderne avec progression"""
    
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(600, 400)
        
        # Centrer l'écran
        screen = QApplication.primaryScreen().geometry()
        self.move(
            (screen.width() - self.width()) // 2,
            (screen.height() - self.height()) // 2
        )
        
        # Layout
        layout = QVBoxLayout()
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(20)
        
        # Container avec fond
        container = QWidget()
        container.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #667eea, stop:1 #764ba2);
                border-radius: 20px;
            }
        """)
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(40, 40, 40, 40)
        container_layout.setSpacing(30)
        
        # Icon
        icon_label = QLabel("💰")
        icon_label.setFont(QFont("Segoe UI", 80))
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon_label.setStyleSheet("color: white;")
        
        # Title
        title_label = QLabel("Financify")
        title_label.setFont(QFont("Segoe UI", 36, QFont.Weight.Bold))
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet("color: white;")
        
        # Subtitle
        subtitle_label = QLabel("Your Investment Hub")
        subtitle_label.setFont(QFont("Segoe UI", 16))
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle_label.setStyleSheet("color: rgba(255, 255, 255, 0.8);")
        
        # Progress bar
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(6)
        self.progress.setStyleSheet("""
            QProgressBar {
                background-color: rgba(255, 255, 255, 0.2);
                border-radius: 3px;
            }
            QProgressBar::chunk {
                background-color: white;
                border-radius: 3px;
            }
        """)
        
        # Loading text
        self.loading_label = QLabel("Loading...")
        self.loading_label.setFont(QFont("Segoe UI", 12))
        self.loading_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.loading_label.setStyleSheet("color: rgba(255, 255, 255, 0.9);")
        
        # Add to layout
        container_layout.addStretch()
        container_layout.addWidget(icon_label)
        container_layout.addWidget(title_label)
        container_layout.addWidget(subtitle_label)
        container_layout.addStretch()
        container_layout.addWidget(self.progress)
        container_layout.addWidget(self.loading_label)
        
        layout.addWidget(container)
        self.setLayout(layout)
        
    def set_progress(self, value, text=""):
        """Met à jour la progression"""
        self.progress.setValue(value)
        if text:
            self.loading_label.setText(text)

def main():
    """Point d'entrée principal"""
    
    # Configuration de l'application
    app = QApplication(sys.argv)
    app.setApplicationName("Financify")
    app.setOrganizationName("Financify Team")
    app.setApplicationVersion("1.0.0")
    
    # Splash screen
    splash = ModernSplashScreen()
    splash.show()
    app.processEvents()
    
    # Simulation de chargement
    steps = [
        (20, "Initializing database..."),
        (40, "Loading assets..."),
        (60, "Loading accounts..."),
        (80, "Preparing interface..."),
        (100, "Almost ready...")
    ]
    
    for progress, text in steps:
        QTimer.singleShot(progress * 15, lambda p=progress, t=text: splash.set_progress(p, t))
    
    # Créer et afficher la fenêtre principale
    def show_main():
        try:
            print("🚀 Démarrage de Financify...")
            window = FinancifyMainWindow()
            window.show()
            splash.close()
            print("✅ Financify démarré avec succès!")
        except Exception as e:
            print(f"❌ Erreur au démarrage: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)
    
    QTimer.singleShot(1800, show_main)
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
