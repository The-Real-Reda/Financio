#!/bin/bash

echo "═══════════════════════════════════════════════════════════════════"
echo "           💰 FINANCIFY - BUILD FINAL VERSION 💰"
echo "═══════════════════════════════════════════════════════════════════"
echo ""

# Déterminer Python
if command -v python3 &> /dev/null; then
    PYTHON="python3"
    PIP="python3 -m pip"
elif command -v python &> /dev/null; then
    PYTHON="python"
    PIP="python -m pip"
else
    echo "❌ Python non trouvé!"
    echo "Installez Python 3.8+"
    exit 1
fi

echo "[1/6] Vérification de Python..."
$PYTHON --version
echo "✅ Python détecté"
echo ""

echo "[2/6] Mise à jour de pip..."
$PIP install --upgrade pip --quiet
echo "✅ pip à jour"
echo ""

echo "[3/6] Installation des dépendances..."
echo "   Cela peut prendre 3-5 minutes..."
echo ""

$PIP install PyQt6==6.6.1 --quiet 2>/dev/null || $PIP install PyQt6 --quiet
echo "   ✅ PyQt6"

$PIP install requests==2.31.0 --quiet
echo "   ✅ requests"

$PIP install pandas==2.1.4 --quiet 2>/dev/null || $PIP install pandas --quiet
echo "   ✅ pandas"

$PIP install matplotlib==3.8.2 --quiet 2>/dev/null || $PIP install matplotlib --quiet
echo "   ✅ matplotlib"

$PIP install pyinstaller==6.3.0 --quiet 2>/dev/null || $PIP install pyinstaller --quiet
echo "   ✅ pyinstaller"

echo ""
echo "✅ Toutes les dépendances installées"
echo ""

echo "[4/6] Test de l'application..."
$PYTHON -c "from PyQt6.QtWidgets import QApplication; print('✅ PyQt6 OK')" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "❌ PyQt6 ne fonctionne pas"
    exit 1
fi
echo ""

echo "[5/6] Compilation en EXE..."
echo "   ⏳ Cela peut prendre 10-15 minutes..."
echo ""

# Nettoyer
rm -rf build dist *.spec 2>/dev/null

# Compiler
$PYTHON -m PyInstaller \
    --name="Financify" \
    --onefile \
    --windowed \
    --add-data="src:src" \
    --add-data="data:data" \
    --hidden-import=PyQt6 \
    --hidden-import=PyQt6.QtCore \
    --hidden-import=PyQt6.QtGui \
    --hidden-import=PyQt6.QtWidgets \
    --collect-all=PyQt6 \
    --noconfirm \
    --clean \
    main.py

echo ""
echo "[6/6] Vérification finale..."
sleep 2

if [ -f "dist/Financify" ] || [ -f "dist/Financify.exe" ]; then
    echo ""
    echo "═══════════════════════════════════════════════════════════════════"
    echo "              🎉 SUCCÈS! Exécutable créé! 🎉"
    echo "═══════════════════════════════════════════════════════════════════"
    echo ""
    
    if [ -f "dist/Financify" ]; then
        EXE_PATH="dist/Financify"
    else
        EXE_PATH="dist/Financify.exe"
    fi
    
    echo "📁 Emplacement: $(pwd)/$EXE_PATH"
    ls -lh "$EXE_PATH"
    echo ""
    echo "🚀 Pour lancer:"
    echo "   ./$EXE_PATH"
    echo ""
    
    read -p "Voulez-vous tester l'application maintenant? (O/N): " test
    if [[ "$test" =~ ^[Oo]$ ]]; then
        chmod +x "$EXE_PATH"
        "./$EXE_PATH" &
        echo "✅ Application lancée!"
    fi
else
    echo ""
    echo "❌ ERREUR DE BUILD"
    echo ""
    echo "Solutions:"
    echo "1. Vérifiez les erreurs ci-dessus"
    echo "2. Essayez: $PYTHON -m PyInstaller --onefile main.py"
    exit 1
fi

echo ""
echo "═══════════════════════════════════════════════════════════════════"
