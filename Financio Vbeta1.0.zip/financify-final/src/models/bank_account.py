"""
BankAccount Model - Version améliorée
"""
from datetime import datetime
from enum import Enum

class AccountType(Enum):
    CHECKING = ("Checking Account", "💳", "#4CAF50")
    SAVINGS = ("Savings Account", "💰", "#2196F3")
    INVESTMENT = ("Investment Account", "📊", "#9C27B0")
    CREDIT = ("Credit Card", "💳", "#FF5722")
    
    def __init__(self, display_name, icon, color):
        self.display_name = display_name
        self.icon = icon
        self.color = color

class BankAccount:
    """Représente un compte bancaire"""
    
    def __init__(self, account_number, account_name, account_type):
        self.id = None
        self.account_number = str(account_number)
        self.account_name = account_name
        self.type = account_type if isinstance(account_type, AccountType) else AccountType[account_type]
        self._balance = 0.0
        self.currency = "USD"
        self.is_active = True
        self.created_date = datetime.now()
        self.transactions = []
    
    @property
    def balance(self):
        return self._balance
    
    @balance.setter
    def balance(self, value):
        self._balance = float(value)
    
    def deposit(self, amount):
        """Déposer de l'argent"""
        self._balance += float(amount)
    
    def withdraw(self, amount):
        """Retirer de l'argent"""
        if amount <= self._balance:
            self._balance -= float(amount)
            return True
        return False
    
    def formatted_balance(self):
        """Balance formatée"""
        return f"{self.currency} {self._balance:,.2f}"
    
    def masked_account_number(self):
        """Numéro de compte masqué"""
        if len(self.account_number) >= 4:
            return "****" + self.account_number[-4:]
        return self.account_number
    
    def get_icon(self):
        """Retourne l'icône du compte"""
        return self.type.icon
    
    def get_color(self):
        """Retourne la couleur du compte"""
        return self.type.color
    
    def to_dict(self):
        """Convertit en dictionnaire"""
        return {
            'id': self.id,
            'account_number': self.account_number,
            'account_name': self.account_name,
            'type': self.type.name,
            'balance': self._balance,
            'currency': self.currency,
            'is_active': self.is_active,
            'created_date': self.created_date.isoformat()
        }
    
    def __repr__(self):
        return f"BankAccount({self.account_name}, {self.masked_account_number()})"
    
    def __str__(self):
        return f"{self.get_icon()} {self.account_name} - {self.formatted_balance()}"
