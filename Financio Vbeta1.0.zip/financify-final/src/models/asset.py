"""
Asset Model - Version améliorée avec validations
"""
from datetime import datetime
from enum import Enum

class AssetType(Enum):
    STOCK = ("Stock", "📈", "#4A90E2")
    CRYPTO = ("Crypto", "₿", "#F7931A")
    GOLD = ("Gold", "🥇", "#FFD700")
    SILVER = ("Silver", "🥈", "#C0C0C0")
    COMMODITY = ("Commodity", "📦", "#8B4513")
    
    def __init__(self, display_name, icon, color):
        self.display_name = display_name
        self.icon = icon
        self.color = color

class Asset:
    """Représente un actif financier"""
    
    def __init__(self, symbol, name, asset_type, current_price=0.0, previous_price=0.0, quantity=0.0):
        self.id = None
        self.symbol = symbol.upper()
        self.name = name
        self.type = asset_type if isinstance(asset_type, AssetType) else AssetType[asset_type]
        self._current_price = float(current_price)
        self._previous_price = float(previous_price)
        self._quantity = float(quantity)
        self.last_updated = datetime.now()
        
    @property
    def current_price(self):
        return self._current_price
    
    @current_price.setter
    def current_price(self, value):
        self._previous_price = self._current_price
        self._current_price = float(value)
        self.last_updated = datetime.now()
    
    @property
    def previous_price(self):
        return self._previous_price
    
    @previous_price.setter
    def previous_price(self, value):
        self._previous_price = float(value)
    
    @property
    def quantity(self):
        return self._quantity
    
    @quantity.setter
    def quantity(self, value):
        self._quantity = float(value)
    
    @property
    def total_value(self):
        """Valeur totale de l'actif"""
        return self._current_price * self._quantity
    
    @property
    def change_amount(self):
        """Montant du changement"""
        return (self._current_price - self._previous_price) * self._quantity
    
    @property
    def change_percent(self):
        """Pourcentage de changement"""
        if self._previous_price > 0:
            return ((self._current_price - self._previous_price) / self._previous_price) * 100
        return 0.0
    
    @property
    def is_positive(self):
        """True si le changement est positif"""
        return self.change_percent >= 0
    
    def formatted_price(self):
        """Prix formaté"""
        return f"${self._current_price:,.2f}"
    
    def formatted_change(self):
        """Changement formaté"""
        sign = "+" if self.is_positive else ""
        return f"{sign}{self.change_percent:.2f}%"
    
    def formatted_value(self):
        """Valeur totale formatée"""
        return f"${self.total_value:,.2f}"
    
    def formatted_quantity(self):
        """Quantité formatée selon le type"""
        if self.type == AssetType.CRYPTO:
            return f"{self._quantity:.6f}"
        return f"{self._quantity:.2f}"
    
    def get_icon(self):
        """Retourne l'icône de l'actif"""
        return self.type.icon
    
    def get_color(self):
        """Retourne la couleur de l'actif"""
        return self.type.color
    
    def to_dict(self):
        """Convertit en dictionnaire"""
        return {
            'id': self.id,
            'symbol': self.symbol,
            'name': self.name,
            'type': self.type.name,
            'current_price': self._current_price,
            'previous_price': self._previous_price,
            'quantity': self._quantity,
            'total_value': self.total_value,
            'change_percent': self.change_percent,
            'last_updated': self.last_updated.isoformat()
        }
    
    def __repr__(self):
        return f"Asset({self.symbol}, {self.name}, {self.formatted_price()})"
    
    def __str__(self):
        return f"{self.get_icon()} {self.symbol} - {self.formatted_price()} ({self.formatted_change()})"
