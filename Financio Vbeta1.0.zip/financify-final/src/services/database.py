"""
Database Service - Version robuste avec gestion d'erreurs
"""
import sqlite3
import os
from datetime import datetime
from pathlib import Path
from src.models.asset import Asset, AssetType
from src.models.bank_account import BankAccount, AccountType

class DatabaseService:
    """Service de gestion de la base de données SQLite"""
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, 'initialized'):
            self.db_path = self._get_db_path()
            self.ensure_db_directory()
            self.init_database()
            self.initialized = True
    
    def _get_db_path(self):
        """Obtient le chemin de la base de données"""
        # Utiliser le dossier de données ou le dossier courant
        if os.path.exists('data'):
            return os.path.join('data', 'financify.db')
        return 'financify.db'
    
    def ensure_db_directory(self):
        """Crée le répertoire de données si nécessaire"""
        db_dir = os.path.dirname(self.db_path)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir, exist_ok=True)
    
    def get_connection(self):
        """Obtient une connexion à la base de données"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            return conn
        except Exception as e:
            print(f"Erreur de connexion DB: {e}")
            return None
    
    def init_database(self):
        """Initialise les tables de la base de données"""
        conn = self.get_connection()
        if not conn:
            return
        
        try:
            cursor = conn.cursor()
            
            # Table des utilisateurs
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    first_name TEXT,
                    last_name TEXT,
                    created_date TEXT NOT NULL
                )
            ''')
            
            # Table des actifs
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS assets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    symbol TEXT NOT NULL,
                    name TEXT NOT NULL,
                    type TEXT NOT NULL,
                    current_price REAL NOT NULL DEFAULT 0,
                    previous_price REAL DEFAULT 0,
                    quantity REAL NOT NULL DEFAULT 0,
                    last_updated TEXT NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            ''')
            
            # Table des comptes bancaires
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS bank_accounts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    account_number TEXT UNIQUE NOT NULL,
                    account_name TEXT NOT NULL,
                    type TEXT NOT NULL,
                    balance REAL NOT NULL DEFAULT 0,
                    currency TEXT NOT NULL DEFAULT 'USD',
                    is_active INTEGER NOT NULL DEFAULT 1,
                    created_date TEXT NOT NULL,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            ''')
            
            conn.commit()
            print("✅ Base de données initialisée")
        except Exception as e:
            print(f"❌ Erreur d'initialisation DB: {e}")
        finally:
            conn.close()
    
    def create_demo_user(self):
        """Crée un utilisateur de démonstration avec des données"""
        conn = self.get_connection()
        if not conn:
            return 1
        
        try:
            cursor = conn.cursor()
            
            # Vérifier si l'utilisateur existe
            cursor.execute("SELECT id FROM users WHERE username = ?", ("demo",))
            result = cursor.fetchone()
            
            if result:
                user_id = result[0]
                print("✅ Utilisateur demo existant trouvé")
            else:
                # Créer l'utilisateur
                cursor.execute('''
                    INSERT INTO users (username, email, first_name, last_name, created_date)
                    VALUES (?, ?, ?, ?, ?)
                ''', ("demo", "demo@financify.com", "Demo", "User", datetime.now().isoformat()))
                user_id = cursor.lastrowid
                
                # Créer les actifs de démonstration
                demo_assets = [
                    ("AAPL", "Apple Inc.", "STOCK", 175.50, 173.20, 10),
                    ("GOOGL", "Alphabet Inc.", "STOCK", 142.30, 140.80, 15),
                    ("MSFT", "Microsoft Corp.", "STOCK", 380.25, 378.90, 8),
                    ("NVDA", "NVIDIA Corp.", "STOCK", 495.75, 488.20, 5),
                    ("BTC", "Bitcoin", "CRYPTO", 43500.00, 42800.00, 0.5),
                    ("ETH", "Ethereum", "CRYPTO", 2350.00, 2310.00, 2.5),
                    ("SOL", "Solana", "CRYPTO", 98.75, 95.20, 25),
                    ("GOLD", "Gold", "GOLD", 2050.50, 2045.00, 5),
                    ("SILVER", "Silver", "SILVER", 24.75, 24.50, 100),
                ]
                
                for symbol, name, asset_type, current, previous, qty in demo_assets:
                    cursor.execute('''
                        INSERT INTO assets (user_id, symbol, name, type, current_price, previous_price, quantity, last_updated)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (user_id, symbol, name, asset_type, current, previous, qty, datetime.now().isoformat()))
                
                # Créer les comptes bancaires
                demo_accounts = [
                    ("1234567890", "Main Checking", "CHECKING", 25000.00),
                    ("0987654321", "Savings Account", "SAVINGS", 50000.00),
                    ("5555666677", "Investment Account", "INVESTMENT", 150000.00),
                ]
                
                for acc_num, acc_name, acc_type, balance in demo_accounts:
                    cursor.execute('''
                        INSERT INTO bank_accounts (user_id, account_number, account_name, type, balance, currency, is_active, created_date)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (user_id, acc_num, acc_name, acc_type, balance, "USD", 1, datetime.now().isoformat()))
                
                print("✅ Données de démonstration créées")
            
            conn.commit()
            return user_id
            
        except Exception as e:
            print(f"❌ Erreur création demo user: {e}")
            return 1
        finally:
            conn.close()
    
    def get_assets(self, user_id):
        """Récupère tous les actifs d'un utilisateur"""
        conn = self.get_connection()
        if not conn:
            return []
        
        try:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, symbol, name, type, current_price, previous_price, quantity, last_updated
                FROM assets WHERE user_id = ?
                ORDER BY symbol
            ''', (user_id,))
            
            assets = []
            for row in cursor.fetchall():
                asset = Asset(row[1], row[2], row[3], row[4], row[5], row[6])
                asset.id = row[0]
                assets.append(asset)
            
            return assets
            
        except Exception as e:
            print(f"❌ Erreur récupération assets: {e}")
            return []
        finally:
            conn.close()
    
    def get_bank_accounts(self, user_id):
        """Récupère tous les comptes bancaires d'un utilisateur"""
        conn = self.get_connection()
        if not conn:
            return []
        
        try:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, account_number, account_name, type, balance, currency, is_active
                FROM bank_accounts WHERE user_id = ?
                ORDER BY created_date
            ''', (user_id,))
            
            accounts = []
            for row in cursor.fetchall():
                account = BankAccount(row[1], row[2], row[3])
                account.id = row[0]
                account.balance = row[4]
                account.currency = row[5]
                account.is_active = bool(row[6])
                accounts.append(account)
            
            return accounts
            
        except Exception as e:
            print(f"❌ Erreur récupération comptes: {e}")
            return []
        finally:
            conn.close()
    
    def update_asset_price(self, asset_id, new_price):
        """Met à jour le prix d'un actif"""
        conn = self.get_connection()
        if not conn:
            return False
        
        try:
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE assets 
                SET previous_price = current_price,
                    current_price = ?,
                    last_updated = ?
                WHERE id = ?
            ''', (new_price, datetime.now().isoformat(), asset_id))
            conn.commit()
            return True
        except Exception as e:
            print(f"❌ Erreur mise à jour prix: {e}")
            return False
        finally:
            conn.close()
