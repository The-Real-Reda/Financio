"""
Main Window - Interface moderne et complète
"""
from PyQt6.QtWidgets import *
from PyQt6.QtCore import *
from PyQt6.QtGui import *
from src.services.database import DatabaseService
import sys

class ModernCard(QFrame):
    """Carte moderne avec ombre"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            QFrame {
                background-color: #2b2d42;
                border-radius: 15px;
                padding: 20px;
            }
        """)
        # Ombre
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 60))
        shadow.setOffset(0, 5)
        self.setGraphicsEffect(shadow)

class FinancifyMainWindow(QMainWindow):
    """Fenêtre principale de Financify"""
    
    def __init__(self):
        super().__init__()
        self.db = DatabaseService()
        self.user_id = self.db.create_demo_user()
        self.init_ui()
        self.load_data()
        
        # Timer pour rafraîchir (toutes les 60 secondes)
        self.timer = QTimer()
        self.timer.timeout.connect(self.refresh_data)
        self.timer.start(60000)
    
    def init_ui(self):
        """Initialise l'interface utilisateur"""
        self.setWindowTitle("💰 Financify - Investment Hub")
        self.setGeometry(100, 100, 1400, 900)
        self.setMinimumSize(1200, 800)
        
        # Style global moderne
        self.setStyleSheet("""
            QMainWindow {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #0f0e17, stop:1 #1a1a2e);
            }
            QLabel {
                color: #fffffe;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
            QPushButton {
                background-color: #7f5af0;
                color: #fffffe;
                border: none;
                padding: 12px 24px;
                border-radius: 10px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #9d77f7;
            }
            QPushButton:pressed {
                background-color: #6842c2;
            }
            QTableWidget {
                background-color: #1e1e1e;
                color: #fffffe;
                border: none;
                border-radius: 10px;
                gridline-color: #2b2d42;
            }
            QTableWidget::item {
                padding: 12px;
                border-bottom: 1px solid #2b2d42;
            }
            QTableWidget::item:selected {
                background-color: #7f5af0;
            }
            QHeaderView::section {
                background-color: #2b2d42;
                color: #fffffe;
                padding: 12px;
                border: none;
                font-weight: bold;
            }
            QTabWidget::pane {
                border: none;
                background-color: transparent;
            }
            QTabBar::tab {
                background-color: #2b2d42;
                color: #94a1b2;
                padding: 15px 30px;
                margin-right: 5px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                font-size: 14px;
                font-weight: bold;
            }
            QTabBar::tab:selected {
                background-color: #7f5af0;
                color: #fffffe;
            }
            QTabBar::tab:hover {
                background-color: #3d3f5c;
            }
            QScrollArea {
                border: none;
                background-color: transparent;
            }
            QScrollBar:vertical {
                background-color: #1e1e1e;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #7f5af0;
                border-radius: 6px;
            }
        """)
        
        # Widget central
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)
        
        # Header
        layout.addWidget(self.create_header())
        
        # Tabs
        self.tabs = QTabWidget()
        self.tabs.addTab(self.create_dashboard(), "📊 Dashboard")
        self.tabs.addTab(self.create_invest(), "📈 Invest")
        self.tabs.addTab(self.create_banking(), "🏦 Banking")
        self.tabs.addTab(self.create_stats(), "📈 Statistics")
        layout.addWidget(self.tabs)
        
        # Status bar moderne
        self.statusBar().setStyleSheet("""
            QStatusBar {
                background-color: #2b2d42;
                color: #94a1b2;
                border-top: 2px solid #7f5af0;
            }
        """)
        self.statusBar().showMessage("✅ Ready | Last update: " + QTime.currentTime().toString())
    
    def create_header(self):
        """Crée le header moderne"""
        header = ModernCard()
        layout = QHBoxLayout(header)
        
        # Logo et titre
        title_layout = QHBoxLayout()
        icon_label = QLabel("💰")
        icon_label.setFont(QFont("Segoe UI", 32))
        title_label = QLabel("Financify")
        title_label.setFont(QFont("Segoe UI", 28, QFont.Weight.Bold))
        title_layout.addWidget(icon_label)
        title_layout.addWidget(title_label)
        title_layout.addStretch()
        
        layout.addLayout(title_layout)
        layout.addStretch()
        
        # User info
        user_widget = QWidget()
        user_layout = QVBoxLayout(user_widget)
        user_layout.setContentsMargins(0, 0, 0, 0)
        
        user_name = QLabel("👤 Demo User")
        user_name.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        user_email = QLabel("demo@financify.com")
        user_email.setFont(QFont("Segoe UI", 11))
        user_email.setStyleSheet("color: #94a1b2;")
        
        user_layout.addWidget(user_name)
        user_layout.addWidget(user_email)
        layout.addWidget(user_widget)
        
        return header
    
    def create_dashboard(self):
        """Crée le dashboard"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(20)
        
        # Cartes statistiques
        cards_layout = QHBoxLayout()
        
        self.total_card = self.create_stat_card("Total Portfolio", "$0", "+$0 (0%)")
        self.assets_card = self.create_stat_card("Total Assets", "0", "Stocks, Crypto, Gold")
        self.accounts_card = self.create_stat_card("Bank Accounts", "0", "Active accounts")
        
        cards_layout.addWidget(self.total_card)
        cards_layout.addWidget(self.assets_card)
        cards_layout.addWidget(self.accounts_card)
        layout.addLayout(cards_layout)
        
        # Titre section
        title = QLabel("📈 My Investment Portfolio")
        title.setFont(QFont("Segoe UI", 20, QFont.Weight.Bold))
        layout.addWidget(title)
        
        # Table des actifs
        self.assets_table = QTableWidget()
        self.assets_table.setColumnCount(7)
        self.assets_table.setHorizontalHeaderLabels([
            "Symbol", "Name", "Type", "Price", "Change %", "Quantity", "Total Value"
        ])
        self.assets_table.horizontalHeader().setStretchLastSection(True)
        self.assets_table.setAlternatingRowColors(True)
        self.assets_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.assets_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.assets_table.verticalHeader().setVisible(False)
        layout.addWidget(self.assets_table)
        
        return widget
    
    def create_invest(self):
        """Crée la section investissement"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        card = ModernCard()
        card_layout = QVBoxLayout(card)
        card_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.setSpacing(20)
        
        icon = QLabel("📈")
        icon.setFont(QFont("Segoe UI", 80))
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        title = QLabel("Investment Trading")
        title.setFont(QFont("Segoe UI", 28, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        subtitle = QLabel("Search and trade stocks, crypto, and commodities")
        subtitle.setFont(QFont("Segoe UI", 14))
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("color: #94a1b2;")
        
        btn = QPushButton("🚀 Start Trading")
        btn.setFixedWidth(200)
        btn.setFixedHeight(50)
        btn.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        
        card_layout.addWidget(icon)
        card_layout.addWidget(title)
        card_layout.addWidget(subtitle)
        card_layout.addWidget(btn, alignment=Qt.AlignmentFlag.AlignCenter)
        
        layout.addWidget(card)
        
        return widget
    
    def create_banking(self):
        """Crée la section banking"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setSpacing(20)
        
        # Total bancaire
        self.bank_total = QLabel("Total: $0")
        self.bank_total.setFont(QFont("Segoe UI", 24, QFont.Weight.Bold))
        layout.addWidget(self.bank_total)
        
        # Table des comptes
        self.accounts_table = QTableWidget()
        self.accounts_table.setColumnCount(4)
        self.accounts_table.setHorizontalHeaderLabels([
            "Account Name", "Account Number", "Type", "Balance"
        ])
        self.accounts_table.horizontalHeader().setStretchLastSection(True)
        self.accounts_table.setAlternatingRowColors(True)
        self.accounts_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.accounts_table.verticalHeader().setVisible(False)
        layout.addWidget(self.accounts_table)
        
        return widget
    
    def create_stats(self):
        """Crée la section statistiques"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        card = ModernCard()
        card_layout = QVBoxLayout(card)
        card_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        icon = QLabel("📊")
        icon.setFont(QFont("Segoe UI", 80))
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        title = QLabel("Advanced Statistics")
        title.setFont(QFont("Segoe UI", 28, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        subtitle = QLabel("Detailed charts and analytics coming soon")
        subtitle.setFont(QFont("Segoe UI", 14))
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet("color: #94a1b2;")
        
        card_layout.addWidget(icon)
        card_layout.addWidget(title)
        card_layout.addWidget(subtitle)
        
        layout.addWidget(card)
        
        return widget
    
    def create_stat_card(self, title, value, subtitle):
        """Crée une carte statistique"""
        card = ModernCard()
        layout = QVBoxLayout(card)
        layout.setSpacing(10)
        
        title_label = QLabel(title)
        title_label.setFont(QFont("Segoe UI", 12))
        title_label.setStyleSheet("color: #94a1b2;")
        
        value_label = QLabel(value)
        value_label.setFont(QFont("Segoe UI", 32, QFont.Weight.Bold))
        value_label.setObjectName("value")
        
        subtitle_label = QLabel(subtitle)
        subtitle_label.setFont(QFont("Segoe UI", 11))
        subtitle_label.setStyleSheet("color: #94a1b2;")
        subtitle_label.setObjectName("subtitle")
        
        layout.addWidget(title_label)
        layout.addWidget(value_label)
        layout.addWidget(subtitle_label)
        
        return card
    
    def load_data(self):
        """Charge toutes les données"""
        self.load_assets()
        self.load_bank_accounts()
        self.update_summary()
    
    def load_assets(self):
        """Charge les actifs"""
        assets = self.db.get_assets(self.user_id)
        self.assets_table.setRowCount(len(assets))
        
        for i, asset in enumerate(assets):
            # Symbol
            symbol = QTableWidgetItem(f"{asset.get_icon()} {asset.symbol}")
            symbol.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
            self.assets_table.setItem(i, 0, symbol)
            
            # Name
            self.assets_table.setItem(i, 1, QTableWidgetItem(asset.name))
            
            # Type
            type_item = QTableWidgetItem(asset.type.display_name)
            type_item.setForeground(QColor(asset.get_color()))
            self.assets_table.setItem(i, 2, type_item)
            
            # Price
            self.assets_table.setItem(i, 3, QTableWidgetItem(asset.formatted_price()))
            
            # Change
            change_item = QTableWidgetItem(asset.formatted_change())
            change_item.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
            if asset.is_positive:
                change_item.setForeground(QColor("#16db93"))
            else:
                change_item.setForeground(QColor("#ff6b6b"))
            self.assets_table.setItem(i, 4, change_item)
            
            # Quantity
            self.assets_table.setItem(i, 5, QTableWidgetItem(asset.formatted_quantity()))
            
            # Total Value
            value_item = QTableWidgetItem(asset.formatted_value())
            value_item.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
            self.assets_table.setItem(i, 6, value_item)
    
    def load_bank_accounts(self):
        """Charge les comptes bancaires"""
        accounts = self.db.get_bank_accounts(self.user_id)
        self.accounts_table.setRowCount(len(accounts))
        
        total = sum(acc.balance for acc in accounts)
        self.bank_total.setText(f"Total: ${total:,.2f}")
        
        for i, acc in enumerate(accounts):
            self.accounts_table.setItem(i, 0, QTableWidgetItem(f"{acc.get_icon()} {acc.account_name}"))
            self.accounts_table.setItem(i, 1, QTableWidgetItem(acc.masked_account_number()))
            
            type_item = QTableWidgetItem(acc.type.display_name)
            type_item.setForeground(QColor(acc.get_color()))
            self.accounts_table.setItem(i, 2, type_item)
            
            balance_item = QTableWidgetItem(acc.formatted_balance())
            balance_item.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
            balance_item.setForeground(QColor("#16db93"))
            self.accounts_table.setItem(i, 3, balance_item)
    
    def update_summary(self):
        """Met à jour les cartes de résumé"""
        assets = self.db.get_assets(self.user_id)
        accounts = self.db.get_bank_accounts(self.user_id)
        
        total_assets = sum(a.total_value for a in assets)
        total_bank = sum(acc.balance for acc in accounts)
        total = total_assets + total_bank
        
        total_change = sum(a.change_amount for a in assets)
        change_pct = (total_change / (total - total_change) * 100) if total > 0 else 0
        
        # Mise à jour des cartes
        self.total_card.findChild(QLabel, "value").setText(f"${total:,.2f}")
        
        subtitle_text = f"${total_change:+,.2f} ({change_pct:+.2f}%)"
        subtitle = self.total_card.findChild(QLabel, "subtitle")
        subtitle.setText(subtitle_text)
        subtitle.setStyleSheet(f"color: {'#16db93' if total_change >= 0 else '#ff6b6b'};")
        
        self.assets_card.findChild(QLabel, "value").setText(str(len(assets)))
        self.accounts_card.findChild(QLabel, "value").setText(str(len(accounts)))
        
        # Mise à jour status bar
        self.statusBar().showMessage(f"✅ Portfolio: ${total:,.2f} | Assets: {len(assets)} | Last update: {QTime.currentTime().toString()}")
    
    def refresh_data(self):
        """Rafraîchit les données"""
        self.load_data()
        print("🔄 Données rafraîchies")
